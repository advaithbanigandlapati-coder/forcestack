# ForceStack — Beta Tester Terms (plain-language summary)

Thanks for helping test ForceStack. Before you run it, the short version of the
deal (the full, binding terms are in [LICENSE](LICENSE)):

**You may**
- Download, install, and run ForceStack to try it out and tell us what breaks.

**You may not**
- Share, re-post, or forward the code or the zip to anyone else.
- Reverse-engineer it or reuse its code/ideas in your own or a competing project.
- Use it in production or for anything commercial — this is an evaluation build.

**Please know**
- This is **pre-release beta software that makes privileged system changes**
  (firewall, services, registry, kernel settings). Test it on a machine or VM
  you can afford to break, not a production box. Every change it makes is logged
  and reversible from the in-app Change Journal, but run it at your own risk.
- There is **no warranty**. If something goes wrong, we're not liable.
- Anything you report back (bugs, ideas) we can use freely to improve the product.

**How to help**
1. Run it and use it normally.
2. Note anything confusing, broken, or wrong.
3. Send feedback to: <your contact here>.

Running ForceStack means you accept the full terms in LICENSE. Not open source —
all rights reserved.
