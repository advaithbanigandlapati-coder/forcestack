# Changelog

## v6.2.5-beta — Current
The Windows launcher now handles any Python and installs one if missing.

- **Works with any Python 3.10+.** `Start-ForceStack.bat` searches for installed
  interpreters and picks the best one, preferring 3.13/3.12/3.11/3.10 (which have
  the widest prebuilt-wheel support so the optional ML/PQC extras install without
  a compiler) before falling back to newer/bleeding-edge versions like 3.14.
- **Auto-installs Python if none is found** — via `winget`
  (`Python.Python.3.12`), or a silent download-and-install from python.org if
  winget isn't available. (After a fresh install it asks you to double-click once
  more so the new PATH is picked up.)
- Rejects interpreters older than 3.10, and `build_windows.bat` got the same
  version-preferring detection.

## v6.2.4-beta — Current
Fixed install failure on Python 3.14 (Pillow build-from-source error).

- **Symptom:** on Python 3.14, first-run setup died building Pillow from source
  ("The headers or library files could not be found for zlib") because
  Pillow 10.x has no prebuilt 3.14 wheel.
- **Cause:** `pyproject.toml` pinned `pillow~=10.0`, forcing the 3.14-incompatible
  10.x line. Pillow isn't even imported at runtime — it only came in transitively
  (reportlab depends on it) and via dev-time logo tooling.
- **Fix:** removed the Pillow pin (moved to the `[dev]` extra). reportlab's own
  open `pillow>=9` requirement now lets pip pick a modern Pillow (11.x/12.x) that
  ships a 3.14 wheel — no compiler needed. Also loosened the customtkinter/psutil/
  reportlab pins from `~=` to `>=` so pip can pick wheels for newer Pythons.

## v6.2.3-beta — Current
Fixed the Windows launcher so first-run setup is reliable.

- **Bug:** `Start-ForceStack.bat` decided whether to install dependencies based
  on whether the `.venv` folder existed. If the first run created the venv but
  the dependency install didn't finish (e.g. the optional `scikit-learn` /
  `pqcrypto` extras failing to build on Windows), every later run skipped setup
  and launched with nothing installed → `ModuleNotFoundError: customtkinter`.
- **Fix:** the launcher now checks that the dependencies actually *import*
  (self-healing), installs the guaranteed base packages first, and treats the
  heavy ML/PQC extras as optional (the GUI runs fine without them). `build_windows.bat`
  got the same base-first / extras-optional treatment.

## v6.2.2-beta — Current
Much easier to run — no command line required.

- **`Start-ForceStack.bat`** (Windows): double-click to run. First launch sets up
  a private virtual environment and installs dependencies automatically, then
  starts the GUI; self-elevates to Administrator (hardening tools change system
  settings). No manual pip commands.
- **`build_windows.bat`**: one double-click builds a standalone
  **`dist\ForceStack.exe`** — a single file testers run with no Python and no
  install. Auto-requests Administrator and carries the app icon.
- The PyInstaller spec now embeds the app icon (`assets/logo_mark.ico`), requests
  UAC elevation (`uac_admin`), and bundles the brand assets.
- README rewritten to lead with these double-click paths.

## v6.2.1-beta — Current
Licensing for private beta distribution.

- Replaced the MIT license with a **proprietary Beta Evaluation License** (all
  rights reserved; evaluation only; no redistribution, reverse-engineering, or
  commercial use), so sharing the source zip with testers no longer grants them
  the right to reuse or rebrand the code.
- Added `BETA_TESTERS.md` — plain-language terms testers accept by running it.
- Updated the README license section and the pyproject license classifier.
- Dropped in the official ForceStack logo (`assets/logo.png`) and a
  square emblem app/window icon (`assets/logo_mark.png`).
  (Not legal advice — have a lawyer review before relying on it. Remember: the
  strongest protection is handing testers a built binary rather than source.)

## v5.12.0 — Current
Rebrand: **PyToolCS → ForceStack**, plus a logo.

- Renamed everything across the codebase, docs, CI, and build spec (~230
  occurrences in 47 files): display name, the `ForceStackApp` class, the
  `forcestack` distribution/CLI name and console script, the encrypted-file
  extension (`.ptcs` → `.fstk`), the container magic bytes (`PTCS` → `FSTK`),
  the armor headers (`FORCESTACK …`), the env var (`FORCESTACK_EBPF_COLLECTOR`),
  and the PyInstaller spec (`ForceStack.spec`).
- **Config-dir migration:** data now lives in `~/.forcestack`; on first run the
  app moves a legacy `~/.pytoolcs` across automatically, so existing audit logs,
  the rollback journal, snapshots, and config are preserved.
- **New brand assets:** `assets/logo.svg` (full lockup) and `assets/logo_mark.svg`
  (icon), with PNG renders. The window now uses the mark as its icon (guarded).

No functional changes: 138 tests still pass, `ruff` clean, all pages render.

## v5.11.0
Genuine **in-kernel telemetry** via eBPF (C), the real answer to the probe's
"userland-only / sampling-gap" limitation.

**New `ebpf/` — kernel-side eBPF program in C.**
- `proc_monitor.bpf.c`: an eBPF (CO-RE) program that attaches to the kernel
  `sched_process_exec` / `sched_process_exit` tracepoints and streams events to
  userland over a ring buffer. It runs *in the kernel* (checked by the BPF
  verifier), so it sees every process as it happens — no polling, no sampling
  gap. This is the mechanism modern EDR (Falco, Tetragon) use.
- `proc_monitor.c`: a libbpf userland loader that emits one JSON event per line.
- `Makefile` + `README.md`: build with clang/libbpf on a BTF-enabled kernel.

**Probe integration (`core/eventsource.py`).** A new eBPF backend runs the
compiled collector as a subprocess and consumes its events. Source priority is
now **eBPF → netlink proc connector → Windows WMI → polling**, still strictly
fail-safe and self-verifying: if the collector isn't built, lacks privilege
(needs root/CAP_BPF), or the kernel lacks BTF, it silently falls back, and the
probe only reports "kernel events (ebpf)" once events are actually flowing.
Point it at a build with `FORCESTACK_EBPF_COLLECTOR=/path/to/ebpf/proc_monitor`
(or drop the binary at `ebpf/proc_monitor`).

**Verified vs. not (honest):** the full userland integration — subprocess spawn,
liveness check, JSON parsing, event delivery, self-verification, and fail-safe
fallback — is covered by tests using a simulated collector. The kernel-side C
itself needs clang + libbpf + kernel BTF + CAP_BPF to compile and load, none of
which exist in this CI sandbox, so — like the Windows paths — it's
correct-by-construction and unverified here; it must be built and loaded on a
real host to confirm. It is defense/telemetry only: it does not inline-block in
the kernel (containment is still a userland process-suspend), and Intel-TDT-style
hardware telemetry remains out of reach without vendor drivers.

**Tests**: 138 passing (added eBPF integration + fallback coverage). `ruff` clean.

## v5.10.0
Narrowing the Sentinel Probe's known limitations. Two we improved materially,
two are close to inherent and are now at least handled honestly.

**Event-driven, kernel-sourced telemetry (`core/eventsource.py`)** — new.
Instead of polling only, the probe now consumes the event streams the OS
already exposes to userland (no kernel driver):
- Linux: the kernel **netlink proc connector** pushes fork/exec/exit events as
  they happen (needs root/CAP_NET_ADMIN).
- Windows: a **WMI** `Win32_ProcessStartTrace` subscription (best-effort).
It is strictly **fail-safe and self-verifying**: if a source can't start or
delivers nothing, the probe stays on polling — and it only reports "kernel
events" once events are actually arriving, so it never claims a capability it
isn't getting. This addresses the "userland = polling" and "sampling-gap"
limitations where the OS allows: the burst detector now counts event-sourced
spawns, so processes that start *and* finish between polls are no longer missed.

**Adaptive sampling.** When activity spikes, the poll interval halves (down to
1s), shrinking the blind spot exactly when it matters — a mitigation for the
gap on hosts without an event source.

**False-positive feedback loop.** `mark_benign()` lets you teach the probe that
a detection was benign: it mutes that alert and folds the current behaviour into
the ML baseline, so a first-time backup/build stops reading as anomalous.
(Critical-severity findings still surface even if suppressed.)

**Honest degraded-mode reporting.** The probe page now shows its live telemetry
source, and states plainly when it's running unprivileged ("polling — DEGRADED:
limited network→PID mapping, no containment").

**Still genuinely out of reach (stated, not hidden):** true in-kernel inline
blocking and hardware telemetry (Intel TDT) need a driver and aren't reachable
from Python; anomaly detection fundamentally flags deviation, not intent (the
feedback loop and optional LLM triage reduce but can't eliminate this); and
containment/full network mapping still require admin/root by OS design.

**Tests**: 134 passing (added event-source fail-safe/honesty, mark-benign
suppression + baseline feedback, event-sourced burst detection, adaptive
interval). `ruff` clean.

## v5.9.3
Lint pass — `ruff check .` now reports zero issues (was 205), so the CI lint
gate passes.

- **Real bug fixed:** `Callable` was used in a type hint in `ui/widgets.py`
  without being imported.
- **Real bug fixed:** `save_config` in `core/constants.py` had a duplicate,
  unreachable `except Exception` (a copy-paste leftover from a load routine).
- **Cleanups:** removed the unused `w`/`h` in the animated background's
  `_animate` (kept them in `_draw`, where they're used); removed other dead
  locals (unused report colours, `sc`/`done_count`/`journal_lbl`/`risk_col` in
  the UI, stray `pfx` in two scripts, unused test locals); added `raise … from
  None` on the vault's decrypt-failure errors so internal exceptions don't leak;
  added explicit `strict=False` to `zip()` calls in the probe; replaced bare
  `except:` with `except Exception:` in `open_ports`; converted assigned lambdas
  to `def`; renamed ambiguous `l` variables to `lbl` in the run view.
- **Config:** migrated ruff settings to the non-deprecated `[tool.ruff.lint]`
  section, and scoped the hardening scripts' intentional metadata-first/compact
  one-liner style (and tests' terse style) via per-file ignores rather than
  rewriting them. Compact single-line conditionals are treated as house style.

No behavioural changes: 130 tests still pass and all 12 pages render.

## v5.9.2
Packaging & CI fixes so the documented first-run works and CI can actually run.

- **`pip install -e .` now works.** This is a flat layout with several top-level
  packages, which modern setuptools won't auto-discover — the README's Quick
  Start failed with "Multiple top-level packages discovered in a flat-layout".
  Added explicit discovery to `pyproject.toml`:
  `[tool.setuptools] packages = ["core","scripts","ui","ui.pages"]` +
  `py-modules = ["main"]`. Verified a wheel build packages exactly
  core/scripts/ui/main and excludes tests.
- **CI no longer references removed requirements files.** `ci.yml` and
  `build.yml` installed from `requirements.txt` / `requirements-dev.txt` /
  `requirements-build.txt`, none of which exist since deps moved to
  `pyproject.toml` extras — every push would have failed at the install step.
  Now: tests use `pip install -e ".[full,dev]"` and builds use
  `".[full,build]"`. The inline PyInstaller calls (which also missed hidden
  imports for cryptography/sklearn/pqcrypto and the dynamically-loaded
  `scripts/`) were switched to the maintained `ForceStack.spec`.

## v5.9.1 — Packaging fix
- **Removed a stray brace-expansion junk folder** (`{core,scripts,ui,assets,
  tests,.github`) that had ridden along in the archive since the original
  upload — an empty directory created by a `mkdir {…}` run under `sh` instead of
  `bash`. It was harmless to execution (the real `core/` was intact and the app
  ran) but confusing, and could make a file listing look like `core/` was
  missing. Added a packaging guard so it can't reappear. Verified from a fresh
  extraction: no junk folders, all packages import, app starts, tests pass.

## v5.9.0
The small-items cleanup: honest status codes, private-key-at-rest protection,
and keyboard accessibility.

**`disable_services` reports the truth.** It used to return success
unconditionally; it now tracks each service-disable (and SMBv1) result and
returns the real pass/fail, emitting per-service OK/ERR.

**Private keys can be protected at rest.** The Encryption Vault can now wrap a
private-key bundle under a passphrase (Argon2id + AES-256-GCM) instead of
storing it as plaintext:
- The keypair generator has an optional "Protect private key with a passphrase"
  field; when set, it outputs a protected key block.
- Decryption auto-detects a protected key and prompts for the passphrase
  (`decrypt_with_private` / `decrypt_file_with_private` gained a `passphrase`
  argument; `wrap_private_bundle` / `unwrap_private_bundle` / `is_wrapped_private`
  are the new API). Tested round-trip, wrong-passphrase rejection, and
  decrypt-through-a-protected-key.

**Keyboard accessibility.** Building on the high-contrast/scale options:
- A visible **focus ring** (accent border) now marks the focused button, so
  keyboard users can see where they are.
- **Enter activates the focused button.** Space is deliberately not bound, so
  typing spaces into fields still works — verified, along with the focus ring
  and activation, under a headless render.

**Tests**: 130 passing (added key-wrap round-trip/rejection and the honest
return-value coverage).

**Remaining (unchanged, and honestly out of scope for this sandbox):** the
Windows/macOS code paths and the PyInstaller binary still need verification on
real hardware; there are no UI-handler integration tests; and probe detection
efficacy against real threats is unproven. Screen-reader labeling is limited by
Tk itself.

## v5.8.0
Cleared the remaining backlog: every state-changing tool is now reversible, the
install is lightweight by default, there's a real accessibility pass, and
packaging is fixed.

**Reversibility is now uniform across all hardening tools**
- Added a command-based rollback to the hardening layer (`record_undo` +
  `KIND_COMMAND`): a change can store an explicit undo command that `revert()`
  runs. Retrofitted the last command-only scripts:
  - `disable_services` — journals per-service re-enable (restoring the original
    Windows start type), and re-enabling SMBv1.
  - `auto_updates` — Windows keys now go through the verified `apply_registry`
    path; the apt config is backed up; enabling unattended-upgrades / dnf-timer
    journals a disable-undo; Microsoft Update registration journals a removal-undo.
  - `firewall_config` — captures the prior firewall state and journals a restore
    (turn back off / `ufw disable`) only when it was off before, so revert never
    locks you into a state you didn't have.
- Every reversible change (probe or hardening) is undoable from the UI Change
  Journal's **↩ Revert** button, which routes through `probe.revert_change()`.

**Lighter install.** scikit-learn, numpy, and pqcrypto are now **optional
extras** (`.[ml]`, `.[pqc]`, or `.[full]`), not base dependencies. The base
install is just customtkinter/psutil/pillow/reportlab/cryptography; the probe
falls back to its pure-Python anomaly detector and the vault to password mode if
the extras aren't present. This resolves the "lightweight vs heavy deps" tension.

**Accessibility pass (Settings → Accessibility)**
- **High-contrast mode** — brightens text tiers and borders for low-vision
  readability.
- **Text & interface size** — 100–175% scale applied on top of DPI, enlarging
  fonts and controls. Both persist to config and apply on restart.
- Verified: the app renders in both normal and high-contrast + 1.25× modes on
  stock Tcl/Tk 8.6.

**Packaging fixed.** Added a maintained `ForceStack.spec` that bundles the
dynamically-loaded `scripts/` modules (which the old inline build missed) and
collects the optional ML/PQC/crypto packages; build scripts now install the
`full,build` extras and use the spec. (The spec is validated; a full binary
build isn't runtime-tested in this environment.)

**Tests**: 128 passing (added command-revert and accessibility tests).

## v5.7.0
Made the rollback features reachable, and added five new fully-reversible
hardening tools.

**Rollback & quarantine are now usable from the UI**
- The Sentinel Probe page's Change Journal now reads from the shared durable
  journal, so it shows BOTH probe actions and hardening-tool changes, and each
  reversible entry has a **↩ Revert** button. Reverted items drop off the list.
- A **⊘ Quarantine…** button lets you move a suspicious file into quarantine
  (moved aside, never deleted); it appears in the journal and can be restored
  with one click. This wires up capabilities that previously existed only in code.

**Five new revertable hardening "superscripts" (all in System Hardening)**
Each applies a bundle of related protections through the apply-verify-rollback
layer, so the whole thing can be undone from the Change Journal:
- **Kernel & Network Stack Hardening** — sysctl protections on Linux
  (kptr/dmesg restrict, ptrace scope, SYN cookies, rp_filter, no ICMP
  redirects/source-routing, protected links, no suid core dumps); TCP/IP
  registry hardening on Windows.
- **Legacy Protocol Lockdown** — disables SMBv1, requires SMB signing, disables
  LLMNR (Windows).
- **Credential Theft Protection** — LSA Protection (RunAsPPL), WDigest cleartext
  off, NTLMv2-only, fewer cached logons (Windows); login.defs hashing/umask
  hardening (Linux).
- **Command & Script Execution Logging** — PowerShell script-block/module
  logging + command-line process auditing (Windows); auditd execve rule (Linux).
- **Filesystem & Removable Media Hardening** — AutoRun/AutoPlay off, SmartScreen
  on (Windows); blacklist of uncommon filesystem modules (Linux).

**Coverage**: 25 hardening/scanning tools total; 124 tests passing (added
superscript registration, macOS-graceful, and UI-revert-delegation tests). All
12 UI pages render on stock Tcl/Tk 8.6.

**Still open (honestly):** the older command-only scripts (firewall, auto-updates,
disable-services) still need per-tool undo commands to be reversible; an
accessibility pass and PyInstaller packaging remain; and the deep dependency
stack (sklearn/numpy/cryptography/pqcrypto) is heavy at install time even though
runtime footprint is small.

## v5.6.0
Closed the last things holding the toolkit back: the UI now renders everywhere,
and the probe's remaining false-positive sources are fixed.

**UI portability — the app renders on stock Tcl/Tk again**
- Fixed the crash on standard Tk 8.6: 8-digit `#RRGGBBAA` colours are now
  composited over the base background into valid `#RRGGBB` at the palette level
  (a `_Color` type flattens any appended alpha automatically), so not one call
  site changed and the glass theme renders on every Tk version.
- Fixed a customtkinter 5.2 incompatibility: `_main` was placed with
  `width`/`height` on `place()`, which CTk 5.2 rejects. It now uses a
  constructor width kept in sync on resize (with a re-entrancy guard).
- Verified: all 12 pages render on Tcl/Tk 8.6.14 (dashboard, run-all, probe,
  encryption, the four tool sections, audit, report, settings).

**Sentinel Probe — false positives cut**
- MemoryDefense no longer alerts on the bare "running from a deleted file"
  signal (which fires on every Linux daemon after a package update / the
  "(deleted)" marker). It now requires corroboration — a commonly-abused tool,
  a live network connection, a very recent start, or an oddly-random name — and
  otherwise just feeds the ML model.
- IdentityTelemetry no longer floods on everyday tools: `python`, `curl`, `sh`,
  `wget`, `perl` on ordinary ports are left to the ML model. Only high-signal
  binaries (PowerShell, certutil, rundll32, nc/ncat/socat, …) alert on any
  outbound connection, and *anything* on a known-bad C2 port still alerts.
- Confirmed on a live idle run: model active, 0.02 MB footprint, 0 alerts.

**Tests**: 107 passing (added 5 for the false-positive fixes).

## v5.5.0
The Sentinel Probe rebuilt around real machine learning, with the honesty gaps
from the v5.3 review closed.

**The probe now genuinely uses AI (`core/probe.py`)**
- Added an unsupervised anomaly model that turns each system snapshot into an
  11-feature behavioural vector and scores it: **scikit-learn IsolationForest**
  by default, with a **pure-Python robust z-score** fallback so it still learns
  and scores with no heavy dependency. This is the NGAV approach — learn the
  machine's own baseline, flag deviations, no signatures.
- The model **calibrates its score against the training distribution** (std-devs
  below normal), so idle machines don't false-positive: on a 20-sample idle run
  the anomaly score sat at 0.06 with zero alerts, while an injected behavioural
  spike scored ≥ 0.7 and alerted.
- Every ML detection is **explained**: it reports which features deviated and by
  how many σ. The learned baseline is persisted, and flagged-anomalous samples
  are deliberately **not** folded back into "normal" (no baseline poisoning).
- The optional LLM triage hook remains, clearly separated from the always-on ML
  model and still off by default.

**Beaconing false-positive fixed.** The detector now counts connection
*establishment* events (new-this-sample), not "connection present." A single
long-lived connection (SSH, a browser keep-alive) produces one event and is no
longer mistaken for perfectly-regular C2 beaconing. (Regression test included.)

**"Probe RAM" metric fixed.** It reported the whole application's RSS. It now
reports the probe's **own retained-data footprint** (labelled "Probe data
footprint"): 0.02 MB in the idle run above, versus 160 MB whole-app RSS.

**Smart-rollback made real.** Probe changes are written to the **same durable
rollback journal** as the hardening layer (`core/hardening.py`). Process
containment is a reversible suspend/resume; a suspicious file can be
**quarantined** (moved aside, not deleted) and restored; and registry/file
reverts delegate to the hardening layer. `revert_change()` undoes any of these.

**Tests**: 102 passing — 15 for the probe (ML learns/flags on both backends,
calibration, no-poisoning, persistence, beaconing regression incl. the
persistent-connection case, honest footprint, durable revertible rollback).

## v5.4.0
Encryption and the hardening toolkit hardened to enterprise grade.

**Encryption Vault — rebuilt (`core/pqcrypto.py`, container format v2)**
- Post-quantum KEM now runs on **PQClean's constant-time C implementation**
  (`pqcrypto`) by default, instead of a pure-Python reference. The engine is
  backend-pluggable and reports, honestly, whether the live backend is
  production-grade (`pqc_production_grade`) — the UI shows a "PQC: constant-time"
  vs "PQC: reference (eval only)" badge accordingly.
- Password mode upgraded from scrypt to **Argon2id** (memory-hard; scrypt kept
  as an automatic fallback). The KDF and its parameters are recorded per file.
- **The entire container header is now authenticated** as AES-GCM associated
  data, so tampering with any algorithm/parameter is detected — previously only
  the magic bytes were bound.
- **Streaming file encryption**: files are encrypted as a chain of individually
  authenticated 1 MiB chunks with per-chunk nonces and an explicit
  end-of-stream marker, so truncation/reordering/splicing is detected and memory
  use is constant regardless of file size. Large-file encryption now runs off
  the UI thread with a progress indicator.
- **Removed the plaintext SHA-256 from the container** (it leaked whether two
  ciphertexts shared a plaintext and let an attacker confirm guessed contents).
  GCM already authenticates; SHA-256 remains a standalone verification tool.

**Hardening toolkit — apply / verify / rollback (`core/hardening.py`)**
- New shared layer: every managed change is applied, **read back to verify it
  actually took effect** (no more reporting "OK" on a silently failed write),
  and **journalled so it can be reverted precisely**. Registry writes capture
  the prior value; edited config files are backed up first.
- Retrofitted `rdp_hardening`, `screen_lock`, and `guest_disable` (Windows
  registry writes now verified + reversible) and `rdp_hardening`,
  `account_lockout`, `screen_lock` (Linux config files backed up before edit).
- The durable rollback journal is the honest foundation the Sentinel Probe's
  "smart rollback" will build on next.

**Tests**: 93 passing (was 75) — 20 crypto (streaming, truncation, header-AAD,
no-plaintext-hash, production-backend), 6 rollback.

**Known UI item (not yet addressed):** on stock Tcl/Tk 8.6, raw-widget glass
colors (8-digit RGBA hex) fail to render; the app needs Tk 8.7+ or a color
flatten pass. Tracked for the UI polish work.

## v5.3.0
Three major additions plus an accessibility pass and a security review.

**New: Sentinel Probe — low-RAM, AI-assisted NGAV sensor (`core/probe.py`)**
- Behaviour-based detection that catches zero-day and polymorphic threats with
  no signature, by watching processes, live network connections, and the audit
  log together. Keeps only a small fixed-size event window, so its footprint
  stays low; the UI shows the probe's own RAM use.
- Four detection modules mapped to 2026 NGAV frontiers: AgenticThreat
  (machine-speed/AI-orchestrated bursts, C2 beaconing), MemoryDefense (fileless
  malware with no file on disk), IdentityTelemetry (living-off-the-land abuse of
  trusted tools), and SmartRollback (journals precise, reversible system changes
  so a malicious one can be undone without touching user files).
- Explainable heuristic analyzer always on; optional AI-triage hook (off by
  default, no network calls unless installed). Defensive only — the strongest
  action is a reversible process *suspend*, opt-in, admin-gated.

**New: Encryption Vault — hybrid post-quantum + SHA-256 (`core/pqcrypto.py`)**
- Password mode (scrypt + AES-256-GCM) and keypair mode (hybrid ML-KEM-768 +
  X25519 → HKDF-SHA256 → AES-256-GCM), protecting against "harvest now, decrypt
  later" quantum attacks. Text, file, keypair, and SHA-256 verification tabs.
  Honest capability badges; degrades clearly if a library is missing.

**Accessibility / readability pass**
- New `ExplainCard` widget: a plain-English "what is this & why it matters"
  panel with an optional "For the curious →" deep-dive, so IT pros and first-
  timers alike can use and learn from every new page.

**Security review** — see `SECURITY_AUDIT_v5_3.md`. Fixed an unhandled
`FileNotFoundError`/`OSError` in `usb_lockdown.py`. 75 tests pass (14 new).

## v5.2.0
Three fixes — settings persistence, OS-filtered remediation, onboarding replay:

**Fix #59 — settings page now persists**
- `BooleanVar` checkboxes and `StringVar` entries were created fresh on every render
  with no save mechanism — selections lost on navigation
- `core/constants.py` extended with `save_config(updates: dict)` and
  `load_config_dict() -> dict` — atomic merge-write to config.json, safe read
- `_page_settings` now loads current saved values into all fields on render
- New fields: `timeout_secs`, `min_pw_len`, `max_pw_age`, `reports_dir`
- Script selection checkboxes read from and write to `disabled_tools: list[str]`
  in config.json — tools unchecked here are skipped in Run All
- "Apply and Save" button validates numeric fields, saves all values, shows
  confirmation with count of disabled tools
- `_page_run_all._start()` filters `tool_ids` against `disabled_tools` at run time

**Fix #60 — how_to_fix renders current OS steps only**
- All 20 `how_to_fix` strings contain Windows/macOS/Linux sections prefixed with
  their platform name. Previously all sections rendered regardless of OS.
- `_step_relevant(step)` filters by prefix match against `OS_NAME`: a step starting
  with "Windows:" only renders on Windows, etc. Steps with no prefix always render.
- Platform prefix stripped before display — user sees the instruction, not "macOS: ..."
- Non-technical home users on macOS no longer see Windows registry instructions

**Settings — onboarding wizard replay**
- "Re-run wizard" button in Settings removes the `~/.forcestack/onboarded` sentinel
  and re-shows the onboarding modal immediately
- Users who clicked Skip can return to the guided path without knowing about sentinel files

## v5.1.0
## v5.1.0 — Current
Three fixes — architectural consistency, lock contention, thread naming:

**Fix #57 — runner.run_all is now the single execution path**
- `_page_run_all` previously built its own `_worker` that called `mod.execute()` directly
  via importlib, bypassing `run_all` entirely — no per-tool timeout, no `_validate_result`,
  no `_make_emit`. A hanging script would hang the entire run indefinitely.
- `run_all` extended with three optional callbacks (all default to None — fully backward-
  compatible with headless/CLI callers):
    - `per_tool_start_cb(tid)` — called before each tool starts (UI marks it RUNNING)
    - `tool_output_cb(tid, line, level)` — per-tool terminal routing; falls back to output_cb
    - `progress_cb(fraction)` — progress bar update after each tool completes
- `_page_run_all._start()` now calls `runner.run_all(...)` with these callbacks wired in.
  All execution now goes through the runner: per-tool timeout, type checking, emit
  interception, toast routing, audit ordering.
- Dead `run_all` import resolved — it is now actually called.

**Fix #58 — audit _save released from lock contention**
- `audit.record()` previously held `_lock` for the full disk write. Any concurrent call
  to `last_run()`, `stats()`, or `get_entries()` blocked for the file write duration,
  causing UI lag during Run All.
- Fixed: snapshot `list(self.entries)` inside the lock, release lock, then call
  `_save(entries_snapshot)` outside it. Readers unblock immediately after insert.
- `_save()` accepts optional `entries_snapshot` parameter; other callers (still under
  their own locks) pass nothing and fall back to `self.entries` — unchanged behaviour.

**Fix #24 extension — sub-thread names now unique**
- `_sub` threads were named `forcestack-sub-{tool_id}` with no timestamp
- Two sequential run-all invocations produced identically named threads
- Fixed: `forcestack-sub-{tool_id}-{int(time.time())}` — consistent with outer thread naming

## v5.0.1
## v5.0.1 — Current
Two fixes in runner.py:

**Fix #55 — dry-run IndexError in run_all**
- `_sub` in dry-run mode wrote `holder[:] = [True, "dry-run"]` (2 elements)
- Unpacked immediately after as `result_holder[0], result_holder[1], result_holder[2]`
- `result_holder[2]` raised `IndexError`, thread died silently, `all_done_cb` never fired
- Fix: `holder[:] = [True, "dry-run", tname]` — `tname` already in scope at that point

**Fix #56 — _emit closure deduplication**
- The dict-intercepting `_emit` closure existed verbatim in both `run_script` and `run_all`
- Extracted to `_make_emit(output_cb, payload_list) -> Callable` factory function
- Both call sites replaced with `_emit = _make_emit(output_cb, _error_payloads)`
- Behaviour identical; single definition, testable in isolation

## v5.0.0
## v5.0.0 — Current
Two fixes closing the last real code-level gaps:

**`core/runner.py` — run_all dict emit parity with run_script**
- `run_all` previously passed `output_cb` directly to `mod.execute()` — dict payloads
  from scripts were handed to a str-expecting callback, silently dropped in headless/CLI
  mode, and `toast_cb` never fired during Run All via the runner
- `run_all` now wraps `output_cb` in the same `_emit` interceptor pattern as `run_script`:
  intercepts dict payloads, displays title + first fix line in the terminal, stashes for
  `toast_cb` which fires after `per_tool_done_cb` for each tool
- `toast_cb: Optional[ToastCB]` parameter added to `run_all` signature (default None,
  fully backward-compatible)
- The UI's `_page_run_all._per_emit` closure handles per-tool terminal routing and remains
  unchanged — the runner fix closes the headless gap, both paths are now correct independently

**`scripts/_base.py` — ErrorPayload TypedDict**
- `ErrorPayload(TypedDict)` added with required keys: `title`, `why`, `fix`, `raw`
- Exported from `__all__` — scripts import and annotate emit dict literals with it
- Wrong or missing key (e.g. `what_to_do` instead of `fix`) is now a type error at
  definition time rather than a silently empty card at render time
- Docstring includes full usage example and explains what the runner does with each key

## v4.6.2
## v4.6.2 — Current
Onboarding coverage + contributor contract documentation:

**`ui/app.py` — onboarding path coverage**
- All 20 tools now appear in at least one guided onboarding path (was 15/20)
- Home path additions: guest_disable, account_lockout, disable_services, dns_over_https (11 tools total)
- Admin path additions: disable_services, usb_lockdown (11 tools total)
- disable_services appears in both paths with context-appropriate rationale
- Time estimates updated: home ~25 min, admin ~60 min

**`CONTRIBUTING.md` — stateless module constraint + full script contract**
- Full script template with assert_tool_registered already in place and explained
- Explicit section on why assert_tool_registered must be at module level: importlib caches
  in sys.modules, module-level code does not re-execute, mutable state persists across runs
- sudo_prefix() requirement documented with correct/wrong examples and explanation of
  why hardcoding "sudo" breaks Windows and causes double-sudo on Linux
- shell=True prohibition documented with injection risk explained and correct alternative shown
- Structured dict emit pattern documented with all four required keys and what the runner
  does with them (terminal display + toast queue)
- Idempotency requirement made explicit with reference to hosts_blocklist.py pattern

## v4.6.1
## v4.6.1 — Current
Onboarding coverage fix: added all 5 tools missing from guided paths.
- Home path: guest_disable, account_lockout, disable_services, dns_over_https added (11 tools total)
- Admin path: disable_services, usb_lockdown added (11 tools total)
- All 20 tools now appear in at least one guided path
- Time estimates updated: home ~25 min, admin ~60 min

## v4.6.0
Remediation consistency + first-run onboarding:

**`core/tools.py` — `how_to_fix` field (all 20 tools)**
- New `how_to_fix: str` field on the `Tool` dataclass — plain-English, concrete, platform-specific
  remediation steps for every tool in the registry
- Covers all three platforms where applicable: exact navigation paths (Settings → ...), CLI
  commands with flags, and edge-case warnings (e.g. LUKS requires reinstall, USB needs MDM)
- Surfaced in the tool detail page as a permanent green "How to fix issues found by this tool"
  card — visible before running, not just after an error

**`ui/app.py` — first-run onboarding wizard**
- `_show_onboarding()`: shown once on first launch (sentinel: `~/.forcestack/onboarded`)
- Persona selection: Home/Personal (~15 min, 7 tools) vs IT Admin/Compliance (~45 min, 9 tools)
- Each persona reveals a prioritised scan path with rationale per step, risk badges, and
  "Start here" indicator on step 1
- CTA navigates directly to step 1 tool detail; "Go to dashboard" skips; both dismiss permanently
- Two-view flow (persona → path) with back navigation; scrollable for long admin path
- Sentinel written on any dismissal path — modal never re-appears

**`core/constants.py`**
- Added `ONBOARD_STATE = CONFIG_DIR / "onboarded"` sentinel path

## v4.5.0
Goal 1 completeness pass — error path rewrite across all scripts + infrastructure:

**Infrastructure**
- `ui/widgets.py`: Added `ErrorToast` — dismissible slide-in notification (bottom-right),
  shows plain-English title + one-liner, clicking "View fix steps" navigates to detail page
- `ui/app.py`: Added `_page_error_detail` — renders full error payload (what, why, fix steps,
  raw diagnostic output in ColorTerminal); added `_show_toast` wiring; toast_cb threaded
  through both `run_script` and `_page_run_all` execution paths
- `core/runner.py`: `emit` now intercepts dict payloads from scripts — shows title + first fix
  line in terminal immediately, stashes payload, fires `toast_cb` after `done_cb`

**Script error message rewrites**
- `av_status.py`: Structured emits for Windows real-time protection OFF, tamper protection OFF,
  macOS Gatekeeper disabled, Linux no-AV-found — each with navigation path or install command
- `hosts_blocklist.py`: Raw `Exception` catch replaced with structured emit explaining hosts
  file purpose, likely cause, and exact recovery steps
- `open_ports.py`: Access denied is now a structured emit; RISKY dict expanded from labels to
  `(label, plain-English risk description)` — shown inline under each flagged port
- `auto_updates.py`: `PermissionError` on `/etc/apt/apt.conf.d/20auto-upgrades` now explains
  what the file does, why it matters, and how to apply manually
- `nist_password.py`: `PermissionError` on `pwquality.conf` explains what the file controls
  and provides the manual fix command with the correct minlen value
- `startup_audit.py`: Non-system services now get investigation instructions (not just
  "verify expected"); `systemctl` and `reg query` failures are explicitly handled and emitted
  (previously silent `ok=True` on command failure)
- `wifi_security.py`: All weak/WEP detections now emit structured payloads with router admin
  page steps and OS-specific saved-profile cleanup on all three platforms
- `rdp_hardening.py`: SSH restart warning replaced with structured payload — why lockout
  is possible, exact test command, and step-by-step recovery if login fails

## v4.4.0
Bug fixes — 7 issues resolved (see below) + packaging polish:
- README version updated from v3.4 to v4.4
- `requirements.txt`, `requirements-dev.txt`, `requirements-build.txt` removed — all dependencies consolidated into `pyproject.toml` which already had them fully defined. Install with `pip install -e .`, `pip install -e ".[dev]"`, `pip install -e ".[build]"`.

Bug fixes — 7 issues resolved:

**Critical:**
- Fix #43: `auto_updates.py` — `NameError: dnf_path` on any Linux machine with dnf installed. `shutil.which()` returns bool into `has_dnf` but `dnf_path.strip()` referenced a variable that no longer exists. Fixed: `elif has_dnf and dnf_path.strip():` → `elif has_dnf:`.
- Fix #44: `dns_over_https.py` — merge branch built `new_lines` but never called `conf.write_text(...)`. DoH changes were silently discarded on re-runs. Also removed dead `if not tag_present:` block inside `if tag_present:` and fixed missing append of managed keys when `[Resolve]` is the last section.

**Medium:**
- Fix #45: `auto_updates.py` — macOS Darwin branch hardcoded `"sudo"` instead of `sudo_prefix()`. Same pattern already fixed across other scripts.
- Fix #46: `reporter.py` — `path.replace(".pdf", ".txt")` corrupts paths containing `.pdf` elsewhere (e.g. `/reports/report_2024.pdf.bak`). Fixed to `str(Path(path).with_suffix(".txt"))`.
- Fix #47: `nist_password.py` — `line.split("=")[0].strip().lstrip("#")` left a trailing space, so `#minlen=8` (no space after `#`) matched managed dict key and was silently uncommented and overwritten. Fixed by adding `.strip()` after `lstrip("#")`.
- Fix #48: `main.py` — `shlex.quote()` produces POSIX single-quote escaping, which breaks Windows argument parsing after UAC elevation. Replaced with `subprocess.list2cmdline()` which produces correct Windows double-quote escaping. Removed unused `import shlex`.

**Low:**
- Fix #49: `screen_lock.py` — dead `$p = New-Object System.Security.Principal.SecurityIdentifier('S-1-5-32-544')` in Windows secedit PowerShell command. `$p` was never referenced. Removed.

## v4.2.0
Bug fixes — 9 issues found and resolved:

**Critical / Correctness:**
- Fix #27: `startup_audit.py` — `rstrip(".service")` strips characters not a suffix, corrupting service names (e.g. `"NetworkManager.service"` → `"NetworkManag"`). Replaced with `removesuffix(".service")`.
- Fix #28: `runner.py` — timeout handler did `result_holder = [...]` (new object), discarding sub-thread result if it finished just before timeout. Fixed with in-place `result_holder[:] = [...]`.
- Fix #29: `guest_disable.py` — `ok` never updated from `ok1` in Linux branch; script always returned `True` even if all `passwd -l` calls failed.
- Fix #30: `guest_disable.py` — `detail` always said "locked" regardless of outcome. Now accurately reports which accounts were locked vs skipped.

**Bugs / Inconsistencies:**
- Fix #31: `guest_disable.py` — missing `assert_tool_registered(TOOL_ID)`.
- Fix #32: `guest_disable.py` — `sudo_prefix` not imported; Linux branch hardcoded `"sudo"`.
- Fix #33: `guest_disable.py` — macOS branch hardcoded `"sudo"` instead of `sudo_prefix()`.
- Fix #34: `av_status.py` — missing `assert_tool_registered(TOOL_ID)`.
- Fix #35: `wifi_security.py` — missing `assert_tool_registered(TOOL_ID)`.
- Fix #36: `auto_updates.py` — `run_cmd(["which", "apt/dnf"])` subprocess replaced with `shutil.which()` (same fix already applied to `cve_scan.py` in v3.4.0).
- Fix #37: `audit_logging.py` — hardcoded `"sudo"` in macOS branch replaced with `sudo_prefix()`.
- Fix #38: `account_lockout.py` — hardcoded `"sudo"` in macOS branch replaced with `sudo_prefix()`.
- Fix #39: `rdp_hardening.py` — hardcoded `"sudo"` in macOS branch replaced with `sudo_prefix()`.
- Fix #40: `rdp_hardening.py` — `_detect_ssh_service()` called `systemctl` once per loop iteration; hoisted to single call before loop.
- Fix #41: `disable_services.py` — hardcoded `"sudo"` in macOS branch replaced with `sudo_prefix()`.

**Minor:**
- Fix #42: `screen_lock.py` — `import re` buried inside `execute()` function body moved to top-level imports.

## v3.4.0
Full code review pass — all 26 issues resolved:

**Security / Correctness (from v3.3):**
- Fix #1: False HMAC claim removed — unused `import hmac`/`import hashlib` removed from `audit.py`
- Fix #3: Wrong NIST control `PE-11` (Emergency Power) → `IA-11` (Re-Authentication) for `screen_lock`
- Fix #4: `APP_VERSION` no longer defined twice — `main.py` imports from `core.constants`
- Fix #5: `TIMEOUT_SECS` corrected from 900s to 600s (10 min) to match all documentation
- Fix #6: `sudo_prefix()` now guards against `AttributeError` on Windows
- Fix #7: `run_all()` no longer re-imports each module; `tool_name` carried through `result_holder[2]`
- Fix #8: `assert_tool_registered()` validates against `TOOL_MAP` (authoritative), not `NIST_MAP`
- Fix #9: Hardcoded `"sudo"` in `usb_lockdown.py` replaced with `sudo_prefix()`
- Fix #10: Hardcoded `"sudo"` in `screen_lock.py` macOS branch replaced with `sudo_prefix()`

**Enterprise Features:**
- Fix #11: `--json-output` flag added to headless mode — writes `[{tool_id, status, detail, duration_s, nist}]` JSON to stdout for CI/SIEM integration
- Fix #12: `--headless` mode now attaches a `StreamHandler(sys.stderr)` at WARNING level so CI systems capture errors without tailing app.log
- Fix #13: Policy values now configurable via `--timeout-secs`, `--min-pw-len`, `--max-pw-age` CLI flags (also readable from `config.json` and env vars)
- Fix #14: `hosts_blocklist.py` now fetches the live StevenBlack 50,000-domain unified list with graceful fallback to built-in defaults if offline
- Fix #15: `cve_scan.py` uses `shutil.which()` for package manager detection instead of spawning `["which", pm]` subprocess
- Fix #17: macOS USB Lockdown limitation now honestly documented in both tool description and script output
- Fix #18: `~/.forcestack/config.json` now loaded at startup — supports `timeout_secs`, `min_pw_len`, `max_pw_age`, `build` keys

**Code Quality:**
- Fix #16: `pytest-timeout>=2.3` added to `[project.optional-dependencies]` dev in `pyproject.toml`
- Fix #19: `usb_lockdown.py` reformatted to standard Python style (was semicolon one-liners)
- Fix #20: `FORCESTACK_BUILD` environment variable documented in README
- Fix #21: `HOSTNAME = platform.node() or "<unknown>"` guards against empty string in containers
- Fix #22: `CONTRIBUTING.md` added — covers dev setup, script authoring contract, CI flags, env vars
- Fix #23: Windows uninstall instructions added to README (`rmdir /s /q %USERPROFILE%\.forcestack`)
- Fix #24: `py.typed` marker file added; registered in `pyproject.toml` package-data
- Fix #25: CHANGELOG now documents all fix numbers including those from source comments
- Fix #26: `F401` ruff suppression scoped to `scripts/_base.py` and `core/__init__.py` only

## v3.3.0
Code review fixes — security and correctness (13 bugs):
- Fix #1, #3, #4, #5, #6, #7, #8, #9, #10, #16, #21, #26 (see v3.4.0 for descriptions)

## v3.2.0
CI fixes (7 bugs):
- Bug 1–7: pytest-timeout, ruff config consolidation, build consistency, CI matrix guards

## v3.1.0
- Complete rebuild: glassmorphic UI, Warp-style terminal, 20 NIST-mapped scripts

## v2.0.0
- Multi-file enterprise structure

## v1.0.0
- Initial single-file prototype
