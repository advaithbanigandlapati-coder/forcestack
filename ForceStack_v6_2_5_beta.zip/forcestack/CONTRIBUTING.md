# Contributing to ForceStack

Thank you for your interest in contributing! This document covers the development workflow, how to add new scripts, and how to run the test suite.

## Development Setup

```bash
git clone https://github.com/your-org/forcestack.git
cd forcestack
pip install -e ".[dev]"
```

**Requirements:** Python 3.10+, pip.

## Running Tests

```bash
pytest                        # all tests
pytest tests/test_runner.py   # single file
pytest --timeout=30           # with timeout guard
```

## Adding a New Hardening Script

### Step-by-step

1. **Create the script** in `scripts/your_tool_id.py` using the full template below.
2. **Register it** in `core/tools.py` — add a `Tool(...)` entry to `ALL_TOOLS` with a populated `how_to_fix` field.
3. **Map its NIST controls** in `core/constants.py` — add to `NIST_MAP` and `NIST_CONTROL_NAMES`.
4. **Write a test** in `tests/test_scripts_dryrun.py`.

### Full script template

```python
"""scripts/your_tool_id.py — NIST XX-YY, XX-ZZ.
Brief description of what this script hardens and why it matters.
"""
TOOL_NAME = "Your Tool Name"
TOOL_ID   = "your_tool_id"

from scripts._base import run_cmd, sudo_prefix, assert_tool_registered, TIMEOUT_MEDIUM
from pathlib import Path

# assert_tool_registered MUST be at module level, not inside execute().
# It raises RuntimeError at import time if TOOL_ID is missing from TOOL_MAP or NIST_MAP,
# preventing silent registry drift. See: core/runner.py fix #23 and _base.py.
assert_tool_registered(TOOL_ID)


def execute(emit, os_name: str) -> tuple[bool, str]:
    emit("  Checking... (NIST XX-YY)\n", "info")
    ok = True

    if os_name == "Windows":
        out, rc = run_cmd(["reg", "query", r"HKLM\Some\Key"])
        if rc:
            emit("  OK  Setting is configured", "ok")
        else:
            # Structured error emit — the runner and UI both understand this shape.
            # All four keys are expected; omit none.
            emit({
                "title": "Plain-English description of what is wrong",
                "why": (
                    "One sentence explaining the security consequence. "
                    "Write for someone who is not a security professional."
                ),
                "fix": (
                    "Step 1: concrete action the user can take right now\n"
                    "Step 2: follow-up or verification step\n"
                    "Step 3: what to do if step 1 fails"
                ),
                "raw": f"reg query returned: {out[:200]}",
            }, "err")
            ok = False

    elif os_name == "Darwin":
        pfx = sudo_prefix()   # returns [] when already root; never hardcode ["sudo", ...]
        run_cmd(pfx + ["some", "macos", "command"])
        emit("  OK  Applied on macOS", "ok")

    else:
        pfx = sudo_prefix()
        run_cmd(pfx + ["some", "linux", "command"])
        emit("  OK  Applied on Linux", "ok")

    emit("\n  NIST XX-YY complete.", "info")
    return ok, "brief detail string for audit log"
```

### Why `assert_tool_registered` must be at module level

`importlib.import_module` caches results in `sys.modules`. Calling it a second time returns the cached module without re-executing module-level code. This means:

- **State in module-level variables persists across runs** within the same process. Do not store mutable state at module level — only constants and the `TOOL_ID`/`TOOL_NAME` strings.
- **`assert_tool_registered` fires exactly once per session**, at first import. It raises `RuntimeError` immediately if the tool is not in `TOOL_MAP` or `NIST_MAP`, surfacing the error at startup rather than silently producing wrong audit output.

If you need values that refresh between runs (e.g. policy constants read from environment variables), read them inside `execute()`, not at module level. See `nist_password.py` fix #4 for the pattern.

## Script Contract

Every `execute()` function must satisfy these requirements. Violations are caught by CI or at import time.

**Return value**

`execute(emit, os_name)` must return `(bool, str)`:
- `bool` — `True` if the check passed or the fix was applied successfully, `False` otherwise.
- `str` — a brief detail string for the audit log. Keep it under 80 characters.

**Output: `emit(line, level)`**

Use `emit` for all output — never `print()`. Levels:

| Level | Use |
|-------|-----|
| `"ok"` | Check passed or change applied successfully |
| `"err"` | Check failed or change could not be applied |
| `"warn"` | Needs attention but not a hard failure |
| `"info"` | Neutral status or progress message |

For failure conditions a non-technical user might encounter, pass a dict instead of a string:

```python
emit({
    "title": "What is wrong — plain English, no jargon",
    "why":   "One sentence on the security consequence",
    "fix":   "Step-by-step resolution, specific enough to follow without searching",
    "raw":   "Diagnostic output for the detail page terminal",
}, "err")
```

The runner intercepts dict payloads, displays `title` and the first `fix` line in the terminal immediately, and queues a toast notification linking to the full detail page. All four keys are required.

**Privilege escalation: always `sudo_prefix()`**

Never hardcode `["sudo", ...]`. Always use `sudo_prefix()`:

```python
pfx = sudo_prefix()
run_cmd(pfx + ["systemctl", "restart", "sshd"])
```

`sudo_prefix()` returns `["sudo"]` on Linux/macOS when not already root, and `[]` when running as root or on Windows. Hardcoding `"sudo"` breaks Windows silently and causes double-sudo errors when the tool is launched with `sudo python3 main.py`.

**Shell injection: never `shell=True`**

Always pass commands as lists. Never use `shell=True` or string concatenation:

```python
# Correct
run_cmd(["reg", "add", key, "/v", name, "/d", value, "/f"])

# Wrong — shell=True enables injection and breaks cross-platform behaviour
run_cmd(f"reg add {key} /v {name}", shell=True)
```

If a command genuinely requires shell features, construct the full argument list explicitly or use `subprocess` directly with `shell=False`.

**Idempotency**

Re-running a script must produce the same result. Check before writing — use guard conditions, tags (e.g. `FORCESTACK_TAG` in `hosts_blocklist.py`), or `already_applied()` where appropriate. A script that appends to a config file on every run is a bug.

## Configuration & Policy Values

Policy constants (timeouts, password lengths) can be overridden at runtime:

```bash
# CLI flags (headless mode)
python main.py --headless --timeout-secs 300 --min-pw-len 20

# Config file (~/.forcestack/config.json)
{"timeout_secs": 300, "min_pw_len": 20, "max_pw_age": 90}

# Environment variables (lowest precedence)
FORCESTACK_TIMEOUT_SECS=300 python main.py --headless
```

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `FORCESTACK_BUILD` | Build label in reports (sanitized) | `Enterprise` |
| `FORCESTACK_TIMEOUT_SECS` | Screen lock idle timeout | `600` |
| `FORCESTACK_MIN_PW_LEN` | Minimum password length | `15` |
| `FORCESTACK_MAX_PW_AGE` | Maximum password age (days) | `365` |

## CI / Headless Mode

```bash
# Run all tools, exit 0 on pass
python main.py --headless --dry-run

# Machine-readable JSON output for SIEM integration
python main.py --headless --json-output | jq .

# Run a single tool
python main.py --headless --tool firewall_config

# List all tool IDs
python main.py --list-tools
```

## Code Style

This project uses `ruff` for linting (configured in `pyproject.toml`). Run before committing:

```bash
ruff check .
```

Scripts in `scripts/` follow standard Python formatting. The historical one-liner style in `usb_lockdown.py` was corrected in v3.4.

## Uninstalling

**Linux/macOS:**
```bash
rm -rf ~/.forcestack
pip uninstall forcestack
```

**Windows:**
```cmd
rmdir /s /q %USERPROFILE%\.forcestack
pip uninstall forcestack
```
