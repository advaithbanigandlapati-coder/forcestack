# -*- mode: python ; coding: utf-8 -*-
# PyInstaller spec for ForceStack. Handles the app's dynamic script loading and
# the compiled/optional dependencies (sklearn, numpy, pqcrypto, cryptography).
#
# Build:  pyinstaller ForceStack.spec
#
# Note: scripts/*.py are imported at runtime via importlib, so PyInstaller's
# static analysis cannot see them — we add them explicitly with
# collect_submodules("scripts"). The heavy ML/PQC libs are optional at runtime;
# collect_all is wrapped so a missing optional package doesn't break the build.
from PyInstaller.utils.hooks import collect_all, collect_submodules

datas, binaries, hiddenimports = [], [], []

# Required + always-bundled
for pkg in ("customtkinter", "PIL", "reportlab", "cryptography"):
    d, b, h = collect_all(pkg)
    datas += d; binaries += b; hiddenimports += h

# Optional (ML anomaly model / post-quantum KEM). Skip cleanly if not installed.
for pkg in ("sklearn", "numpy", "pqcrypto"):
    try:
        d, b, h = collect_all(pkg)
        datas += d; binaries += b; hiddenimports += h
    except Exception:
        pass

# The app loads tool scripts dynamically — bundle every submodule explicitly.
hiddenimports += collect_submodules("scripts")
hiddenimports += collect_submodules("core")
hiddenimports += collect_submodules("ui")
hiddenimports += ["psutil"]

# Bundle the brand assets so the window icon resolves at runtime.
import os
for _a in ("logo.png", "logo_mark.png"):
    _p = os.path.join("assets", _a)
    if os.path.exists(_p):
        datas.append((_p, "assets"))

a = Analysis(
    ["main.py"],
    pathex=["."],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    runtime_hooks=[],
    excludes=["tkinter.test", "test", "pytest"],
    noarchive=False,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz, a.scripts, a.binaries, a.datas, [],
    name="ForceStack",
    icon="assets/logo_mark.ico",
    uac_admin=True,   # request elevation: hardening tools change system settings
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,          # GUI app (windowed)
    disable_windowed_traceback=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
