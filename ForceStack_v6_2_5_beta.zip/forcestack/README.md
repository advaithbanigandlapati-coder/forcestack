<p align="center">
  <img src="assets/logo.png" alt="ForceStack — Cybersecurity" width="300">
</p>

# ForceStack — Cybersecurity Defense Toolkit

> NIST SP 800-53 Rev 5 · 25 hardening tools (verify + rollback) · ML NGAV Sentinel Probe with optional in-kernel eBPF telemetry · Post-quantum Encryption Vault · Cross-platform · Built for everyone from teens to IT pros

---

## Quick Start

### Easiest — Windows (recommended for testers)

**Option A — just run it (no setup, no Python needed):** double-click
**`Start-ForceStack.bat`**. It works with **any Python 3.10+** already on the
machine, and if Python isn't installed it **installs it for you** (via winget,
or a silent download from python.org). Then it sets itself up automatically and
launches, asking for Administrator access because the hardening tools change
system settings. After the one-time setup it starts in seconds.

**Option B — a single .exe to hand out (no Python for testers):** double-click
**`build_windows.bat`** once. It produces **`dist\ForceStack.exe`** — a standalone
executable your testers can just double-click. No Python, no install; it
auto-requests Administrator and carries the app icon.

### Manual (Linux / macOS / advanced)

```bash
pip install -e ".[full]"     # or: pip install -e .   (lighter; probe/vault degrade gracefully)
python main.py               # Windows: run as Administrator
sudo python3 main.py         # Linux / macOS

python main.py --dry-run                 # preview, makes no changes
python main.py --headless --tool firewall_config   # headless / CI
```

---

## What's inside

**20 hardening tools** across System Hardening, Passwords & Accounts, Threat
Scanning, Network Security, and Compliance — each with plain-English "why it
matters" and step-by-step fixes.

**🛰 Sentinel Probe** — a lightweight, **ML-driven** behavioural sensor (NGAV)
that catches threats with *no known signature* (zero-day, polymorphic, fileless).
It turns each snapshot of processes, network connections, and your audit log into
a behavioural feature vector and scores it with an unsupervised anomaly model
(scikit-learn IsolationForest, or a pure-Python robust-statistics fallback) that
learns *this* machine's normal and explains which signals deviated. Four
explainable modules add agentic-threat tempo, fileless/memory tells, abuse of
trusted built-in tools ("living off the land"), and change-tracking. Responses
are defensive and reversible — suspend a process or quarantine a file (moved,
not deleted) — recorded in a durable rollback journal. An optional LLM triage
layer is off by default. It reports its own data footprint so "low-RAM" is
verifiable.

**🔐 Encryption Vault** — hybrid **post-quantum** encryption that protects
against "harvest now, decrypt later." Password mode (**Argon2id** + AES-256-GCM)
or keypair mode (**ML-KEM-768 + X25519**, mixed with HKDF-SHA256, then
AES-256-GCM), plus SHA-256 file verification. The post-quantum KEM runs on
PQClean's **constant-time** C implementation by default, and the UI tells you
honestly whether the live backend is production-grade. Files are encrypted in
authenticated streaming chunks (constant memory, truncation-proof) and the
entire container header is authenticated. Only standard, audited primitives —
nothing home-rolled.

**Built to be understood.** Every new page opens with a "What is this & why does
it matter?" card, with an optional deeper dive for the curious — so whether
you're a teenager securing a laptop or an IT admin running an audit, you can use
it *and* learn from it.

> Defense only. There are no offensive tools here.

## Requirements

| Dependency       | Version  | Purpose                     |
|-----------------|----------|-----------------------------|
| customtkinter   | ≥ 5.2.0  | Cross-platform dark UI      |
| psutil          | ≥ 5.9.0  | Port scanning / process info|
| pillow          | ≥ 10.0.0 | Image handling               |
| reportlab       | ≥ 4.0.0  | PDF report generation        |

```bash
pip install -e .                  # runtime
pip install -e ".[build]"         # PyInstaller (build only)
pip install -e ".[dev]"           # pytest, coverage (dev only)
```

---

## Building Executables

```bash
# Windows
build_windows.bat
# → dist/ForceStack.exe

# macOS / Linux
chmod +x build_unix.sh && ./build_unix.sh
# → dist/ForceStack
```

---

## Running Tests

```bash
pip install -e ".[dev]"
pytest tests/ -v
pytest tests/ --cov=core --cov-report=html
```

---

## Architecture

```
ForceStack_v3/
├── main.py                 Entry point: admin check, CLI flags, launches UI
├── core/
│   ├── tools.py            Canonical tool registry (ALL_TOOLS, TOOL_MAP)
│   ├── audit.py            Thread-safe JSON audit log (schema v3, HMAC-protected)
│   ├── constants.py        Palette, NIST mappings, safe path setup
│   ├── runner.py           Script execution engine (threading, dry-run)
│   ├── reporter.py         TXT + PDF report generation
│   └── utils.py            Shared run_cmd(), idempotency helpers
├── scripts/
│   ├── _base.py            Shared imports for all script modules
│   └── *.py                20 NIST-mapped hardening scripts
├── ui/
│   ├── app.py              Main application (glassmorphic enterprise UI)
│   ├── background.py       Animated mesh gradient canvas
│   ├── widgets.py          Glass cards, colored terminal, status dots
│   └── utils.py            DPI scaling, platform fonts, tooltips
└── tests/
    ├── conftest.py          Shared fixtures (audit_log, patched_audit_module)
    ├── test_audit.py        Audit log + HMAC tamper-protection tests
    ├── test_utils.py        run_cmd, already_applied, sudo_prefix tests
    ├── test_runner.py       Script execution engine tests
    ├── test_reporter.py     TXT/PDF report generation tests
    ├── test_scripts_dryrun.py  Return-type contract for all 20 scripts
    └── test_headless.py     Integration tests for headless CLI mode
```

---

## CLI Flags

| Flag                      | Description                                                        |
|---------------------------|--------------------------------------------------------------------|
| `--dry-run`               | Preview what each script would do, no system changes               |
| `--headless`              | Run all scripts without the GUI (CI/CD)                            |
| `--tool TOOL_ID`          | Run a single tool in headless mode                                 |
| `--list-tools`            | Print all available tool IDs and exit                              |
| `--json-output`           | Write headless results to stdout as JSON (tool_id, status, detail) |
| `--timeout-secs N`        | Screen lock idle timeout in seconds (overrides env var)            |
| `--min-pw-len N`          | Minimum password length (overrides env var)                        |
| `--max-pw-age N`          | Maximum password age in days (overrides env var)                   |
| `--version`               | Print version and exit                                             |

---

## NIST SP 800-53 Rev 5 Coverage

| Tool                       | Controls              | Risk     | Section     |
|----------------------------|-----------------------|----------|-------------|
| Disable Risky Services     | CM-7, AC-17, SI-3     | MEDIUM   | Hardening   |
| Configure Firewall         | SC-7, CA-3, AC-4      | LOW      | Hardening   |
| USB Lockdown               | MP-7, AC-19, SC-41    | MEDIUM   | Hardening   |
| Full-Disk Encryption Check | SC-28, SC-12, CP-9    | CRITICAL | Hardening   |
| Harden RDP / SSH           | AC-17, IA-2, SC-8     | HIGH     | Hardening   |
| Screen Lock Timeout        | AC-11, AC-12, IA-11   | LOW      | Hardening   |
| NIST Password Policy       | IA-5, IA-11, AC-2     | LOW      | Passwords   |
| Local Admin Auditor        | AC-2, AC-6, IA-4      | MEDIUM   | Passwords   |
| Disable Guest Account      | AC-2, AC-3, IA-2      | LOW      | Passwords   |
| Account Lockout Policy     | AC-7, SI-10, IA-5     | MEDIUM   | Passwords   |
| Enable Audit Logging       | AU-2, AU-3, AU-12     | LOW      | Scanning    |
| Open Ports Scanner         | CM-7, RA-5, SC-7      | MEDIUM   | Scanning    |
| Startup Items Auditor      | CM-7, SI-3, CM-8      | HIGH     | Scanning    |
| AV and EDR Status          | SI-3, SI-8, RA-5      | HIGH     | Scanning    |
| CVE Vulnerability Scanner  | RA-5, SI-2, CM-8      | HIGH     | Scanning    |
| DNS-over-HTTPS             | SC-20, SC-21, SC-22   | LOW      | Network     |
| Wi-Fi Security Audit       | SC-8, AC-18, SC-7     | MEDIUM   | Network     |
| Hosts File Blocklist       | SC-7, SI-3, SC-20     | LOW      | Network     |
| Automatic Updates          | SI-2, CM-3, SI-7      | MEDIUM   | Compliance  |
| TLS and SSL Hardening      | SC-8, SC-23, SC-17    | MEDIUM   | Compliance  |

**Control families covered:** AC, AU, CA, CM, CP, IA, MP, PE, RA, SC, SI (40+ controls)

---

## UI Features

- **Animated mesh gradient background** — deep indigo blobs drift slowly (Warp Terminal style)
- **Glassmorphic cards** — `#FFFFFF08` glass overlay, 1px white-edge border, hover transitions
- **Dashboard** — animated compliance ring, 2×2 stat grid, NIST chip cloud with tooltips, workflow with connecting lines
- **Run All page** — Warp-style sequential block log, per-tool colour bars, elapsed timer, floating stop bar
- **Tool detail pages** — drill-down navigation (Apple Settings pattern), full description, live terminal (inlined in `ui/app.py`)
- **Audit Log** — alternating row backgrounds, export CSV, proper empty states
- **Reports** — TXT and PDF, page numbers, NIST coverage matrix in both formats
- **Settings** — idle timeout, report dir, per-script enable/disable checkboxes
- **Keyboard shortcuts** — `Ctrl/Cmd+R` Run All, `+L` Log, `+G` Report, `+,` Settings, `?` Help overlay

---

## Data Locations

All runtime data is stored in `~/.forcestack/`:

| Path                            | Contents                                              |
|---------------------------------|-------------------------------------------------------|
| `~/.forcestack/audit.json`        | Persistent audit log (JSON schema v3, HMAC-protected) |
| `~/.forcestack/audit.key`         | 32-byte HMAC signing key (0600, owner only)           |
| `~/.forcestack/reports/`          | Generated TXT and PDF reports (0600 files, 0700 dir)  |
| `~/.forcestack/snapshots/`        | System state snapshots (0700 dir)                     |
| `~/.forcestack/app.log`           | Application error log                                 |
| `~/.forcestack/window_state.json` | Window size/position                                  |

---

## Uninstall

```bash
# Remove runtime data
rm -rf ~/.forcestack

# Remove dependencies
pip uninstall customtkinter psutil pillow reportlab
```

---

## Security Notes

- **Idempotent**: All scripts detect already-applied configuration and skip re-application
- **Air-gap safe**: TLS test (`tls_config.py`) skips gracefully on no-network machines
- **No telemetry**: No data leaves your machine
- **Audit trail**: Every script execution is recorded with timestamp, duration, NIST controls, and OS metadata. The log is HMAC-SHA256 protected — both per-entry and at file level — to detect tampering, deletion, and reordering. The signing key lives in `~/.forcestack/audit.key` (0600).
- **Schema versioned**: Audit log format is versioned (currently v3) with automatic migration from v1/v2

---

## License

**Proprietary — Beta Evaluation License. All rights reserved.**
This is **not** open source. Beta testers may evaluate it under the terms in
[LICENSE](LICENSE); see [BETA_TESTERS.md](BETA_TESTERS.md). No redistribution,
reverse-engineering, or commercial use.


## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `FORCESTACK_BUILD` | Build label shown in PDF report headers (max 32 chars, sanitized). Set this to your org name or deployment identifier. | `Enterprise` |
| `FORCESTACK_TIMEOUT_SECS` | Screen lock idle timeout override (seconds) | `600` |
| `FORCESTACK_MIN_PW_LEN` | Minimum password length override | `15` |
| `FORCESTACK_MAX_PW_AGE` | Maximum password age override (days) | `365` |

Example:
```bash
FORCESTACK_BUILD="ACME Corp v4.4" python main.py --headless --json-output
```

## Uninstall

**Linux / macOS:**
```bash
rm -rf ~/.forcestack
pip uninstall forcestack
```

**Windows:**
```cmd
rmdir /s /q %USERPROFILE%\.forcestack
pip uninstall forcestack
```
