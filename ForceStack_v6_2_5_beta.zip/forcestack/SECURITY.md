# Security Policy

## Supported Versions

| Version | Supported |
|---------|-----------|
| 3.x     | ✅ Active  |
| 2.x     | ❌ EOL     |

## Reporting a Vulnerability

ForceStack handles system-level hardening and audit data. Security issues
should be reported **privately** before public disclosure.

**Do NOT open a public GitHub issue for security vulnerabilities.**

### How to Report

1. Email: advaith.banigandlapati@gmail.com
2. Include: version, OS, reproduction steps, impact assessment
3. Expected response: acknowledgement within 48 hours

### Scope

- Remote code execution via crafted audit.json
- Privilege escalation via script execution
- Audit log tampering / HMAC bypass
- Information disclosure from ~/.forcestack/ permissions

## Known Limitations

| Area | Status |
|------|--------|
| Audit log HMAC tamper-protection | ✅ Implemented (schema v3) — per-entry + file-level HMAC-SHA256 |
| Report file permissions | ✅ Implemented — reports written 0600, dirs 0700 |
| Key storage | ⚠️ Key stored locally at `~/.forcestack/audit.key`; if the machine is compromised root can replace both key and log. Enterprise deployments should consider an external KMS. |

### Out of Scope

- Issues requiring physical access to the machine
- Social engineering
- Theoretical weaknesses without a proof of concept

## Disclosure Timeline

- Day 0: Report received
- Day 3: Severity assessment shared with reporter
- Day 30: Patch released (critical: Day 7)
- Day 37: Public disclosure
