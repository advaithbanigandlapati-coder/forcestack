# ForceStack — Security & Code Review (v5.3)

This is a review of the toolkit's *own* code for flaws — the kind of thing an
attacker or an auditor would look for in a security product. The good news:
the existing codebase was already careful. Below is what was checked, what was
found, and what was fixed.

## Method
Static review plus a full UI render test (every page instantiated under a
headless display) and the complete test suite (75 tests, all passing).

## Findings

### Fixed in this release
1. **`usb_lockdown.py` — unhandled `FileNotFoundError` (robustness).**
   When writing the udev rule on Linux, the code caught `PermissionError` but
   not a missing `/etc/udev/rules.d` directory (minimal systems / containers).
   That raised an uncaught exception. **Fix:** now catches `FileNotFoundError`
   and generic `OSError`, reports a clear message, and returns a clean failure
   instead of crashing the script thread. (Also removed the only failing test.)

### Reviewed — no action needed (already sound)
2. **No command injection surface.** No use of `shell=True`, `os.system`,
   `eval`, or `exec` anywhere. All subprocess calls pass argument *lists*, and
   `core/utils.run_cmd` centralises them with timeouts and exception capture.
3. **No hardcoded secrets.** The only literal URLs are router admin addresses
   in remediation text (`192.168.x.x`); no credentials or keys in source.
4. **Audit log integrity is real.** `core/audit.py` HMAC-signs every entry and
   the whole file (HMAC-SHA256), with the key stored `0o600`. Tampering,
   reordering, insertion, and deletion are all detected.
5. **Config directories are owner-only.** `~/.forcestack` and its subdirectories
   are created `0o700`; audit files `0o600`.
6. **Thread-safety is handled.** `ColorTerminal.append` marshals back to the UI
   thread; the audit log writes under a lock and snapshots before disk I/O.
7. **Windows elevation quoting.** `main.request_admin` correctly uses
   `subprocess.list2cmdline` (not POSIX `shlex.quote`) for `ShellExecuteW`.

## New code added in v5.3 — security posture
8. **`core/pqcrypto.py` uses only standard, audited primitives.** Nothing is
   home-rolled: AES-256-GCM, X25519, scrypt, HKDF-SHA256 (from `cryptography`)
   and ML-KEM-768 (FIPS 203, from `kyber-py`). Encryption is a genuine hybrid
   (post-quantum **and** classical secrets mixed via HKDF) so a break in either
   one alone does not expose data. Every container carries a SHA-256 integrity
   tag and AES-GCM authentication; wrong keys/passwords and tampering are
   rejected with clear errors (covered by tests).
9. **`core/probe.py` is defensive-only and fail-safe.** The sensor never
   attacks anything. Its most forceful action is to *suspend* (pause) a
   suspected process — reversible, never a delete — and only when the user has
   explicitly opted into autonomous mode, and only with admin/root. The
   optional AI triage layer is **off by default**, makes **no network calls**
   unless installed, and sends only structural signals (no file contents or
   personal data). A failure in any analyzer or module is swallowed so the
   sensor can never crash the host app.

## Residual notes (environment, not defects)
- The UI requires Tcl/Tk **8.7+** because it uses RGBA (`#RRGGBBAA`) colors;
  this ships with the bundled Tk on macOS/Windows and modern Linux. On an old
  Tk 8.6 the glass styling won't render. Not a security issue.
- Post-quantum mode needs `cryptography` + `kyber-py`. If absent, the vault
  says so plainly and disables the affected mode rather than pretending.
