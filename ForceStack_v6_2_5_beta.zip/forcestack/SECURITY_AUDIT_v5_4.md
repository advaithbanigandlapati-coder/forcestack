# ForceStack — Security Notes (v5.4)

This release closes the encryption and hardening issues raised in the v5.3
review. What changed, and the honest state of each.

## Encryption (`core/pqcrypto.py`, container v2)

Fixed
- **Reference-grade PQC → production.** ML-KEM-768 now runs on PQClean's
  constant-time C code (`pqcrypto`) by default. The pure-Python `kyber-py`
  remains only as an explicit, clearly-labelled evaluation fallback.
  `crypto_capabilities()["pqc_production_grade"]` reflects reality and the UI
  shows it.
- **Unauthenticated header → fully bound.** The whole header (algorithm, KDF
  params, salts, KEM ciphertext) is AES-GCM associated data. Editing any field
  fails decryption. (Test: `test_header_tamper_detected`.)
- **Plaintext-hash leak → removed.** No hash of the plaintext is stored in the
  container. (Test: `test_no_plaintext_hash_in_container`.)
- **Whole-file-in-RAM, GCM size ceiling → streaming.** Files encrypt as
  independently-authenticated 1 MiB chunks with per-chunk nonces and an
  end-of-stream marker; truncation and reordering are detected, memory is
  constant. (Tests: streaming round-trips + `test_streaming_truncation_detected`.)
- **scrypt → Argon2id** for password mode (memory-hard), parameters recorded
  per file; scrypt retained as an automatic fallback on older `cryptography`.

Construction (unchanged, still correct)
- Hybrid secret = ML-KEM-768 shared ⧺ X25519 shared → HKDF-SHA256 → AES-256-GCM.
  Breaking either KEM alone yields nothing.

Honest residual notes
- Private key bundles are emitted as base64 text for the user to store; the tool
  does not itself manage a key vault/HSM. Treat the private bundle like any
  secret. A future step could wrap it in password mode at rest.
- Nonces are random-prefixed per file with a 32-bit counter — safe for
  <2^32 chunks (4 PB at 1 MiB). Larger single files are rejected implicitly by
  running out of counter space; not a practical limit.

## Hardening toolkit (`core/hardening.py`)

Fixed
- **"OK" reported on silently-failed writes → verify-after-apply.** Registry
  changes are read back and only reported OK when the read-back matches.
- **No undo → durable rollback journal.** Prior registry values are captured;
  edited config files are backed up before the write. `revert()` restores the
  exact prior state (or removes a value/file that did not exist before).
  Journal is `~/.forcestack/rollback.json` (0600) with backups under `snapshots/`.
- Retrofitted the highest-impact state-changing scripts (RDP/SSH, screen lock,
  guest account, account lockout).

Still sound from v5.3
- No `shell=True` / `eval` / `os.system`; all subprocess calls use argument
  lists. Audit log remains HMAC-signed and tamper-evident.

Not yet done (tracked)
- The remaining scripts that shell out to OS tools (e.g. `firewall_config`,
  `dns_over_https`) don't yet journal rollback for their non-registry, non-file
  changes; those need per-tool "undo" commands. Framework is in place.
- UI: raw-widget glass colours use 8-digit RGBA hex, which needs Tcl/Tk 8.7+
  (or a flatten pass) to render — a UI-portability item, not a security one.
