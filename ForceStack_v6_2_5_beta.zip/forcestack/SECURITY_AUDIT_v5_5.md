# ForceStack — Sentinel Probe Notes (v5.5)

This closes the probe-specific honesty gaps raised in the v5.3 review. What is
now real, and what is still limited — stated plainly.

## Now real

- **It uses machine learning.** An unsupervised IsolationForest (scikit-learn)
  learns a per-machine baseline of behavioural feature vectors and scores new
  behaviour; a pure-Python robust z-score detector is the dependency-free
  fallback. This is the NGAV model, not if-statements. (The heuristic modules
  still exist, but as an explainable layer *on top of* the model.)
- **It doesn't cry wolf on normal machines.** The score is calibrated against
  the training distribution, so in-distribution behaviour scores low. Verified:
  idle run → anomaly ≈ 0.06, zero alerts; injected spike → ≥ 0.7, alerts.
- **The beaconing false positive is gone.** Detection now keys off connection
  *establishment* events, so a persistent connection can't masquerade as
  regular beaconing. (`test_persistent_connection_produces_one_event_not_many`.)
- **The RAM number is honest.** "Probe data footprint" measures the probe's own
  retained structures (~0.02 MB idle), not the whole process (~160 MB).
- **Rollback is real and shared.** Probe actions go to the same durable journal
  as hardening changes. Suspend↔resume, quarantine↔restore, and registry/file
  reverts all work through `revert_change()`. Quarantine moves a file aside; it
  never deletes.
- **Explainability.** Every ML alert names the top deviating features and their
  σ-distance from normal, so an operator can act on it.

## Honest limitations (unchanged realities of a userland sensor)

- **No kernel/hardware telemetry.** It samples via `psutil`; it does not use
  Intel TDT, ETW, eBPF, or memory tagging. The "MemoryDefense" signal is a
  deleted-executable heuristic, not hardware-assisted memory inspection.
- **Sampling cadence.** A ~4 s timer can miss very short-lived activity between
  samples. This is the trade for low overhead and no syscall hooking.
- **Privileges.** Full connection→PID mapping and process containment need
  admin/root; without it the network signals degrade gracefully.
- **The ML catches *deviation*, not *intent*.** A genuinely novel-but-benign
  workload (a new heavy build, a first-time backup job) can read as anomalous
  until the baseline adapts. It is a triage aid, not a verdict.
- **Autonomous containment stays opt-in** and only ever *suspends* (reversible),
  never kills, and only for high-severity findings with a PID.

## Recommended use

Treat the probe as a lightweight, explainable behavioural early-warning layer
that complements (does not replace) OS/EDR controls. Run it alongside the
hardening tools; review ML alerts using the feature explanations; use quarantine
and suspend as reversible first responses while you investigate.
