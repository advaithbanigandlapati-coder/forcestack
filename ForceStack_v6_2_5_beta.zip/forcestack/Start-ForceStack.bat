@echo off
setlocal EnableExtensions EnableDelayedExpansion
title ForceStack
cd /d "%~dp0"

REM ============================================================
REM  ForceStack launcher — works with any Python 3.10+, and
REM  installs Python automatically if you don't have it.
REM ============================================================

REM --- self-elevate to Administrator (hardening changes system settings) ---
net session >nul 2>&1
if !errorlevel! neq 0 (
    echo Requesting administrator access ^(needed to apply hardening^)...
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs" >nul 2>&1
    exit /b
)
cd /d "%~dp0"

REM --- find a suitable Python (>=3.10). Prefer versions with the best wheel
REM     support so the optional ML/PQC extras install without a compiler. ---
call :FIND_PYTHON
if not defined PY (
    echo.
    echo No suitable Python 3.10+ was found. Installing Python 3.12 ^(one-time^)...
    echo.
    where winget >nul 2>&1
    if !errorlevel! equ 0 (
        winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
    ) else (
        echo winget not available - downloading the official installer...
        powershell -NoProfile -ExecutionPolicy Bypass -Command "$u='https://www.python.org/ftp/python/3.12.8/python-3.12.8-amd64.exe'; $o=Join-Path $env:TEMP 'python-setup.exe'; Write-Host 'Downloading Python...'; Invoke-WebRequest -Uri $u -OutFile $o; Write-Host 'Installing Python (silent)...'; Start-Process -Wait -FilePath $o -ArgumentList '/quiet','InstallAllUsers=0','PrependPath=1','Include_launcher=1'"
    )
    call :FIND_PYTHON
    if not defined PY (
        echo.
        echo Python has been installed, but this window needs to reload your PATH.
        echo   ^>^>  Please double-click Start-ForceStack.bat ONE more time to finish.  ^<^<
        echo.
        pause & exit /b 0
    )
)

echo Using: & %PY% --version

REM --- create the private environment if it isn't there yet ---
if not exist ".venv\Scripts\python.exe" (
    echo Setting up ForceStack ^(one-time^)...
    %PY% -m venv .venv || ( echo Could not create environment. & pause & exit /b 1 )
)
call ".venv\Scripts\activate.bat"

REM --- ensure dependencies actually import (self-heals a partial setup) ---
python -c "import customtkinter, psutil, reportlab, cryptography" 2>nul
if !errorlevel! neq 0 (
    echo Installing dependencies ^(first run, ~1-2 minutes^)...
    python -m pip install --upgrade pip >nul
    python -m pip install -e . || ( echo Dependency install failed. & pause & exit /b 1 )
    REM optional ML probe + post-quantum crypto: nice to have, safe to skip if no wheel
    python -m pip install "scikit-learn>=1.3" "numpy>=1.24" "pqcrypto>=0.3" 2>nul
)

python -c "import customtkinter" 2>nul || ( echo Setup incomplete. Delete the .venv folder and run again. & pause & exit /b 1 )

echo Launching ForceStack...
python main.py %*
if !errorlevel! neq 0 (
    echo.
    echo ForceStack exited with an error. Copy the text above if you report a bug.
    pause
)
exit /b

REM ---- helper: locate a Python >=3.10, preferring 3.13/3.12/3.11/3.10, then any ----
:FIND_PYTHON
set "PY="
for %%V in (3.13 3.12 3.11 3.10 3.14 3.15) do (
    if not defined PY ( py -%%V -c "import sys" >nul 2>&1 && set "PY=py -%%V" )
)
if not defined PY ( py -3 -c "import sys" >nul 2>&1 && set "PY=py -3" )
if not defined PY ( python -c "import sys" >nul 2>&1 && set "PY=python" )
REM reject anything older than 3.10
if defined PY (
    %PY% -c "import sys; sys.exit(0 if sys.version_info>=(3,10) else 1)" >nul 2>&1 || set "PY="
)
exit /b
