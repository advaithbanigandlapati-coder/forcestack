#!/bin/bash
# ForceStack — Unix build (macOS / Linux)
set -e
echo "ForceStack — Unix Build"

# Purge stale bytecode so PyInstaller doesn't bundle .pyc from another Python.
find . -type d -name __pycache__ -exec rm -rf {} + 2>/dev/null || true
find . -name "*.pyc" -delete 2>/dev/null || true

# Install the app with the full (ML + PQC) and build extras.
python3 -m pip install --upgrade pip
python3 -m pip install -e ".[full,build]"

# Build using the maintained spec (handles dynamic script loading + heavy deps).
pyinstaller --clean --noconfirm ForceStack.spec

echo "Build complete: dist/ForceStack"
