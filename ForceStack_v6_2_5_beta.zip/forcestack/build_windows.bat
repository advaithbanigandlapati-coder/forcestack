@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Build ForceStack.exe
cd /d "%~dp0"
echo === Building a standalone ForceStack.exe (no Python needed to run it) ===
echo.

REM --- find a suitable Python (>=3.10), preferring best wheel support ---
set "PY="
for %%V in (3.13 3.12 3.11 3.10 3.14 3.15) do (
    if not defined PY ( py -%%V -c "import sys" >nul 2>&1 && set "PY=py -%%V" )
)
if not defined PY ( py -3 -c "import sys" >nul 2>&1 && set "PY=py -3" )
if not defined PY ( python -c "import sys" >nul 2>&1 && set "PY=python" )
if not defined PY (
    echo Python 3.10+ is required to BUILD the exe.
    echo Install it from https://www.python.org/downloads/ ^(check "Add to PATH"^),
    echo or just run Start-ForceStack.bat which can install Python for you.
    pause & exit /b 1
)
echo Using: & %PY% --version

if not exist ".buildenv\Scripts\python.exe" (
    %PY% -m venv .buildenv || ( echo venv failed & pause & exit /b 1 )
)
call ".buildenv\Scripts\activate.bat"
python -m pip install --upgrade pip
python -m pip install -e ".[build]" || ( echo dependency install failed & pause & exit /b 1 )
python -m pip install "scikit-learn>=1.3" "numpy>=1.24" "pqcrypto>=0.3" 2>nul
pyinstaller --clean --noconfirm ForceStack.spec || ( echo build failed & pause & exit /b 1 )

echo.
echo ============================================================
echo  Done. Give your testers this single file (no Python needed):
echo     %cd%\dist\ForceStack.exe
echo ============================================================
pause
