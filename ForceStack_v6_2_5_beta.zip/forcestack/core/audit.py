"""
core/audit.py — Thread-safe persistent audit log with HMAC tamper-protection.
Issues fixed: #11 (misleading comment), #12 (nist join guard), #13 (circular dep),
              #15 (copy under lock in reporter), #84 (0600 file permissions),
              #1  (HMAC tamper-protection — implemented)

Tamper-protection design
────────────────────────
Each entry carries an ``"hmac"`` field: HMAC-SHA256 computed over the
canonical JSON of that entry (all fields except ``"hmac"`` itself, sorted
keys, no extra whitespace).  The saved file also carries a top-level
``"file_hmac"``: HMAC-SHA256 over the ordered list of every per-entry HMAC
digest.  This means:

  • Editing any field in an entry       → per-entry HMAC fails
  • Deleting / inserting / reordering   → file-level HMAC fails
  • Copying a valid entry from elsewhere → file-level HMAC fails

The HMAC key (32 random bytes, hex-encoded) is stored in
``~/.forcestack/audit.key`` with 0o600 permissions and is generated on first
run.  If the key file is lost or corrupted, a new key is generated; all
existing entries will then fail verification (expected — we can no longer
authenticate what we signed before).

Old schema-v1 (bare list) and schema-v2 entries are back-signed with the
current key on first load, giving them a clean baseline going forward.
"""

from __future__ import annotations
import hashlib
import hmac as _hmac
import json
import csv
import os
import threading
import datetime
import logging
from typing import Any, Optional

from core.constants import (
    AUDIT_FILE, AUDIT_KEY_FILE, APP_VERSION, OS_NAME,
    CURRENT_USER, HOSTNAME, NIST_MAP,
)

log = logging.getLogger("forcestack")

SCHEMA_VERSION = 3
MAX_ENTRIES    = 10_000


class AuditLog:
    def __init__(self):
        self._lock   = threading.Lock()
        self.entries: list[dict[str, Any]] = []
        self._index:  dict[str, dict] = {}   # tool_id → most recent entry (O(1) lookup)
        self._key    = self._load_or_create_key()
        self._load()

    # ── Key management ────────────────────────────────────────────────────────

    def _load_or_create_key(self) -> bytes:
        """
        Load the 32-byte HMAC key from disk, or generate and persist a new one.
        The key file is written with 0o600 permissions (owner read/write only).
        """
        if AUDIT_KEY_FILE.exists():
            try:
                raw = AUDIT_KEY_FILE.read_text(encoding="utf-8").strip()
                key = bytes.fromhex(raw)
                if len(key) == 32:
                    return key
                log.warning("audit key has unexpected length %d, regenerating", len(key))
            except Exception as e:
                log.warning("audit key load failed (%s), regenerating", e)

        key = os.urandom(32)
        try:
            fd = os.open(
                str(AUDIT_KEY_FILE),
                os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
                0o600,
            )
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(key.hex())
            # belt-and-suspenders: ensure permissions are correct after rename
            os.chmod(str(AUDIT_KEY_FILE), 0o600)
        except Exception as e:
            log.error("audit key save failed: %s", e)
        return key

    # ── HMAC helpers ──────────────────────────────────────────────────────────

    def _entry_hmac(self, entry: dict) -> str:
        """
        HMAC-SHA256 of the canonical form of *entry*, excluding the stored
        ``"hmac"`` field so the digest is self-consistent.
        """
        canonical = {k: v for k, v in entry.items() if k != "hmac"}
        msg = json.dumps(canonical, sort_keys=True, separators=(",", ":"), default=str)
        return _hmac.new(self._key, msg.encode(), hashlib.sha256).hexdigest()

    def _file_hmac(self, entries: list[dict]) -> str:
        """
        HMAC-SHA256 over the ordered sequence of per-entry HMAC digests.
        Detects entry deletion, insertion, and reordering without re-hashing
        every entry's full payload.
        """
        digests = [e.get("hmac", "") for e in entries]
        msg = json.dumps(digests, separators=(",", ":")).encode()
        return _hmac.new(self._key, msg, hashlib.sha256).hexdigest()

    def _sign_entry(self, entry: dict) -> dict:
        """Add (or refresh) the ``"hmac"`` field on *entry* in-place."""
        entry["hmac"] = self._entry_hmac(entry)
        return entry

    def _sign_entries(self, entries: list[dict]) -> None:
        """Sign every entry in *entries* in-place (used during migration)."""
        for entry in entries:
            self._sign_entry(entry)

    # ── Verification ──────────────────────────────────────────────────────────

    def _verify_entries(self, entries: list[dict], stored_file_hmac: str) -> list[dict]:
        """
        Verify per-entry HMACs and the file-level HMAC.

        Tampered entries are marked with ``"_tampered": True`` so callers can
        distinguish them from clean entries without us silently dropping data.
        Returns the (possibly annotated) entry list.
        """
        tamper_count = 0
        for entry in entries:
            stored = entry.get("hmac", "")
            if not stored:
                # Unsigned entry (e.g. injected without the key).
                entry["_tampered"] = True
                tamper_count += 1
            else:
                expected = self._entry_hmac(entry)
                if not _hmac.compare_digest(stored, expected):
                    entry["_tampered"] = True
                    tamper_count += 1

        if tamper_count:
            log.warning(
                "audit: %d entr%s failed HMAC verification — possible tampering",
                tamper_count,
                "y" if tamper_count == 1 else "ies",
            )

        # File-level check — catches add/delete/reorder even when all
        # individual entry HMACs look clean (e.g. attacker copies a valid entry).
        if stored_file_hmac:
            expected_fhmac = self._file_hmac(entries)
            if not _hmac.compare_digest(stored_file_hmac, expected_fhmac):
                log.warning(
                    "audit: file-level HMAC mismatch — "
                    "entries may have been added, removed, or reordered"
                )

        return entries

    def verify_integrity(self) -> dict:
        """
        Re-verify all in-memory entries and the persisted file HMAC.

        Returns a summary dict::

            {
              "total":        int,   # total entries examined
              "ok":           int,   # entries whose HMAC verified
              "tampered":     int,   # entries with a bad HMAC
              "unsigned":     int,   # entries with no HMAC field
              "file_hmac_ok": bool,  # whether the file-level HMAC verified
            }

        This is safe to call at any time; it does not modify any state.
        """
        with self._lock:
            entries = list(self.entries)

        total = len(entries)
        ok = tampered = unsigned = 0
        for entry in entries:
            stored = entry.get("hmac", "")
            if not stored:
                unsigned += 1
            elif _hmac.compare_digest(stored, self._entry_hmac(entry)):
                ok += 1
            else:
                tampered += 1

        file_hmac_ok = False
        try:
            with open(AUDIT_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            stored_fhmac = data.get("file_hmac", "")
            if stored_fhmac:
                expected_fhmac = self._file_hmac(data.get("entries", []))
                file_hmac_ok = _hmac.compare_digest(stored_fhmac, expected_fhmac)
        except Exception as e:
            log.debug("verify_integrity: could not read audit file: %s", e)

        return {
            "total":        total,
            "ok":           ok,
            "tampered":     tampered,
            "unsigned":     unsigned,
            "file_hmac_ok": file_hmac_ok,
        }

    # ── I/O ──────────────────────────────────────────────────────────────────

    def _load(self) -> None:
        if not AUDIT_FILE.exists():
            return
        try:
            with open(AUDIT_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)

            if isinstance(data, list):
                # Schema v1 (bare list) — back-sign everything and re-save as v3.
                entries = data[:MAX_ENTRIES]
                self._sign_entries(entries)
                self.entries = entries
                self._rebuild_index()
                self._save()
                return

            if not isinstance(data, dict):
                self.entries = []
                self._rebuild_index()
                return

            schema = data.get("schema")

            if schema == SCHEMA_VERSION:
                # Current format — verify and load.
                entries = data.get("entries", [])[:MAX_ENTRIES]
                self.entries = self._verify_entries(entries, data.get("file_hmac", ""))

            elif schema == 2:
                # Schema v2 — back-sign to establish a clean HMAC baseline and
                # re-save as v3.  No tampering check is possible for unsigned
                # entries, so we trust them on this one migration pass.
                entries = data.get("entries", [])[:MAX_ENTRIES]
                self._sign_entries(entries)
                self.entries = entries
                self._rebuild_index()
                self._save()
                return

            else:
                log.warning("audit: unknown schema %r, starting fresh", schema)
                self.entries = []

            self._rebuild_index()

        except Exception as e:
            log.warning("audit load failed: %s", e)
            self.entries = []

    def _save(self, entries_snapshot: list | None = None) -> None:
        """
        Write audit entries to disk atomically.
        If entries_snapshot is provided (from record() which releases the lock
        before calling), use it. Otherwise fall back to self.entries for callers
        that already hold _lock.
        Fix #58: record() now passes a snapshot so the disk write happens outside
        the lock, eliminating the contention window that blocked concurrent reads.
        """
        entries = entries_snapshot if entries_snapshot is not None else self.entries
        try:
            # Attach file-level HMAC before serialising.
            file_hmac = self._file_hmac(entries)
            payload = {
                "schema":    SCHEMA_VERSION,
                "file_hmac": file_hmac,
                "entries":   entries,
            }
            tmp = AUDIT_FILE.with_suffix(".tmp")
            # Fix #84: write with 0600 permissions (owner-read/write only)
            fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2, default=str)
            tmp.replace(AUDIT_FILE)
            # Belt-and-suspenders: ensure final file is also 0600
            try:
                os.chmod(str(AUDIT_FILE), 0o600)
            except OSError:
                pass
        except Exception as e:
            log.error("audit save failed: %s", e)

    def _rebuild_index(self) -> None:
        """
        Fix #11: comment was inverted.
        entries[0] is newest. We iterate oldest-first (reversed) so the
        LAST dict-assignment for each tool_id ends up being the MOST RECENT entry.
        """
        self._index = {}
        for entry in reversed(self.entries):   # oldest → newest; last write = most recent
            self._index[entry.get("tool_id", "")] = entry

    def snapshot_entries(self) -> list[dict]:
        """
        Fix #15: thread-safe copy for use by reporter without holding the lock
        during the entire rendering pass.
        """
        with self._lock:
            return list(self.entries)

    # ── Record ───────────────────────────────────────────────────────────────
    def record(
        self,
        tool_id: str,
        tool_name: str,
        status: str,
        detail: str = "",
        duration_s: float = 0.0,
    ) -> dict:
        nist = NIST_MAP.get(tool_id, [])
        entry: dict[str, Any] = {
            "schema_ver": SCHEMA_VERSION,
            "timestamp":  datetime.datetime.now().isoformat(timespec="seconds"),
            "tool_id":    tool_id,
            "tool_name":  tool_name,
            "status":     status,
            "detail":     detail,
            "duration_s": round(duration_s, 2),
            "nist":       nist,
            "os":         OS_NAME,
            "hostname":   HOSTNAME,
            "user":       CURRENT_USER,
            "app_ver":    APP_VERSION,
        }
        # Sign before inserting so the HMAC covers all fields above.
        self._sign_entry(entry)
        with self._lock:
            self.entries.insert(0, entry)
            if len(self.entries) > MAX_ENTRIES:
                self.entries = self.entries[:MAX_ENTRIES]
            self._index[tool_id] = entry
            # Fix #58: snapshot the data needed for _save while under the lock,
            # then write to disk outside it. Prevents concurrent reads (last_run,
            # stats, get_entries) from blocking for the duration of the file write.
            entries_snapshot = list(self.entries)
        # Disk write outside the lock — readers unblocked immediately after insert.
        self._save(entries_snapshot)
        return entry

    # ── Query ─────────────────────────────────────────────────────────────────
    def last_run(self, tool_id: str) -> Optional[dict]:
        """O(1) lookup via in-memory index."""
        return self._index.get(tool_id)

    def stats(self) -> dict:
        """Single-pass stats."""
        total = success = errors = warnings = 0
        for e in self.entries:
            total += 1
            s = e.get("status", "")
            if s == "success":   success  += 1
            elif s == "error":   errors   += 1
            elif s == "warning": warnings += 1
        return {"total": total, "success": success, "errors": errors, "warnings": warnings}

    def compliance_score(self, total_tools: int) -> int:
        """
        Fix #13: accepts total_tools as parameter instead of importing ALL_TOOLS
        here (which created a core.tools → core.audit → core.tools circular dep).
        """
        if not self._index or total_tools == 0:
            return 0
        passing = sum(
            1 for entry in self._index.values()
            if entry.get("status") == "success"
        )
        return int(min(passing, total_tools) / total_tools * 100)

    def get_entries(
        self,
        tool_id:  Optional[str]  = None,
        status:   Optional[str]  = None,
        limit:    Optional[int]  = None,
    ) -> list[dict]:
        """
        Fix #16: filtering API so callers don't slice entries directly.
        """
        result = [
            e for e in self.entries
            if (tool_id is None or e.get("tool_id") == tool_id)
            and (status is None or e.get("status") == status)
        ]
        if limit:
            result = result[:limit]
        return result

    # ── Export ────────────────────────────────────────────────────────────────
    def export_csv(self, path: str) -> None:
        fields = [
            "timestamp", "tool_id", "tool_name", "status", "detail",
            "duration_s", "nist", "os", "hostname", "user", "app_ver",
        ]
        try:
            with open(path, "w", newline="", encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
                w.writeheader()
                for e in self.entries:
                    row = dict(e)
                    # Fix #12: guard against v1 entries where nist may be a string
                    nist = e.get("nist", [])
                    row["nist"] = ", ".join(nist) if isinstance(nist, list) else str(nist)
                    w.writerow(row)
        except PermissionError as e:
            raise PermissionError(f"Cannot write to {path}: {e}") from e
        except OSError as e:
            raise OSError(f"Export failed: {e}") from e

    def clear(self) -> None:
        with self._lock:
            self.entries = []
            self._index  = {}
            self._save()


# Singleton
audit = AuditLog()
