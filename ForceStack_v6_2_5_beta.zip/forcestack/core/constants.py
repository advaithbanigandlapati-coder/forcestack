"""
core/constants.py — App-wide constants, palette, NIST mappings, safe path setup.
Issues fixed: #20 (APP_BUILD sanitized), #21 (CURRENT_USER sentinel)
"""

from __future__ import annotations
import platform
import os
import re
import logging
from pathlib import Path

log = logging.getLogger("forcestack")

# ── App Meta ──────────────────────────────────────────────────────────────────
APP_NAME    = "ForceStack"
APP_VERSION = "6.2.5-beta"

# Fix #20: sanitize env var so it can't inject content into PDF headers
_raw_build   = os.environ.get("FORCESTACK_BUILD", "Enterprise")
APP_BUILD    = re.sub(r"[^\w\s\-.]", "", _raw_build)[:32] or "Enterprise"

OS_NAME      = platform.system()
HOSTNAME     = platform.node() or "<unknown>"  # fix #21: guard against empty string in containers

# Fix #21: use sentinel "<unknown>" so it's distinguishable from a real username
CURRENT_USER = os.getenv("USERNAME") or os.getenv("USER") or ""
if not CURRENT_USER:
    log.warning("Could not determine current user from environment")
    CURRENT_USER = "<unknown>"

# ── Paths ─────────────────────────────────────────────────────────────────────
BASE_DIR     = Path(__file__).parent.parent
CONFIG_DIR   = Path.home() / ".forcestack"

# One-time migration: the app was formerly "PyToolCS" and stored data in
# ~/.pytoolcs. If that legacy directory exists and the new one doesn't yet,
# move it across so audit logs, the rollback journal, snapshots and config are
# preserved across the rename.
_LEGACY_DIR = Path.home() / ".pytoolcs"
if _LEGACY_DIR.exists() and not CONFIG_DIR.exists():
    try:
        _LEGACY_DIR.rename(CONFIG_DIR)
    except OSError:
        pass

AUDIT_FILE    = CONFIG_DIR / "audit.json"
AUDIT_KEY_FILE = CONFIG_DIR / "audit.key"
SNAPSHOT_DIR  = CONFIG_DIR / "snapshots"
REPORTS_DIR  = CONFIG_DIR / "reports"
LOG_FILE     = CONFIG_DIR / "app.log"
WINDOW_STATE  = CONFIG_DIR / "window_state.json"
ONBOARD_STATE = CONFIG_DIR / "onboarded"   # sentinel file — exists after first-run wizard


CONFIG_FILE  = CONFIG_DIR / "config.json"


def _load_config() -> None:
    """
    Fix #18: load ~/.forcestack/config.json for headless/enterprise use.
    Config values are applied as environment variable overrides so scripts
    can read them without changing their signatures. CLI flags take precedence
    over config file values (callers set os.environ BEFORE _load_config runs
    if they want CLI to win — we use setdefault here so existing env vars win).

    Supported keys:
      timeout_secs   (int)       — screen lock idle timeout
      min_pw_len     (int)       — minimum password length
      max_pw_age     (int)       — maximum password age in days
      build          (str)       — overrides FORCESTACK_BUILD
      disabled_tools (list[str]) — tool IDs excluded from Run All
      reports_dir    (str)       — override default report output directory
    """
    if not CONFIG_FILE.exists():
        return
    try:
        import json as _json
        cfg = _json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        mapping = {
            "timeout_secs": "FORCESTACK_TIMEOUT_SECS",
            "min_pw_len":   "FORCESTACK_MIN_PW_LEN",
            "max_pw_age":   "FORCESTACK_MAX_PW_AGE",
            "build":        "FORCESTACK_BUILD",
        }
        import os as _os
        for key, env_var in mapping.items():
            if key in cfg:
                _os.environ.setdefault(env_var, str(cfg[key]))
    except Exception as e:
        log.warning("config.json load failed: %s", e)


def load_config_dict() -> dict:
    """
    Return the raw config.json dict, or {} if not present / unreadable.
    Used by the Settings UI to populate fields with current saved values.
    Fix #59: settings page reads saved values rather than hardcoded defaults.
    """
    import json as _json
    if not CONFIG_FILE.exists():
        return {}
    try:
        return _json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_config(updates: dict) -> None:
    """
    Merge updates into config.json atomically.
    Fix #59: settings page persists values here; runner and scripts pick them
    up on next launch via _load_config → os.environ.setdefault.
    """
    import json as _json
    existing = load_config_dict()
    existing.update(updates)
    tmp = CONFIG_FILE.with_suffix(".tmp")
    try:
        tmp.write_text(_json.dumps(existing, indent=2), encoding="utf-8")
        tmp.replace(CONFIG_FILE)
    except Exception as e:
        log.error("config save failed: %s", e)


_load_config()


def _safe_mkdirs() -> None:
    """Create config directories without crashing on permission errors.
    Directories are restricted to 0o700 (owner-only) so reports and snapshots
    are not world-readable even if the user has a permissive umask.
    """
    for d in [CONFIG_DIR, SNAPSHOT_DIR, REPORTS_DIR]:
        try:
            d.mkdir(parents=True, exist_ok=True)
            try:
                os.chmod(str(d), 0o700)
            except OSError:
                pass
        except OSError as e:
            log.warning("Cannot create config dir %s: %s", d, e)


_safe_mkdirs()

# ── Colour Palette ────────────────────────────────────────────────────────────
# Tk portability: standard Tcl/Tk (8.6) rejects 8-digit #RRGGBBAA colours, which
# crashes raw tk widgets. We composite any alpha over a base background into a
# valid #RRGGBB at load time, and make palette values flatten automatically when
# an alpha suffix is appended (e.g. C["accent"] + "18"), so no call site changes
# and the UI renders on every Tk version.
_FLATTEN_BASE = "#070A12"


def _flatten(color: str, base: str = _FLATTEN_BASE) -> str:
    """Composite an #RRGGBBAA colour over `base`, returning Tk-safe #RRGGBB."""
    if not (isinstance(color, str) and color.startswith("#") and len(color) == 9):
        return color
    try:
        r, g, b, a = (int(color[i:i + 2], 16) for i in (1, 3, 5, 7))
        br, bg, bb = (int(base[i:i + 2], 16) for i in (1, 3, 5))
    except ValueError:
        return color[:7]  # drop alpha if unparseable
    af = a / 255.0
    def mix(fg, bgc):
        return round(fg * af + bgc * (1 - af))
    return "#%02X%02X%02X" % (mix(r, br), mix(g, bg), mix(b, bb))


class _Color(str):
    """A hex colour that flattens alpha when a 2-hex-digit alpha is appended."""
    __slots__ = ()

    def __add__(self, other):
        if (isinstance(other, str) and len(other) == 2
                and self.startswith("#") and len(self) == 7):
            try:
                int(other, 16)
                return _flatten(str.__add__(self, other))
            except ValueError:
                pass
        return str.__add__(self, other)


C = {
    # Backgrounds
    "bg0":      "#070A12",
    "bg1":      "#0B1221",
    "bg2":      "#0F1A2E",
    "bg3":      "#142236",
    "bg4":      "#1A2D47",
    "bg5":      "#1F3558",
    # Glass overlays
    "glass":    "#FFFFFF08",
    "glass_h":  "#FFFFFF12",
    "glass_b":  "#FFFFFF14",
    "glass_bh": "#00D4C050",
    # Borders
    "border":   "#1E304D",
    "border2":  "#263D61",
    # Accents
    "accent":   "#00D4C0",
    "accent2":  "#0EA5E9",
    "adim":     "#009B8F",
    "a2dim":    "#0887C4",
    "indigo":   "#6366F1",
    "indigo_d": "#4F52D4",
    # Semantic
    "green":    "#22D3A0",
    "yellow":   "#FBBF24",
    "orange":   "#FB923C",
    "red":      "#F87171",
    "purple":   "#A78BFA",
    # Text (WCAG AA on bg3)
    "t1":       "#E4EEF8",
    "t2":       "#7A9FBF",
    "t3":       "#4A6A8B",
    "t4":       "#1E3048",
    # Terminal
    "term_bg":  "#040710",
    "term_fg":  "#00D4C0",
    "term_ok":  "#22D3A0",
    "term_err": "#F87171",
    "term_warn":"#FBBF24",
    "term_inf": "#7A9FBF",
}

# Flatten any 8-digit entries and wrap every value so appended alpha flattens too.
C = {k: _Color(_flatten(v)) for k, v in C.items()}

# Accessibility: a high-contrast override for low-vision readability, toggled in
# Settings → Accessibility. Brightens the text tiers and borders (WCAG-oriented).
try:
    if load_config_dict().get("high_contrast"):
        _HC = {
            "t1": "#FFFFFF", "t2": "#E4EEF8", "t3": "#C4D6E8", "t4": "#9FBAD2",
            "border": "#4A6A8B", "border_bright": "#5F82A8",
            "term_fg": "#FFFFFF",
        }
        for _k, _v in _HC.items():
            if _k in C:
                C[_k] = _Color(_v)
except Exception:
    pass

# ── NIST SP 800-53 Rev 5 ──────────────────────────────────────────────────────
NIST_MAP: dict[str, list[str]] = {
    "disable_services":  ["CM-7",  "AC-17", "SI-3"],
    "firewall_config":   ["SC-7",  "CA-3",  "AC-4"],
    "usb_lockdown":      ["MP-7",  "AC-19", "SC-41"],
    "encryption_check":  ["SC-28", "SC-12", "CP-9"],
    "rdp_hardening":     ["AC-17", "IA-2",  "SC-8"],
    "screen_lock":       ["AC-11", "AC-12", "IA-11"],
    "nist_password":     ["IA-5",  "IA-11", "AC-2"],
    "admin_audit":       ["AC-2",  "AC-6",  "IA-4"],
    "guest_disable":     ["AC-2",  "AC-3",  "IA-2"],
    "account_lockout":   ["AC-7",  "SI-10", "IA-5"],
    "audit_logging":     ["AU-2",  "AU-3",  "AU-12"],
    "open_ports":        ["CM-7",  "RA-5",  "SC-7"],
    "startup_audit":     ["CM-7",  "SI-3",  "CM-8"],
    "av_status":         ["SI-3",  "SI-8",  "RA-5"],
    "cve_scan":          ["RA-5",  "SI-2",  "CM-8"],
    "dns_over_https":    ["SC-20", "SC-21", "SC-22"],
    "wifi_security":     ["SC-8",  "AC-18", "SC-7"],
    "hosts_blocklist":   ["SC-7",  "SI-3",  "SC-20"],
    "auto_updates":      ["SI-2",  "CM-3",  "SI-7"],
    "tls_config":        ["SC-8",  "SC-23", "SC-17"],
    # Advanced hardening superscripts
    "kernel_hardening":       ["SC-7",  "SI-3",  "CM-7"],
    "smb_protocol_lockdown":  ["CM-7",  "SC-8",  "AC-17"],
    "credential_protection":  ["IA-5",  "AC-3",  "AC-6"],
    "exec_logging":           ["AU-2",  "AU-12", "SI-4"],
    "filesystem_hardening":   ["CM-7",  "MP-7",  "SC-18"],
}

NIST_CONTROL_NAMES: dict[str, str] = {
    "AC-2":  "Account Management",
    "AC-3":  "Access Enforcement",
    "AC-4":  "Information Flow Enforcement",
    "AC-6":  "Least Privilege",
    "AC-7":  "Unsuccessful Logon Attempts",
    "AC-11": "Session Lock",
    "AC-12": "Session Termination",
    "AC-17": "Remote Access",
    "AC-18": "Wireless Access",
    "AC-19": "Access Control for Mobile Devices",
    "AU-2":  "Event Logging",
    "AU-3":  "Content of Audit Records",
    "AU-12": "Audit Record Generation",
    "CA-3":  "Information Exchange",
    "CM-3":  "Configuration Change Control",
    "CM-7":  "Least Functionality",
    "CM-8":  "System Component Inventory",
    "CP-9":  "System Backup",
    "IA-2":  "Identification and Authentication",
    "IA-4":  "Identifier Management",
    "IA-5":  "Authenticator Management",
    "IA-11": "Re-Authentication",
    "MP-7":  "Media Use",
    "RA-5":  "Vulnerability Monitoring and Scanning",
    "SC-7":  "Boundary Protection",
    "SC-8":  "Transmission Confidentiality and Integrity",
    "SC-12": "Cryptographic Key Establishment and Management",
    "SC-17": "Public Key Infrastructure Certificates",
    "SC-18": "Mobile Code",
    "SC-20": "Secure Name/Address Resolution (Authoritative)",
    "SC-21": "Secure Name/Address Resolution (Recursive)",
    "SC-22": "Architecture and Provisioning for Name/Address Resolution",
    "SC-23": "Session Authenticity",
    "SC-28": "Protection of Information at Rest",
    "SC-41": "Port and I/O Device Access",    "SI-2":  "Flaw Remediation",
    "SI-4":  "System Monitoring",
    "SI-3":  "Malicious Code Protection",
    "SI-7":  "Software, Firmware, and Information Integrity",
    "SI-8":  "Spam Protection",
    "SI-10": "Information Input Validation",
}
