"""
core/eventsource.py — event-driven, kernel-sourced process telemetry.

WHY
───
The probe's baseline design polls with psutil, which has two honest weaknesses:
it can miss processes that start and finish between samples, and psutil is a
userland vantage point. This module narrows that gap WITHOUT a kernel driver by
consuming the event streams the OS already exposes to userland:

  • Linux: the kernel **netlink proc connector** (CN_IDX_PROC) pushes
    fork/exec/exit events as they happen — no polling, sourced from the kernel.
    Requires CAP_NET_ADMIN (root).
  • Windows: a **WMI** subscription to Win32_ProcessStartTrace delivers
    process-start events via the OS (implemented as a best-effort backend).

This is NOT a replacement for kernel EDR (CrowdStrike/Defender live in the
kernel and can inline-block; hardware telemetry like Intel TDT is not reachable
from Python). It is an honest step from "polling only" to "event-driven where
the OS lets us", and it is strictly FAIL-SAFE: if a source can't start or
delivers nothing, the probe stays on polling and says so. A source is only
reported active once it has actually received an event — so the probe never
claims a capability it isn't getting.
"""

from __future__ import annotations

import json
import os
import platform
import shutil
import socket
import struct
import subprocess
import threading
import time
from pathlib import Path
from typing import Callable, Optional

_OS = platform.system()

# netlink proc connector constants (Linux)
_NETLINK_CONNECTOR = 11
_CN_IDX_PROC = 1
_PROC_CN_MCAST_LISTEN = 1
_PROC_EVENT_FORK = 0x00000001
_PROC_EVENT_EXEC = 0x00000002
_PROC_EVENT_EXIT = 0x80000000


class ProcessEventSource:
    """Best-effort event-driven process telemetry. Fail-safe by construction."""

    def __init__(self):
        self.kind = "none"
        self.events_received = 0
        self._on_event: Optional[Callable[[dict], None]] = None
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._sock = None
        self._proc: Optional[subprocess.Popen] = None

    @property
    def active(self) -> bool:
        """Only 'active' once real events have arrived — never claims capability
        it isn't actually receiving."""
        return self.events_received > 0

    def start(self, on_event: Callable[[dict], None]) -> bool:
        self._on_event = on_event
        self._stop.clear()
        # Priority: genuine in-kernel eBPF > netlink proc connector > Windows WMI.
        if self._start_ebpf():
            return True
        if _OS == "Linux":
            return self._start_netlink()
        if _OS == "Windows":
            return self._start_wmi()
        return False   # macOS EndpointSecurity needs a signed system extension

    def stop(self) -> None:
        self._stop.set()
        try:
            if self._sock is not None:
                self._sock.close()
        except Exception:
            pass
        try:
            if self._proc is not None:
                self._proc.terminate()
                try:
                    self._proc.wait(timeout=1)
                except Exception:
                    pass
                for s in (self._proc.stdout, self._proc.stderr):
                    try:
                        if s:
                            s.close()
                    except Exception:
                        pass
        except Exception:
            pass

    # ── Linux/Windows: in-kernel eBPF collector (subprocess emitting JSON) ──────
    def _start_ebpf(self) -> bool:
        binary = _find_ebpf_collector()
        if not binary:
            return False
        try:
            self._proc = subprocess.Popen(
                [binary], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                text=True, bufsize=1)
        except OSError:
            self._proc = None
            return False
        # Liveness: if it dies immediately (no privilege / no BTF), fall back.
        time.sleep(0.3)
        if self._proc.poll() is not None:
            self._proc = None
            return False
        self.kind = "ebpf"
        self._thread = threading.Thread(target=self._ebpf_loop, daemon=True,
                                        name="forcestack-ebpf")
        self._thread.start()
        return True

    def _ebpf_loop(self) -> None:
        proc = self._proc
        if proc is None or proc.stdout is None:
            return
        try:
            for line in proc.stdout:
                if self._stop.is_set():
                    break
                line = line.strip()
                if not line:
                    continue
                try:
                    evt = json.loads(line)
                except (ValueError, TypeError):
                    continue
                self._deliver(evt.get("type", "exec"), pid=evt.get("pid"),
                              ppid=evt.get("ppid"), comm=evt.get("comm", ""))
        except (ValueError, OSError):
            pass  # pipe closed during shutdown — expected

    # ── Linux: netlink proc connector ──────────────────────────────────────────
    def _start_netlink(self) -> bool:
        try:
            s = socket.socket(socket.AF_NETLINK, socket.SOCK_DGRAM, _NETLINK_CONNECTOR)
            s.bind((os.getpid(), _CN_IDX_PROC))
        except (PermissionError, OSError):
            return False   # needs root / not available → caller falls back to polling
        self._sock = s
        try:
            op = struct.pack("I", _PROC_CN_MCAST_LISTEN)
            cn_msg = struct.pack("IIIIHH", _CN_IDX_PROC, 0, 0, 0, len(op), 0) + op
            nlmsg = struct.pack("IHHII", 16 + len(cn_msg), 3, 0, 0, os.getpid()) + cn_msg
            s.send(nlmsg)
        except OSError:
            self.stop()
            return False
        self.kind = "netlink"
        self._thread = threading.Thread(target=self._netlink_loop, daemon=True,
                                        name="forcestack-procevents")
        self._thread.start()
        return True

    def _netlink_loop(self) -> None:
        try:
            self._sock.settimeout(1.0)
        except Exception:
            return
        while not self._stop.is_set():
            try:
                data = self._sock.recv(1024)
            except socket.timeout:
                continue
            except Exception:
                break   # socket closed during shutdown, or transient error
            if len(data) < 40:
                continue
            try:
                what = struct.unpack("I", data[36:40])[0]
            except struct.error:
                continue
            if what == _PROC_EVENT_EXEC:
                self._deliver("exec")
            elif what == _PROC_EVENT_FORK:
                self._deliver("fork")
            elif what == _PROC_EVENT_EXIT:
                self._deliver("exit")

    # ── Windows: WMI process-start events (best-effort) ─────────────────────────
    def _start_wmi(self) -> bool:
        try:
            import wmi  # type: ignore
        except Exception:
            return False
        self.kind = "wmi"
        self._thread = threading.Thread(target=self._wmi_loop, args=(wmi,), daemon=True,
                                        name="forcestack-procevents")
        self._thread.start()
        return True

    def _wmi_loop(self, wmi) -> None:
        try:
            c = wmi.WMI()
            watcher = c.Win32_ProcessStartTrace.watch_for()
            while not self._stop.is_set():
                try:
                    evt = watcher(timeout_ms=1000)
                    if evt is not None:
                        self._deliver("exec", name=getattr(evt, "ProcessName", ""))
                except wmi.x_wmi_timed_out:
                    continue
                except Exception:
                    break
        except Exception:
            return

    def _deliver(self, etype: str, **extra) -> None:
        self.events_received += 1
        if self._on_event:
            try:
                self._on_event({"type": etype, "ts": time.time(), **extra})
            except Exception:
                pass


def _find_ebpf_collector() -> Optional[str]:
    """Locate the compiled eBPF collector binary, if the user built it."""
    env = os.environ.get("FORCESTACK_EBPF_COLLECTOR")
    if env and os.path.isfile(env) and os.access(env, os.X_OK):
        return env
    # bundled build location: <repo>/ebpf/proc_monitor
    here = Path(__file__).resolve().parent.parent / "ebpf" / "proc_monitor"
    if here.is_file() and os.access(here, os.X_OK):
        return str(here)
    return shutil.which("proc_monitor")


def capabilities() -> dict:
    return {
        "os": _OS,
        "ebpf_collector": _find_ebpf_collector() is not None,
        "linux_netlink": _OS == "Linux",
        "windows_wmi": _OS == "Windows",
        "is_privileged": _is_privileged(),
        "note": ("in-kernel eBPF available (build ebpf/)" if _find_ebpf_collector()
                 else "eBPF collector not built; using netlink/polling" if _OS == "Linux"
                 else "event source uses WMI" if _OS == "Windows"
                 else "no userland event source on this OS"),
    }


def _is_privileged() -> bool:
    try:
        if _OS == "Windows":
            import ctypes
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        return os.geteuid() == 0
    except Exception:
        return False
