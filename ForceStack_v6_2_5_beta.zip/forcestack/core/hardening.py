"""
core/hardening.py — Enterprise apply / verify / rollback layer.

WHY THIS EXISTS
───────────────
The hardening scripts used to write a setting and then print "OK" whether or
not the write actually succeeded, with no way to undo it. That is not
acceptable for an enterprise change: a control you *assume* is applied but
isn't is worse than a known gap, and a change you can't reverse is a change
you can't safely deploy.

This module gives every script three guarantees:

  1. APPLY      — make the change through one audited path.
  2. VERIFY     — read the setting back and confirm it holds the intended
                  value. "OK" is only reported when verification passes.
  3. ROLLBACK   — the prior state is captured first (registry value or a file
                  backup) and written to a durable rollback journal, so any
                  change can be reversed precisely without disturbing anything
                  else on the system.

The journal is the same mechanism the Sentinel Probe's "smart rollback" will
build on, so a hardening change and an automatically-reverted malicious change
share one honest, inspectable ledger.
"""

from __future__ import annotations

import json
import os
import shutil
import threading
import time
import uuid
from pathlib import Path
from typing import Callable, Optional

from core.constants import CONFIG_DIR, SNAPSHOT_DIR
from core.utils import run_cmd

ROLLBACK_FILE = CONFIG_DIR / "rollback.json"
_LOCK = threading.Lock()

Emit = Optional[Callable[[str, str], None]]

# Kinds of reversible change we track.
KIND_REGISTRY = "registry"
KIND_FILE = "file"
KIND_COMMAND = "command"    # a change reversed by running a stored undo command


# ── Journal (durable, atomic, thread-safe) ──────────────────────────────────────
def _load() -> list[dict]:
    try:
        return json.loads(ROLLBACK_FILE.read_text(encoding="utf-8"))
    except Exception:
        return []


def _save(records: list[dict]) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(CONFIG_DIR, 0o700)
    except OSError:
        pass
    tmp = ROLLBACK_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(records, indent=2), encoding="utf-8")
    tmp.replace(ROLLBACK_FILE)
    try:
        os.chmod(ROLLBACK_FILE, 0o600)
    except OSError:
        pass


def _journal(record: dict) -> dict:
    record.setdefault("id", uuid.uuid4().hex[:12])
    record.setdefault("ts", time.time())
    record.setdefault("time", time.strftime("%Y-%m-%d %H:%M:%S"))
    record.setdefault("reverted", False)
    with _LOCK:
        recs = _load()
        recs.append(record)
        _save(recs)
    return record


def list_rollbacks(tool_id: Optional[str] = None, include_reverted: bool = False) -> list[dict]:
    recs = _load()
    out = []
    for r in recs:
        if tool_id and r.get("tool_id") != tool_id:
            continue
        if not include_reverted and r.get("reverted"):
            continue
        out.append(r)
    return list(reversed(out))   # newest first


def _mark_reverted(record_id: str) -> None:
    with _LOCK:
        recs = _load()
        for r in recs:
            if r.get("id") == record_id:
                r["reverted"] = True
                r["reverted_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
        _save(recs)


# ── Registry apply + verify (Windows) ───────────────────────────────────────────
def _reg_query(path: str, name: str) -> Optional[str]:
    """Return the current value's data as a string, or None if absent."""
    out, ok = run_cmd(["reg", "query", path, "/v", name])
    if not ok:
        return None
    # Output line looks like:  <name>    REG_DWORD    0x1
    for line in out.splitlines():
        parts = line.split()
        if name.lower() in [p.lower() for p in parts] and len(parts) >= 3:
            return parts[-1]
    return None


def _normalize_dword(v: str) -> str:
    """Compare 0x1 / 1 forms consistently."""
    v = v.strip().lower()
    try:
        if v.startswith("0x"):
            return str(int(v, 16))
        return str(int(v))
    except ValueError:
        return v


def apply_registry(emit: Emit, tool_id: str, path: str, name: str,
                   type_: str, value, label: str) -> bool:
    """
    Snapshot the prior value, write the new one, VERIFY it took, and journal a
    rollback record. Returns True only when the read-back confirms the change.
    """
    prior = _reg_query(path, name)
    from core.utils import reg_add
    _, wrote = reg_add(path, name, type_, value)
    if not wrote:
        if emit:
            emit(f"  ERR  {label}: write failed (need admin?)", "err")
        return False

    got = _reg_query(path, name)
    want = str(value)
    verified = got is not None and (
        _normalize_dword(got) == _normalize_dword(want) or got.strip() == want.strip()
    )
    _journal({
        "tool_id": tool_id, "kind": KIND_REGISTRY,
        "target": path, "name": name, "type": type_,
        "prior": prior, "applied": want, "reversible": True,
        "verified": verified, "detail": label,
    })
    if emit:
        if verified:
            emit(f"  OK  {label}  (verified: {name}={got})", "ok")
        else:
            emit(f"  WARN {label}: wrote but read-back was '{got}' (expected '{want}')", "warn")
    return verified


# ── File backup (cross-platform) ────────────────────────────────────────────────
def backup_file(tool_id: str, path, note: str = "") -> Optional[str]:
    """
    Copy a config file into the snapshot store before it is edited, and journal
    a rollback record pointing at the backup. Returns the backup path (or None
    if the source doesn't exist yet — in which case rollback means 'delete').
    """
    src = Path(path)
    SNAPSHOT_DIR.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    safe = str(src).strip("/").replace("/", "_").replace("\\", "_").replace(":", "")
    backup = SNAPSHOT_DIR / f"{tool_id}__{safe}__{stamp}.bak"
    existed = src.exists()
    if existed:
        shutil.copy2(src, backup)
    _journal({
        "tool_id": tool_id, "kind": KIND_FILE,
        "target": str(src), "backup": str(backup) if existed else None,
        "existed": existed, "reversible": True, "detail": note or f"backup of {src}",
    })
    return str(backup) if existed else None


# ── Command-reversible change (store an explicit undo command) ──────────────────
def record_undo(tool_id: str, undo_cmd: list, detail: str, note: str = "") -> dict:
    """Journal a change whose reversal is running `undo_cmd` (an argv list).
    The calling script performs the forward change itself; this records how to
    reverse it so the Change Journal can undo it later."""
    return _journal({
        "tool_id": tool_id, "kind": KIND_COMMAND,
        "undo": list(undo_cmd), "detail": detail, "reversible": True,
        "target": note or detail,
    })


# ── Revert ───────────────────────────────────────────────────────────────────
def revert(record_id: str, emit: Emit = None) -> tuple[bool, str]:
    rec = next((r for r in _load() if r.get("id") == record_id), None)
    if not rec:
        return False, "rollback record not found"
    if rec.get("reverted"):
        return True, "already reverted"

    kind = rec.get("kind")
    try:
        if kind == KIND_REGISTRY:
            from core.utils import reg_add
            if rec.get("prior") is None:
                run_cmd(["reg", "delete", rec["target"], "/v", rec["name"], "/f"])
                msg = f"removed {rec['name']} (was absent before)"
            else:
                reg_add(rec["target"], rec["name"], rec.get("type", "REG_DWORD"), rec["prior"])
                msg = f"restored {rec['name']} = {rec['prior']}"
        elif kind == KIND_COMMAND:
            undo = rec.get("undo") or []
            if not undo:
                return False, "no undo command recorded"
            out, ran = run_cmd(undo)
            if not ran:
                return False, f"undo command failed: {out[:120]}"
            msg = f"ran undo: {' '.join(undo)}"
        elif kind == KIND_FILE:
            target = Path(rec["target"])
            if rec.get("existed") and rec.get("backup") and Path(rec["backup"]).exists():
                shutil.copy2(rec["backup"], target)
                msg = f"restored {target} from backup"
            elif not rec.get("existed"):
                if target.exists():
                    target.unlink()
                msg = f"deleted {target} (did not exist before)"
            else:
                return False, "backup missing — cannot revert"
        else:
            return False, f"unknown rollback kind '{kind}'"
    except PermissionError:
        return False, "permission denied (run as admin/root)"
    except Exception as e:
        return False, str(e)

    _mark_reverted(record_id)
    if emit:
        emit(f"  OK  Reverted: {msg}", "ok")
    return True, msg


def revert_last(tool_id: Optional[str] = None, emit: Emit = None) -> tuple[bool, str]:
    recs = list_rollbacks(tool_id=tool_id)
    if not recs:
        return False, "nothing to revert"
    return revert(recs[0]["id"], emit)
