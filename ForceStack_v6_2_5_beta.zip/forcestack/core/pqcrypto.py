"""
core/pqcrypto.py — Hybrid post-quantum encryption engine (enterprise grade).

WHY THIS EXISTS
───────────────
"Harvest now, decrypt later": an adversary can copy your encrypted data today
and decrypt it years from now once a cryptographically-relevant quantum
computer exists. Classical algorithms alone (RSA, ECDH) will not survive that.
This module provides *hybrid* encryption — a post-quantum KEM combined with a
classical KEM — so data stays confidential even if ONE of the two is ever
broken. This is the construction NIST, IETF and the major browsers are
standardising on for the migration period.

PRIMITIVES (all standard; nothing home-rolled)
──────────────────────────────────────────────
  • ML-KEM-768   (FIPS 203)  — post-quantum key-encapsulation
  • X25519                    — classical elliptic-curve key-exchange
  • HKDF-SHA256               — binds both shared secrets into one 256-bit key
  • AES-256-GCM               — authenticated encryption (AEAD)
  • Argon2id (memory-hard)    — password → key (falls back to scrypt)
  • SHA-256                   — file/key fingerprints & standalone verification

BACKEND HONESTY
───────────────
The post-quantum KEM is provided by a pluggable backend. In order of
preference:
  1. `pqcrypto`  — PQClean's audited, **constant-time C** implementation.
                   This is the production-grade path.
  2. `kyber_py`  — a pure-Python reference implementation. Correct, but NOT
                   side-channel hardened. Usable for evaluation only.
`crypto_capabilities()["pqc_production_grade"]` tells you which one is live, so
the UI never implies protection it can't deliver.

CONTAINER SECURITY PROPERTIES (format v2)
─────────────────────────────────────────
  • The ENTIRE header (algorithm, KDF params, salts, KEM ciphertext) is bound
    as AES-GCM associated data, so tampering with any parameter is detected.
  • Large files are encrypted as a chain of independently-authenticated chunks
    with per-chunk nonces and an explicit end-of-stream marker, so truncation,
    reordering, or splicing of chunks is detected. Memory use is constant
    regardless of file size.
  • No plaintext hash is ever stored in the container (that would leak whether
    two ciphertexts share a plaintext, and let an attacker confirm guessed
    contents). GCM already authenticates integrity. SHA-256 remains available
    as a *separate* file-verification utility.

Nothing here is offensive. This module only protects data at rest / in transit.
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import struct
from dataclasses import dataclass
from typing import Callable, Optional

# ── Symmetric / classical primitives (required) ────────────────────────────────
_HAS_CRYPTOGRAPHY = False
_HAS_ARGON2 = False
try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.asymmetric.x25519 import (
        X25519PrivateKey, X25519PublicKey,
    )
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
    from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
    from cryptography.hazmat.primitives import hashes
    _HAS_CRYPTOGRAPHY = True
    try:
        from cryptography.hazmat.primitives.kdf.argon2 import Argon2id
        _HAS_ARGON2 = True
    except Exception:  # cryptography < 44
        Argon2id = None  # type: ignore
except Exception:  # pragma: no cover - environment dependent
    pass


# ── Post-quantum KEM backend (pluggable, production-first) ──────────────────────
class _PQBackend:
    name = "none"
    production = False
    available = False

    def keygen(self):        raise NotImplementedError
    def encaps(self, ek):    raise NotImplementedError   # -> (shared, ct)
    def decaps(self, dk, ct): raise NotImplementedError  # -> shared


class _PQCleanBackend(_PQBackend):
    """PQClean ML-KEM-768 via `pqcrypto` — compiled C, constant-time."""
    name = "pqclean-mlkem768"
    production = True

    def __init__(self):
        from pqcrypto.kem import ml_kem_768 as m
        self._m = m
        self.available = True

    def keygen(self):
        pk, sk = self._m.generate_keypair()
        return pk, sk

    def encaps(self, ek):
        ct, shared = self._m.encrypt(ek)
        return shared, ct

    def decaps(self, dk, ct):
        return self._m.decrypt(dk, ct)


class _KyberPyBackend(_PQBackend):
    """Pure-Python reference ML-KEM-768 via `kyber_py`. NOT constant-time."""
    name = "kyber-py-mlkem768"
    production = False

    def __init__(self):
        from kyber_py.ml_kem import ML_KEM_768 as m
        self._m = m
        self.available = True

    def keygen(self):
        return self._m.keygen()

    def encaps(self, ek):
        shared, ct = self._m.encaps(ek)
        return shared, ct

    def decaps(self, dk, ct):
        return self._m.decaps(dk, ct)


def _select_pq_backend() -> _PQBackend:
    for cls in (_PQCleanBackend, _KyberPyBackend):
        try:
            return cls()
        except Exception:
            continue
    return _PQBackend()


_PQ = _select_pq_backend()
_HAS_MLKEM = _PQ.available


MAGIC = b"FSTK"
FORMAT_VERSION = 2
_HKDF_INFO = b"ForceStack hybrid PQC v2 | ML-KEM-768 + X25519 | AES-256-GCM"

# Argon2id parameters (OWASP-aligned interactive defaults): 64 MiB, t=3, p=4.
_ARGON_MEM_KIB = 64 * 1024
_ARGON_TIME = 3
_ARGON_LANES = 4
# scrypt fallback parameters (N must be a power of two).
_SCRYPT_N = 2 ** 15
_SCRYPT_R = 8
_SCRYPT_P = 1

_STREAM_CHUNK = 1 << 20          # 1 MiB plaintext per authenticated chunk
_MODE_PW = 1
_MODE_HYBRID = 2
_MODE_PW_STREAM = 3
_MODE_HYBRID_STREAM = 4


class CryptoUnavailable(RuntimeError):
    """Raised when a required primitive is not installed. Message is user-facing."""


def crypto_capabilities() -> dict:
    """Honest report of what this machine can actually do."""
    quantum = _HAS_CRYPTOGRAPHY and _HAS_MLKEM
    hint = ""
    if not _HAS_CRYPTOGRAPHY:
        hint = "pip install cryptography"
    elif not _HAS_MLKEM:
        hint = "pip install pqcrypto   (production)  ·  or: pip install kyber-py"
    elif not _PQ.production:
        hint = "pip install pqcrypto   (for a constant-time, production-grade PQC backend)"
    return {
        "aes_gcm": _HAS_CRYPTOGRAPHY,
        "x25519": _HAS_CRYPTOGRAPHY,
        "ml_kem_768": _HAS_MLKEM,
        "sha256": True,
        "password_kdf": "argon2id" if _HAS_ARGON2 else ("scrypt" if _HAS_CRYPTOGRAPHY else "none"),
        "quantum_safe": quantum,
        "pqc_backend": _PQ.name,
        "pqc_production_grade": bool(_PQ.production and _HAS_MLKEM),
        "install_hint": hint,
    }


# ── SHA-256 utilities (always available; standalone, never inside a container) ──
def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: str, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(chunk), b""):
            h.update(block)
    return h.hexdigest()


def fingerprint(data: bytes) -> str:
    hx = sha256_hex(data).upper()
    return " ".join(hx[i:i + 4] for i in range(0, 32, 4))


# ── Guards ──────────────────────────────────────────────────────────────────
def _require_aes() -> None:
    if not _HAS_CRYPTOGRAPHY:
        raise CryptoUnavailable(
            "The 'cryptography' package is not installed, so encryption is "
            "unavailable.\nInstall it with:  pip install cryptography"
        )


def _require_pqc() -> None:
    _require_aes()
    if not _HAS_MLKEM:
        raise CryptoUnavailable(
            "Post-quantum keys need a KEM backend.\n"
            "Install one with:  pip install pqcrypto   (production, constant-time)\n"
            "                or:  pip install kyber-py   (pure-Python reference)"
        )


# ── Key derivation ────────────────────────────────────────────────────────────
def _derive_password_key(password: str, salt: bytes, params: dict) -> bytes:
    kdf = params.get("kdf")
    if kdf == "argon2id":
        if not _HAS_ARGON2:
            raise CryptoUnavailable("This file needs Argon2id (cryptography >= 44).")
        return Argon2id(
            salt=salt, length=32,
            iterations=params["t"], lanes=params["p"], memory_cost=params["m"],
        ).derive(password.encode("utf-8"))
    if kdf == "scrypt":
        return Scrypt(salt=salt, length=32,
                      n=params["n"], r=params["r"], p=params["p"]).derive(
                          password.encode("utf-8"))
    raise ValueError(f"Unknown password KDF '{kdf}'.")


def _default_pw_params() -> dict:
    if _HAS_ARGON2:
        return {"kdf": "argon2id", "m": _ARGON_MEM_KIB, "t": _ARGON_TIME, "p": _ARGON_LANES}
    return {"kdf": "scrypt", "n": _SCRYPT_N, "r": _SCRYPT_R, "p": _SCRYPT_P}


def _hkdf(secret: bytes, salt: bytes, length: int = 32) -> bytes:
    return HKDF(algorithm=hashes.SHA256(), length=length,
                salt=salt, info=_HKDF_INFO).derive(secret)


# ── Container framing ─────────────────────────────────────────────────────────
# MAGIC(4) | version(1) | mode(1) | header_len(4 BE) | header(json utf-8) | payload
def _b64(b: bytes) -> str:
    return base64.b64encode(b).decode("ascii")


def _unb64(s: str) -> bytes:
    return base64.b64decode(s.encode("ascii"))


def _header_bytes(header: dict) -> bytes:
    return json.dumps(header, separators=(",", ":"), sort_keys=True).encode("utf-8")


def _pack(mode: int, header_bytes: bytes, payload: bytes) -> bytes:
    return (MAGIC + struct.pack("BB", FORMAT_VERSION, mode)
            + struct.pack(">I", len(header_bytes)) + header_bytes + payload)


def _unpack(blob: bytes) -> tuple[int, dict, bytes, bytes]:
    if len(blob) < 10 or blob[:4] != MAGIC:
        raise ValueError("Not a ForceStack encrypted file (bad magic bytes).")
    version, mode = struct.unpack("BB", blob[4:6])
    if version != FORMAT_VERSION:
        raise ValueError(
            f"Unsupported container version {version}. This build writes/reads v{FORMAT_VERSION}."
        )
    (hlen,) = struct.unpack(">I", blob[6:10])
    header_bytes = blob[10:10 + hlen]
    header = json.loads(header_bytes.decode("utf-8"))
    payload = blob[10 + hlen:]
    return mode, header, header_bytes, payload


# ── Password mode (single-shot, for text / small data) ──────────────────────────
def encrypt_with_password(plaintext: bytes, password: str) -> bytes:
    _require_aes()
    if not password:
        raise ValueError("Password must not be empty.")
    salt, nonce = os.urandom(16), os.urandom(12)
    params = _default_pw_params()
    key = _derive_password_key(password, salt, params)
    header = {"mode": "password", "params": params, "salt": _b64(salt), "nonce": _b64(nonce)}
    hb = _header_bytes(header)
    ct = AESGCM(key).encrypt(nonce, plaintext, hb)   # full header authenticated
    return _pack(_MODE_PW, hb, ct)


def decrypt_with_password(blob: bytes, password: str) -> bytes:
    _require_aes()
    mode, header, hb, ct = _unpack(blob)
    if mode == _MODE_PW_STREAM:
        raise ValueError("This is a streamed file container. Use decrypt_file_with_password().")
    if mode != _MODE_PW:
        raise ValueError("This file was not encrypted with a password. Use the matching private key.")
    key = _derive_password_key(password, _unb64(header["salt"]), header["params"])
    try:
        return AESGCM(key).decrypt(_unb64(header["nonce"]), ct, hb)
    except Exception:
        raise ValueError("Wrong password, or the file has been tampered with.") from None


# ── Hybrid post-quantum keypair mode (single-shot) ──────────────────────────────
@dataclass
class HybridKeypair:
    mlkem_ek: bytes
    mlkem_dk: bytes
    x_priv: bytes
    x_pub: bytes
    backend: str = _PQ.name

    def public_bundle(self) -> str:
        return _b64(_header_bytes({
            "v": FORMAT_VERSION, "alg": "mlkem768+x25519", "backend": self.backend,
            "mlkem_ek": _b64(self.mlkem_ek), "x_pub": _b64(self.x_pub),
        }))

    def private_bundle(self) -> str:
        return _b64(_header_bytes({
            "v": FORMAT_VERSION, "alg": "mlkem768+x25519", "backend": self.backend,
            "mlkem_ek": _b64(self.mlkem_ek), "mlkem_dk": _b64(self.mlkem_dk),
            "x_priv": _b64(self.x_priv), "x_pub": _b64(self.x_pub),
        }))

    def public_fingerprint(self) -> str:
        return fingerprint(self.mlkem_ek + self.x_pub)


def generate_keypair() -> HybridKeypair:
    _require_pqc()
    ek, dk = _PQ.keygen()
    xp = X25519PrivateKey.generate()
    return HybridKeypair(mlkem_ek=ek, mlkem_dk=dk,
                         x_priv=xp.private_bytes_raw(),
                         x_pub=xp.public_key().public_bytes_raw(),
                         backend=_PQ.name)


def load_public_bundle(bundle_b64: str) -> dict:
    data = json.loads(_unb64(bundle_b64.strip()).decode("utf-8"))
    if data.get("alg") != "mlkem768+x25519":
        raise ValueError("Unrecognised public key format.")
    return data


def load_private_bundle(bundle_b64: str) -> HybridKeypair:
    data = json.loads(_unb64(bundle_b64.strip()).decode("utf-8"))
    if data.get("alg") != "mlkem768+x25519":
        raise ValueError("Unrecognised private key format.")
    return HybridKeypair(
        mlkem_ek=_unb64(data["mlkem_ek"]), mlkem_dk=_unb64(data["mlkem_dk"]),
        x_priv=_unb64(data["x_priv"]), x_pub=_unb64(data["x_pub"]),
        backend=data.get("backend", _PQ.name),
    )


def _hybrid_encapsulate(public_bundle_b64: str):
    """Return (key, header_fields) for a fresh hybrid encapsulation."""
    pub = load_public_bundle(public_bundle_b64)
    mlkem_ek = _unb64(pub["mlkem_ek"])
    recipient_x = X25519PublicKey.from_public_bytes(_unb64(pub["x_pub"]))
    pq_shared, pq_ct = _PQ.encaps(mlkem_ek)
    eph = X25519PrivateKey.generate()
    cl_shared = eph.exchange(recipient_x)
    salt = os.urandom(16)
    key = _hkdf(pq_shared + cl_shared, salt)
    fields = {
        "alg": "mlkem768+x25519", "backend": _PQ.name,
        "pq_ct": _b64(pq_ct),
        "eph_x_pub": _b64(eph.public_key().public_bytes_raw()),
        "salt": _b64(salt),
        "recipient_fp": fingerprint(mlkem_ek + _unb64(pub["x_pub"])),
    }
    return key, fields


def _hybrid_decapsulate(header: dict, private_bundle_b64: str) -> bytes:
    kp = load_private_bundle(private_bundle_b64)
    pq_shared = _PQ.decaps(kp.mlkem_dk, _unb64(header["pq_ct"]))
    eph_pub = X25519PublicKey.from_public_bytes(_unb64(header["eph_x_pub"]))
    x_priv = X25519PrivateKey.from_private_bytes(kp.x_priv)
    cl_shared = x_priv.exchange(eph_pub)
    return _hkdf(pq_shared + cl_shared, _unb64(header["salt"]))


def encrypt_to_public(plaintext: bytes, public_bundle_b64: str) -> bytes:
    _require_pqc()
    key, fields = _hybrid_encapsulate(public_bundle_b64)
    nonce = os.urandom(12)
    header = {"mode": "hybrid", "nonce": _b64(nonce), **fields}
    hb = _header_bytes(header)
    ct = AESGCM(key).encrypt(nonce, plaintext, hb)
    return _pack(_MODE_HYBRID, hb, ct)


def decrypt_with_private(blob: bytes, private_bundle_b64: str, passphrase: Optional[str] = None) -> bytes:
    _require_pqc()
    if is_wrapped_private(private_bundle_b64):
        if not passphrase:
            raise ValueError("This private key is passphrase-protected — enter its passphrase.")
        private_bundle_b64 = unwrap_private_bundle(private_bundle_b64, passphrase)
    mode, header, hb, ct = _unpack(blob)
    if mode == _MODE_HYBRID_STREAM:
        raise ValueError("This is a streamed file container. Use decrypt_file_with_private().")
    if mode != _MODE_HYBRID:
        raise ValueError("This file was encrypted with a password, not a key. Use password mode.")
    key = _hybrid_decapsulate(header, private_bundle_b64)
    try:
        return AESGCM(key).decrypt(_unb64(header["nonce"]), ct, hb)
    except Exception:
        raise ValueError("Decryption failed — wrong private key, or the file was tampered with.") from None


# ── Streaming file encryption (constant memory, truncation-proof) ───────────────
def _stream_aad(header_digest: bytes, index: int, final: bool) -> bytes:
    return header_digest + struct.pack(">I", index) + (b"\xff" if final else b"\x00")


def _encrypt_stream(in_path: str, out_path: str, key: bytes, mode: int,
                    header: dict, progress: Optional[Callable[[int], None]]) -> None:
    nonce_prefix = os.urandom(8)
    header = {**header, "nonce_prefix": _b64(nonce_prefix), "chunk": _STREAM_CHUNK, "stream": True}
    hb = _header_bytes(header)
    hdigest = hashlib.sha256(hb).digest()
    aead = AESGCM(key)
    total = os.path.getsize(in_path)
    done = 0
    with open(in_path, "rb") as fin, open(out_path, "wb") as fout:
        fout.write(_pack(mode, hb, b""))   # header, empty payload; frames follow
        index = 0
        prev = fin.read(_STREAM_CHUNK)
        while True:
            cur = fin.read(_STREAM_CHUNK)
            final = (cur == b"")
            nonce = nonce_prefix + struct.pack(">I", index)
            frame = aead.encrypt(nonce, prev, _stream_aad(hdigest, index, final))
            fout.write(struct.pack(">I", len(frame)) + frame)
            done += len(prev)
            if progress and total:
                progress(min(100, int(done * 100 / total)))
            index += 1
            if final:
                break
            prev = cur


def _decrypt_stream(in_path: str, out_path: str, key: bytes, header: dict,
                    header_bytes: bytes, payload_offset: int,
                    progress: Optional[Callable[[int], None]]) -> None:
    hdigest = hashlib.sha256(header_bytes).digest()
    nonce_prefix = _unb64(header["nonce_prefix"])
    aead = AESGCM(key)
    total = os.path.getsize(in_path)
    with open(in_path, "rb") as fin, open(out_path, "wb") as fout:
        fin.seek(payload_offset)
        index = 0
        saw_final = False
        while True:
            lb = fin.read(4)
            if not lb:
                break
            if len(lb) != 4:
                raise ValueError("Corrupt container: truncated frame length.")
            (flen,) = struct.unpack(">I", lb)
            frame = fin.read(flen)
            if len(frame) != flen:
                raise ValueError("Corrupt or truncated container.")
            nonce = nonce_prefix + struct.pack(">I", index)
            # peek whether more frames follow to know if this is the final one
            pos = fin.tell()
            more = bool(fin.read(1))
            fin.seek(pos)
            final = not more
            try:
                chunk = aead.decrypt(nonce, frame, _stream_aad(hdigest, index, final))
            except Exception:
                raise ValueError("Wrong key/password, or the file has been tampered with.") from None
            fout.write(chunk)
            if progress and total:
                progress(min(100, int(pos * 100 / total)))
            index += 1
            if final:
                saw_final = True
                break
        if not saw_final:
            raise ValueError("Container is truncated — end-of-stream marker missing.")


def encrypt_file_with_password(in_path: str, out_path: str, password: str,
                               progress: Optional[Callable[[int], None]] = None) -> None:
    _require_aes()
    if not password:
        raise ValueError("Password must not be empty.")
    salt = os.urandom(16)
    params = _default_pw_params()
    key = _derive_password_key(password, salt, params)
    _encrypt_stream(in_path, out_path, key, _MODE_PW_STREAM,
                    {"mode": "password", "params": params, "salt": _b64(salt)}, progress)


def decrypt_file_with_password(in_path: str, out_path: str, password: str,
                               progress: Optional[Callable[[int], None]] = None) -> None:
    _require_aes()
    with open(in_path, "rb") as f:
        blob_head = f.read(10)
        if blob_head[:4] != MAGIC:
            raise ValueError("Not a ForceStack encrypted file.")
        (hlen,) = struct.unpack(">I", blob_head[6:10])
        hb = f.read(hlen)
        payload_offset = 10 + hlen
    mode = struct.unpack("BB", blob_head[4:6])[1]
    header = json.loads(hb.decode("utf-8"))
    if mode != _MODE_PW_STREAM:
        raise ValueError("Not a password-encrypted file container.")
    key = _derive_password_key(password, _unb64(header["salt"]), header["params"])
    _decrypt_stream(in_path, out_path, key, header, hb, payload_offset, progress)


def encrypt_file_to_public(in_path: str, out_path: str, public_bundle_b64: str,
                           progress: Optional[Callable[[int], None]] = None) -> None:
    _require_pqc()
    key, fields = _hybrid_encapsulate(public_bundle_b64)
    _encrypt_stream(in_path, out_path, key, _MODE_HYBRID_STREAM,
                    {"mode": "hybrid", **fields}, progress)


def decrypt_file_with_private(in_path: str, out_path: str, private_bundle_b64: str,
                              progress: Optional[Callable[[int], None]] = None,
                              passphrase: Optional[str] = None) -> None:
    _require_pqc()
    if is_wrapped_private(private_bundle_b64):
        if not passphrase:
            raise ValueError("This private key is passphrase-protected — enter its passphrase.")
        private_bundle_b64 = unwrap_private_bundle(private_bundle_b64, passphrase)
    with open(in_path, "rb") as f:
        blob_head = f.read(10)
        if blob_head[:4] != MAGIC:
            raise ValueError("Not a ForceStack encrypted file.")
        (hlen,) = struct.unpack(">I", blob_head[6:10])
        hb = f.read(hlen)
        payload_offset = 10 + hlen
    mode = struct.unpack("BB", blob_head[4:6])[1]
    header = json.loads(hb.decode("utf-8"))
    if mode != _MODE_HYBRID_STREAM:
        raise ValueError("Not a keypair-encrypted file container.")
    key = _hybrid_decapsulate(header, private_bundle_b64)
    _decrypt_stream(in_path, out_path, key, header, hb, payload_offset, progress)


# ── Armour (copy-pasteable ASCII) ───────────────────────────────────────────────
_ARMOR_HEAD = "-----BEGIN FORCESTACK ENCRYPTED MESSAGE-----"
_ARMOR_TAIL = "-----END FORCESTACK ENCRYPTED MESSAGE-----"


def armor(blob: bytes) -> str:
    body = base64.b64encode(blob).decode("ascii")
    lines = "\n".join(body[i:i + 64] for i in range(0, len(body), 64))
    return f"{_ARMOR_HEAD}\n{lines}\n{_ARMOR_TAIL}"


def dearmor(text: str) -> bytes:
    t = text.strip()
    if _ARMOR_HEAD in t:
        t = t.split(_ARMOR_HEAD, 1)[1]
    if _ARMOR_TAIL in t:
        t = t.split(_ARMOR_TAIL, 1)[0]
    return base64.b64decode("".join(t.split()))


# ── Private-key at-rest protection ──────────────────────────────────────────────
_PRIV_WRAP_HEAD = "-----BEGIN FORCESTACK PROTECTED PRIVATE KEY-----"
_PRIV_WRAP_TAIL = "-----END FORCESTACK PROTECTED PRIVATE KEY-----"


def is_wrapped_private(text: str) -> bool:
    """True if `text` is a passphrase-protected private-key bundle."""
    return _PRIV_WRAP_HEAD in (text or "")


def wrap_private_bundle(private_bundle_b64: str, password: str) -> str:
    """Encrypt a private-key bundle under a passphrase for safe at-rest storage
    (Argon2id + AES-256-GCM). Returns copy-pasteable ASCII."""
    _require_aes()
    if not password:
        raise ValueError("Passphrase must not be empty.")
    blob = encrypt_with_password(private_bundle_b64.strip().encode("ascii"), password)
    body = base64.b64encode(blob).decode("ascii")
    lines = "\n".join(body[i:i + 64] for i in range(0, len(body), 64))
    return f"{_PRIV_WRAP_HEAD}\n{lines}\n{_PRIV_WRAP_TAIL}"


def unwrap_private_bundle(wrapped: str, password: str) -> str:
    """Recover a private-key bundle from its passphrase-protected form."""
    _require_aes()
    t = wrapped.strip()
    if _PRIV_WRAP_HEAD in t:
        t = t.split(_PRIV_WRAP_HEAD, 1)[1]
    if _PRIV_WRAP_TAIL in t:
        t = t.split(_PRIV_WRAP_TAIL, 1)[0]
    blob = base64.b64decode("".join(t.split()))
    return decrypt_with_password(blob, password).decode("ascii")
