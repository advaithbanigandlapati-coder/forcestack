"""
core/probe.py — Sentinel Probe: a low-RAM, ML-driven endpoint sensor (NGAV).

WHAT IT IS
──────────
A lightweight background watcher modelled on Next-Generation Antivirus (NGAV):
instead of matching known virus signatures, it learns what *normal* looks like
on THIS machine and flags behaviour that deviates — so it can catch zero-day,
polymorphic and fileless attacks that have no signature. It watches three
signals together: running processes, live network connections, and the audit
log.

It is DEFENSIVE only. It observes, scores, explains, and — optionally and only
with explicit permission — contains a threat by *suspending* a process
(reversible) or quarantining a file (moved, not deleted). It never attacks
anything.

HOW THE "AI" WORKS  (this is real machine learning, not if-statements)
──────────────────────────────────────────────────────────────────────
Every few seconds the probe turns the current system state into a numeric
feature vector of behavioural signals (process spawn rate, distinct remote
IPs, trusted-tools-touching-the-network count, fileless tells, process-name
entropy, beaconing candidates, memory-growth, …). An unsupervised anomaly
model learns a baseline of normal vectors and then scores each new vector:

  • Primary backend: scikit-learn **IsolationForest** — the same family of
    unsupervised outlier model used in real EDR/NGAV pipelines.
  • Fallback backend: a pure-Python **robust z-score** detector (median/MAD),
    so the probe still learns and scores with zero heavy dependencies.

The model trains on the machine's own baseline (a short warm-up), refits
periodically, and does NOT fold flagged-anomalous samples back into the
baseline (so an ongoing attack can't quietly become the new "normal"). The
learned baseline is persisted to disk, so it survives restarts. Because a bare
"anomaly score" isn't actionable, every ML detection is explained: the probe
reports which features deviated and by how many standard deviations.

On top of the ML layer sit four explainable behavioural modules (agentic-threat
tempo, fileless/memory, identity/LOLBins, and change-tracking for rollback),
and an OPTIONAL large-language-model triage hook (off by default, no network
calls unless you install it) for a second opinion on ambiguous cases.

WHY "low-RAM"
─────────────
The probe keeps only fixed-size rings of recent state and samples on a timer
rather than hooking every syscall. `self_footprint_mb()` reports the size of
the probe's own retained data (not the whole app) so the claim is verifiable.
"""

from __future__ import annotations

import collections
import json
import math
import os
import shutil
import sys
import threading
import time
from dataclasses import dataclass, field, asdict
from typing import Callable, Deque, Optional

try:
    import psutil
    _HAS_PSUTIL = True
except Exception:  # pragma: no cover
    psutil = None  # type: ignore
    _HAS_PSUTIL = False

try:
    import numpy as np
    from sklearn.ensemble import IsolationForest
    _HAS_SKLEARN = True
except Exception:  # pragma: no cover
    np = None  # type: ignore
    IsolationForest = None  # type: ignore
    _HAS_SKLEARN = False

from core.audit import audit
from core import hardening
from core.constants import CONFIG_DIR
from core.eventsource import ProcessEventSource, _is_privileged

_MODEL_FILE = CONFIG_DIR / "probe_baseline.json"
_QUARANTINE_DIR = CONFIG_DIR / "quarantine"


# ── Severity bands ─────────────────────────────────────────────────────────────
SEV_INFO = 20
SEV_LOW = 40
SEV_MED = 60
SEV_HIGH = 80
SEV_CRIT = 95


def severity_band(score: int) -> str:
    if score >= SEV_CRIT:
        return "critical"
    if score >= SEV_HIGH:
        return "high"
    if score >= SEV_MED:
        return "medium"
    if score >= SEV_LOW:
        return "low"
    return "info"


_LOLBINS = {
    "powershell.exe", "pwsh.exe", "cmd.exe", "wscript.exe", "cscript.exe",
    "mshta.exe", "rundll32.exe", "regsvr32.exe", "certutil.exe", "bitsadmin.exe",
    "wmic.exe", "msbuild.exe", "installutil.exe", "curl.exe", "bash", "sh",
    "python", "python3", "perl", "nc", "ncat", "socat", "wget", "curl",
}
# High-signal binaries that almost never make legitimate outbound connections —
# a network connection from these is alert-worthy on its own. The remainder
# (python, sh, bash, curl, wget, perl…) are everyday tools whose ordinary
# network use would otherwise flood a developer's machine with false positives,
# so for those we require a known-bad port before alerting and let the ML model
# weigh routine use.
_LOLBINS_HIGH = {
    "powershell.exe", "pwsh.exe", "cmd.exe", "wscript.exe", "cscript.exe",
    "mshta.exe", "rundll32.exe", "regsvr32.exe", "certutil.exe", "bitsadmin.exe",
    "wmic.exe", "msbuild.exe", "installutil.exe", "nc", "ncat", "socat",
}
_SUSPECT_REMOTE_PORTS = {4444, 5555, 1337, 31337, 6666, 6667, 8888, 9001, 12345}

# NGAV behavioural feature names (order matters — the vector follows this).
FEATURES = [
    "n_procs", "n_new_procs", "n_remote_conns", "n_distinct_ips",
    "n_lolbin_remote", "n_no_disk_image", "max_rss_growth_mb",
    "n_suspect_ports", "spawn_rate", "max_name_entropy", "n_beacon_candidates",
]
_FEATURE_PHRASES = {
    "n_procs": "number of running processes",
    "n_new_procs": "new processes this interval",
    "n_remote_conns": "outbound network connections",
    "n_distinct_ips": "distinct remote servers contacted",
    "n_lolbin_remote": "trusted tools talking to the network",
    "n_no_disk_image": "processes with no file on disk (fileless tell)",
    "max_rss_growth_mb": "fastest memory growth (MB)",
    "n_suspect_ports": "connections on known C2 ports",
    "spawn_rate": "process-spawn rate",
    "max_name_entropy": "most random-looking process name (polymorphism tell)",
    "n_beacon_candidates": "regular network beaconing candidates",
}


def _shannon(s: str) -> float:
    if not s:
        return 0.0
    counts = collections.Counter(s)
    n = len(s)
    return -sum((c / n) * math.log2(c / n) for c in counts.values())


@dataclass
class Detection:
    ts: float
    module: str
    score: int
    title: str
    why: str
    evidence: dict = field(default_factory=dict)
    recommendation: str = ""
    pid: Optional[int] = None
    auto_action: str = ""
    verdict_source: str = "heuristic"   # "heuristic" | "ml" | "ai"

    @property
    def band(self) -> str:
        return severity_band(self.score)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["band"] = self.band
        d["time"] = time.strftime("%H:%M:%S", time.localtime(self.ts))
        return d


# ── The AI: unsupervised anomaly model (IsolationForest + robust-z fallback) ────
class AnomalyModel:
    """
    Learns a per-machine baseline of behavioural feature vectors and scores new
    vectors for anomalousness in [0,1]. Backend is scikit-learn IsolationForest
    when available, else a pure-Python robust z-score detector.
    """

    def __init__(self, warmup: int = 12, refit_every: int = 30, baseline_max: int = 300):
        self.warmup = warmup
        self.refit_every = refit_every
        self._baseline: Deque[list] = collections.deque(maxlen=baseline_max)
        self._model = None
        self._mean = None
        self._std = None
        self._df_mu = 0.0
        self._df_sigma = 1.0
        self._obs = 0
        self.backend = "isolation_forest" if _HAS_SKLEARN else "robust_zscore"
        self._load()

    @property
    def ready(self) -> bool:
        return len(self._baseline) >= self.warmup

    @property
    def state(self) -> str:
        if not self.ready:
            return f"learning ({len(self._baseline)}/{self.warmup})"
        return "active"

    def observe(self, vec: list, anomaly: Optional[float] = None) -> None:
        """Fold a vector into the baseline — but not if it looks anomalous."""
        self._obs += 1
        if (not self.ready) or (anomaly is None) or (anomaly < 0.6):
            self._baseline.append(list(vec))
        if self.ready and (self._model is None or self._obs % self.refit_every == 0):
            self._fit()
            self._save()

    def _fit(self) -> None:
        if not _HAS_SKLEARN:
            # robust stats only
            cols = list(zip(*self._baseline, strict=False))
            self._mean = [_median(c) for c in cols]
            self._std = [max(_mad(c), 1e-6) for c in cols]
            return
        X = np.array(self._baseline, dtype=float)
        self._mean = X.mean(axis=0)
        self._std = X.std(axis=0) + 1e-9
        Xs = (X - self._mean) / self._std
        self._model = IsolationForest(n_estimators=64, random_state=0,
                                      contamination="auto").fit(Xs)
        # Calibrate: learn the distribution of the model's own scores on normal
        # data, so anomaly is measured in std-devs below normal (scale-free).
        dft = self._model.decision_function(Xs)
        self._df_mu = float(np.mean(dft))
        self._df_sigma = float(max(np.std(dft), 0.02))

    def score(self, vec: list) -> tuple[float, list]:
        """Return (anomaly_0_1, top_deviating_features)."""
        if not self.ready or self._mean is None:
            return 0.0, []
        if _HAS_SKLEARN:
            x = np.array(vec, dtype=float)
            z = (x - self._mean) / self._std
            order = list(np.argsort(-np.abs(z)))
            if self._model is not None:
                xs = ((x - self._mean) / self._std).reshape(1, -1)
                df = float(self._model.decision_function(xs)[0])
                # std-devs the new score falls BELOW normal (higher = odder)
                zdf = (self._df_mu - df) / self._df_sigma
                anomaly = 1.0 / (1.0 + math.exp(-1.2 * (zdf - 3.0)))
            else:
                anomaly = float(np.tanh(np.mean(np.clip(np.abs(z) - 2, 0, None)) / 2))
            zlist = [float(v) for v in z]
        else:
            z = [(v - m) / s for v, m, s in zip(vec, self._mean, self._std, strict=False)]
            zlist = z
            order = sorted(range(len(z)), key=lambda i: -abs(z[i]))
            excess = [max(abs(v) - 2, 0) for v in z]
            anomaly = math.tanh((sum(excess) / max(len(excess), 1)) / 2)
        top = [{"feature": FEATURES[i], "phrase": _FEATURE_PHRASES[FEATURES[i]],
                "value": round(float(vec[i]), 2), "z": round(float(zlist[i]), 1)}
               for i in order[:3] if abs(zlist[i]) > 2.0]
        return max(0.0, min(1.0, float(anomaly))), top

    def _save(self) -> None:
        try:
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            _MODEL_FILE.write_text(json.dumps({
                "backend": self.backend,
                "baseline": list(self._baseline),
            }), encoding="utf-8")
            os.chmod(_MODEL_FILE, 0o600)
        except Exception:
            pass

    def _load(self) -> None:
        try:
            data = json.loads(_MODEL_FILE.read_text(encoding="utf-8"))
            for v in data.get("baseline", []):
                if len(v) == len(FEATURES):
                    self._baseline.append(v)
            if self.ready:
                self._fit()
        except Exception:
            pass


def _median(xs):
    s = sorted(xs)
    n = len(s)
    return s[n // 2] if n % 2 else (s[n // 2 - 1] + s[n // 2]) / 2


def _mad(xs):
    m = _median(xs)
    return 1.4826 * _median([abs(x - m) for x in xs])


# ── Analyzer interface (explainable + optional LLM triage) ──────────────────────
class Analyzer:
    name = "base"

    def review(self, detection: Detection) -> Optional[Detection]:
        return detection


class HeuristicAnalyzer(Analyzer):
    """Always-on, offline, explainable correlation layer."""
    name = "heuristic"

    def review(self, detection: Detection) -> Optional[Detection]:
        ev = detection.evidence
        bonus, reasons = 0, []
        if ev.get("is_lolbin") and ev.get("has_remote_conn"):
            bonus += 15
            reasons.append("a trusted system tool is also talking to the network")
        if ev.get("no_disk_image"):
            bonus += 20
            reasons.append("its program file is missing from disk (fileless tell)")
        if ev.get("machine_speed"):
            bonus += 10
            reasons.append("actions arrived faster than a human could type them")
        if bonus:
            detection.score = min(100, detection.score + bonus)
            detection.why += " Correlated signals: " + "; ".join(reasons) + "."
        return detection


class AIAnalyzer(Analyzer):
    """Optional LLM triage hook. OFF unless installed via set_ai_analyzer()."""
    name = "ai"

    def __init__(self, verdict_fn: Callable[[dict], dict]):
        self._fn = verdict_fn

    def review(self, detection: Detection) -> Optional[Detection]:
        try:
            summary = {"title": detection.title, "module": detection.module,
                       "evidence": detection.evidence, "base_score": detection.score}
            verdict = self._fn(summary) or {}
        except Exception:
            return detection
        conf = float(verdict.get("confidence", 0.0))
        if verdict.get("malicious"):
            detection.score = min(100, max(detection.score, int(60 + conf * 40)))
            detection.verdict_source = "ai"
            if verdict.get("reason"):
                detection.why += f" AI triage: {verdict['reason']}"
        elif conf > 0.7:
            detection.score = max(SEV_INFO, detection.score - int(conf * 25))
            detection.verdict_source = "ai"
            detection.why += " AI triage judged this likely benign."
        return detection


# ── Behavioural modules ─────────────────────────────────────────────────────────
class _Module:
    name = "module"

    def scan(self, snap: "Snapshot", eng: "ProbeEngine") -> list[Detection]:
        return []


class AgenticThreatModule(_Module):
    name = "AgenticThreat"

    def scan(self, snap, eng):
        out = []
        # Count spawns from the kernel event stream too, so processes that start
        # AND finish between polls are not missed (closes the sampling gap when
        # event telemetry is active; falls back to the sampled count otherwise).
        sampled = len(snap.new_pids)
        events = eng._event_spawn_count(eng.sample_interval)
        spawn_count = max(sampled, events)
        if spawn_count >= 6:
            src = "kernel events" if events > sampled else "processes"
            out.append(Detection(
                ts=snap.ts, module=self.name, score=SEV_MED,
                title=f"Burst of {spawn_count} new processes at once",
                why=("Automated/AI-driven attacks spawn many processes far faster "
                     f"than a person clicking around ever would (seen via {src})."),
                evidence={"new_pids": list(snap.new_pids)[:20], "event_spawns": events,
                          "machine_speed": True},
                recommendation="Open the process list and confirm you started these."))
        # Beaconing: repeated *new* connections to the same host at a regular
        # interval. Fixed: we count connection ESTABLISHMENT events, so a single
        # long-lived connection (SSH, a browser keep-alive) is NOT flagged.
        for (pid, ip), times in eng._beacon_candidates().items():
            gaps = [t2 - t1 for t1, t2 in zip(times, times[1:], strict=False)]
            if len(gaps) < 3:
                continue
            mean = sum(gaps) / len(gaps)
            if mean <= 0 or mean > 900:      # ignore >15-min gaps
                continue
            var = sum((g - mean) ** 2 for g in gaps) / len(gaps)
            jitter = (var ** 0.5) / mean
            if jitter < 0.12:                # suspiciously regular re-connects
                pname = eng._pid_name(pid)
                out.append(Detection(
                    ts=snap.ts, module=self.name, score=SEV_HIGH,
                    title=f"Regular network beaconing from {pname}",
                    why=("This program repeatedly reconnects to the same server at an "
                         "almost perfectly regular interval — how malware 'phones home'."),
                    evidence={"pid": pid, "remote_ip": ip, "reconnects": len(times),
                              "interval_s": round(mean, 1), "jitter": round(jitter, 3),
                              "has_remote_conn": True},
                    recommendation="Identify this program; if unknown, contain it.",
                    pid=pid))
        return out


class MemoryDefenseModule(_Module):
    name = "MemoryDefense"

    def scan(self, snap, eng):
        out = []
        for pi in snap.procs:
            exe = pi.get("exe") or ""
            # Linux marks a replaced/updated binary's path as "… (deleted)".
            exe_clean = exe.replace(" (deleted)", "")
            no_image = bool(exe_clean) and not os.path.exists(exe_clean)
            if not (no_image and pi.get("rss", 0) > 8 * 1024 * 1024):
                continue
            # The bare "running from a deleted file" signal is COMMON right after
            # a package update on Linux, so alone it is too weak to alert on. We
            # require corroboration; otherwise it only feeds the ML feature vector.
            is_lol = pi.get("name", "").lower() in _LOLBINS
            has_remote = eng._pid_has_remote(pi["pid"])
            age = time.time() - (pi.get("create_time") or time.time())
            recent = age < 300
            odd_name = _shannon(os.path.splitext(pi.get("name", ""))[0]) >= 3.6
            reasons = []
            if is_lol:
                reasons.append("it is a commonly-abused system tool")
            if has_remote:
                reasons.append("it is talking to the network")
            if recent:
                reasons.append("it started only minutes ago")
            if odd_name:
                reasons.append("it has an unusually random-looking name")
            if not reasons:
                continue     # uncorroborated — leave it to the ML model
            out.append(Detection(
                ts=snap.ts, module=self.name,
                score=SEV_HIGH if (is_lol or has_remote) else SEV_MED,
                title=f"Process '{pi.get('name','?')}' runs from a deleted file",
                why=("Malware that lives only in memory deletes its own file to "
                     "hide. Corroborating signs here: " + "; ".join(reasons) + "."),
                evidence={"pid": pi["pid"], "exe": exe or "(none)",
                          "rss_mb": round(pi.get("rss", 0) / 1e6, 1),
                          "no_disk_image": True, "is_lolbin": is_lol,
                          "has_remote_conn": has_remote, "age_s": int(age)},
                recommendation="Capture the PID, then contain and investigate.",
                pid=pi["pid"]))
        return out


class IdentityTelemetryModule(_Module):
    name = "IdentityTelemetry"

    def scan(self, snap, eng):
        out = []
        for pi in snap.procs:
            name = pi.get("name", "").lower()
            if name not in _LOLBINS:
                continue
            has_remote = eng._pid_has_remote(pi["pid"])
            suspect_port = eng._pid_suspect_port(pi["pid"])
            high_signal = name in _LOLBINS_HIGH
            if suspect_port:
                score = SEV_HIGH
            elif has_remote and high_signal:
                score = SEV_MED
            else:
                # Everyday tool (python/curl/sh…) on an ordinary port: routine on
                # a real machine. Don't alert — the ML model still sees it via the
                # n_lolbin_remote feature and will flag it if the pattern is odd.
                continue
            out.append(Detection(
                ts=snap.ts, module=self.name, score=score,
                title=f"Trusted tool '{pi.get('name')}' is making network connections",
                why=("Attackers abuse built-in, signed tools (PowerShell, certutil, "
                     "rundll32…) so antivirus trusts them. This one is reaching the "
                     "network" + (f" on a known-bad port ({suspect_port})" if suspect_port else "")
                     + " — worth a hard look."),
                evidence={"pid": pi["pid"], "is_lolbin": True, "high_signal": high_signal,
                          "has_remote_conn": has_remote, "suspect_port": suspect_port},
                recommendation="Confirm you launched this. If not, contain it.",
                pid=pi["pid"]))
        for e in eng._recent_audit(180):
            if e.get("tool_id") == "admin_audit" and "new" in e.get("detail", "").lower():
                out.append(Detection(
                    ts=snap.ts, module=self.name, score=SEV_MED,
                    title="A new privileged account may have appeared",
                    why="Attackers create hidden admin accounts to keep access after a reboot.",
                    evidence={"audit_detail": e.get("detail", "")[:160]},
                    recommendation="Run the Local Admin Auditor and review every admin account."))
        return out


class SmartRollbackModule(_Module):
    """
    Watches auto-start directories for NEW files and records them in the durable
    rollback journal. A newly-added startup file can be quarantined (moved, not
    deleted) and later restored — surgical, reversible remediation.
    """
    name = "SmartRollback"

    def scan(self, snap, eng):
        out = []
        current = eng._startup_files()
        added = current - eng._startup_baseline
        for path in sorted(added):
            eng.record_change(kind="startup_file_added", target=path,
                              detail=f"New auto-start file: {path}", reversible=True)
            out.append(Detection(
                ts=snap.ts, module=self.name, score=SEV_MED,
                title="New auto-start entry appeared",
                why=("A new file was added to a location that runs automatically at "
                     "login/boot — a common way malware survives a reboot."),
                evidence={"path": path},
                recommendation="If you didn't add this, quarantine it (reversible)."))
        eng._startup_baseline = current
        return out


@dataclass
class Snapshot:
    ts: float
    procs: list
    new_pids: set
    conns: list


# ── The engine ───────────────────────────────────────────────────────────────────
class ProbeEngine:
    def __init__(self, sample_interval: float = 4.0, ring_size: int = 2000):
        self.sample_interval = sample_interval
        self._detections: Deque[Detection] = collections.deque(maxlen=ring_size)
        self._change_journal: Deque[dict] = collections.deque(maxlen=500)
        self._subs: list[Callable[[Detection], None]] = []
        self._change_subs: list[Callable[[dict], None]] = []

        self._modules = [AgenticThreatModule(), MemoryDefenseModule(),
                         IdentityTelemetryModule(), SmartRollbackModule()]
        self._analyzers: list[Analyzer] = [HeuristicAnalyzer()]
        self.model = AnomalyModel()

        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._running = False
        self._lock = threading.Lock()

        self._prev_pids: set = set()
        self._pid_names: dict[int, str] = {}
        self._rss_last: dict[int, int] = {}
        self._prev_conns: set = set()                      # (pid, ip, port) last sample
        self._conn_events: dict = collections.defaultdict(  # (pid, ip) -> deque[ts]
            lambda: collections.deque(maxlen=10))
        self._startup_baseline: set = set()
        self._autonomous = False
        self.samples_taken = 0
        self.started_at: Optional[float] = None
        self.last_anomaly: float = 0.0
        # Event-driven telemetry + feedback state
        self._event_src = ProcessEventSource()
        self._event_spawns: Deque[float] = collections.deque(maxlen=400)
        self._last_vector: Optional[list] = None
        self._suppressed: set = set()          # (module, title) marked benign by the user

    # ── Subscription / config ──────────────────────────────────────────────────
    def subscribe(self, fn): self._subs.append(fn)
    def subscribe_changes(self, fn): self._change_subs.append(fn)

    def set_ai_analyzer(self, verdict_fn) -> None:
        self._analyzers = [a for a in self._analyzers if a.name != "ai"]
        if verdict_fn is not None:
            self._analyzers.append(AIAnalyzer(verdict_fn))

    @property
    def ai_enabled(self) -> bool:
        return any(a.name == "ai" for a in self._analyzers)

    @property
    def ml_backend(self) -> str:
        return self.model.backend

    @property
    def ml_state(self) -> str:
        return self.model.state

    def set_autonomous(self, enabled: bool) -> None:
        self._autonomous = bool(enabled)

    @property
    def autonomous(self) -> bool:
        return self._autonomous

    # ── Lifecycle ───────────────────────────────────────────────────────────────
    @property
    def running(self) -> bool:
        return self._running

    def start(self) -> None:
        if self._running:
            return
        if not _HAS_PSUTIL:
            raise RuntimeError("psutil is required for the probe. pip install psutil")
        self._stop.clear()
        self._startup_baseline = self._startup_files()
        self.started_at = time.time()
        # Try to attach event-driven, kernel-sourced process telemetry. Fail-safe:
        # if it can't start (no privilege / namespaced), we stay on polling.
        try:
            self._event_src.start(self._on_proc_event)
        except Exception:
            pass
        self._thread = threading.Thread(target=self._loop, daemon=True, name="forcestack-probe")
        self._running = True
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        self._running = False
        try:
            self._event_src.stop()
        except Exception:
            pass

    def _on_proc_event(self, evt: dict) -> None:
        if evt.get("type") in ("exec", "fork"):
            self._event_spawns.append(evt.get("ts", time.time()))

    def _event_spawn_count(self, window_s: float = 4.0) -> int:
        cutoff = time.time() - window_s
        return sum(1 for t in self._event_spawns if t >= cutoff)

    def telemetry_mode(self) -> str:
        """Honest, current data-source description — only claims kernel events
        once they're actually arriving."""
        if self._event_src.active:
            return f"kernel events ({self._event_src.kind}) + polling"
        if not _is_privileged():
            return "polling — DEGRADED (no admin/root: limited network→PID mapping, no containment)"
        return "polling (userland)"

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                snap = self._sample()
                self.samples_taken += 1
                # 1) ML anomaly scoring on the behavioural feature vector
                vec = self._features(snap)
                self._last_vector = vec
                anomaly, top = self.model.score(vec)
                self.last_anomaly = anomaly
                self.model.observe(vec, anomaly)
                if self.model.ready and anomaly >= 0.7 and top:
                    self._emit(self._ml_detection(snap, anomaly, top))
                # 2) explainable behavioural modules
                for mod in self._modules:
                    for det in mod.scan(snap, self):
                        self._emit(det)
            except Exception:
                pass  # a sensor must never crash the app
            # Adaptive cadence: sample faster during bursts of activity so the
            # polling gap shrinks exactly when it matters most.
            self._stop.wait(self._next_interval())

    def _next_interval(self) -> float:
        busy = (len(getattr(self, "_prev_pids", ())) and self._event_spawn_count(self.sample_interval) >= 4)
        return max(1.0, self.sample_interval / 2) if busy else self.sample_interval

    def _ml_detection(self, snap, anomaly, top) -> Detection:
        score = int(SEV_MED + (anomaly - 0.7) / 0.3 * (SEV_CRIT - SEV_MED))
        lead = top[0]
        why = ("The learned model for this machine finds the current behaviour "
               f"unusual. Most unusual: {lead['phrase']} "
               f"(now {lead['value']}, ~{abs(lead['z'])}σ from normal).")
        return Detection(
            ts=snap.ts, module="AIAnomaly", score=min(SEV_CRIT, score),
            title="Unusual system behaviour (learned-baseline anomaly)",
            why=why, verdict_source="ml",
            evidence={"anomaly": round(anomaly, 2), "backend": self.model.backend,
                      "top_features": top},
            recommendation="Review the deviating signals below; correlate with any alerts.")

    # ── Detection dispatch ────────────────────────────────────────────────────
    def _emit(self, det: Detection) -> None:
        for a in self._analyzers:
            det = a.review(det)
            if det is None:
                return
        if det.score < SEV_LOW:
            return
        # User-taught suppression: things marked benign are muted unless they
        # escalate to critical (cuts the "first-time benign build/backup" FPs).
        if (det.module, det.title) in self._suppressed and det.score < SEV_CRIT:
            return
        if self._autonomous and det.pid and det.score >= SEV_HIGH:
            ok, msg = self.contain(det.pid)
            det.auto_action = ("Auto-contained: " + msg) if ok else ("Auto-contain failed: " + msg)
        with self._lock:
            self._detections.appendleft(det)
        for fn in list(self._subs):
            try:
                fn(det)
            except Exception:
                pass

    def mark_benign(self, detection: Detection) -> None:
        """Teach the probe that a detection was a false positive: mute this
        alert going forward and fold the current behaviour into the learned
        baseline so the ML model stops treating it as anomalous."""
        self._suppressed.add((detection.module, detection.title))
        if self._last_vector is not None:
            # observe with anomaly=0 so it is always accepted into the baseline
            self.model.observe(self._last_vector, anomaly=0.0)

    def recent(self, limit: int = 50) -> list[Detection]:
        with self._lock:
            return list(self._detections)[:limit]

    # ── Response actions (defensive, reversible / non-destructive) ─────────────
    def contain(self, pid: int) -> tuple[bool, str]:
        if not _HAS_PSUTIL:
            return False, "psutil unavailable"
        try:
            p = psutil.Process(pid)
            name = p.name()
            try:
                p.suspend()
                self.record_change(kind="process_suspend", target=str(pid),
                                   detail=f"Suspended '{name}' (PID {pid})", reversible=True)
                return True, f"suspended '{name}' (PID {pid}) — reversible"
            except (psutil.AccessDenied, NotImplementedError):
                return False, "insufficient privileges (run as admin/root)"
        except psutil.NoSuchProcess:
            return False, "process already gone"
        except Exception as e:
            return False, str(e)

    def release(self, pid: int) -> tuple[bool, str]:
        if not _HAS_PSUTIL:
            return False, "psutil unavailable"
        try:
            psutil.Process(pid).resume()
            return True, f"resumed PID {pid}"
        except Exception as e:
            return False, str(e)

    def quarantine_file(self, path: str) -> tuple[bool, str]:
        """Move a suspicious file into quarantine (reversible — not deleted)."""
        try:
            src = os.path.abspath(path)
            if not os.path.exists(src):
                return False, "file not found"
            _QUARANTINE_DIR.mkdir(parents=True, exist_ok=True)
            os.chmod(_QUARANTINE_DIR, 0o700)
            dest = str(_QUARANTINE_DIR / f"{int(time.time())}__{os.path.basename(src)}")
            shutil.move(src, dest)
            self.record_change(kind="quarantine", target=src, detail=f"Quarantined {src}",
                               reversible=True, extra={"quarantined_to": dest})
            return True, f"quarantined to {dest}"
        except PermissionError:
            return False, "permission denied (run as admin/root)"
        except Exception as e:
            return False, str(e)

    # ── Rollback: shared, durable journal (core/hardening.py) ──────────────────
    def record_change(self, kind: str, target: str, detail: str,
                      reversible: bool = True, extra: Optional[dict] = None) -> dict:
        rec = {"tool_id": "sentinel_probe", "kind": kind, "target": target,
               "detail": detail, "reversible": reversible}
        if extra:
            rec.update(extra)
        rec = hardening._journal(rec)          # durable, inspectable, atomic
        entry = dict(rec)
        entry["time"] = time.strftime("%H:%M:%S")
        self._change_journal.appendleft(entry)
        for fn in list(self._change_subs):
            try:
                fn(entry)
            except Exception:
                pass
        return entry

    def change_journal(self, limit: int = 50) -> list[dict]:
        return list(self._change_journal)[:limit]

    def revert_change(self, record_id: str) -> tuple[bool, str]:
        """Undo a journalled change: resume a process, un-quarantine a file, or
        delegate registry/file reverts to the hardening layer."""
        rec = next((r for r in hardening._load() if r.get("id") == record_id), None)
        if not rec:
            return False, "record not found"
        kind = rec.get("kind")
        if kind == "process_suspend":
            ok, msg = self.release(int(rec["target"]))
            if ok:
                hardening._mark_reverted(record_id)
            return ok, msg
        if kind == "quarantine":
            try:
                dest = rec.get("quarantined_to")
                if dest and os.path.exists(dest):
                    shutil.move(dest, rec["target"])
                    hardening._mark_reverted(record_id)
                    return True, f"restored {rec['target']}"
                return False, "quarantined copy missing"
            except Exception as e:
                return False, str(e)
        if kind in (hardening.KIND_REGISTRY, hardening.KIND_FILE, hardening.KIND_COMMAND):
            return hardening.revert(record_id)
        return False, f"'{kind}' is recorded for review but is not auto-reversible"

    # ── Self footprint (honest: the probe's OWN retained data, not the app) ────
    def self_footprint_mb(self) -> float:
        total = 0
        try:
            for d in (self._detections, self._change_journal):
                total += sys.getsizeof(d)
                for item in list(d):
                    total += sys.getsizeof(item)
                    if isinstance(item, dict):
                        total += sum(sys.getsizeof(k) + sys.getsizeof(v) for k, v in item.items())
            for m in (self._pid_names, self._rss_last):
                total += sys.getsizeof(m)
                total += sum(sys.getsizeof(k) + sys.getsizeof(v)
                             for k, v in list(m.items())[:6000])
            total += sys.getsizeof(self._conn_events)
            for k, dq in list(self._conn_events.items()):
                total += sys.getsizeof(k) + sys.getsizeof(dq)
            total += sum(sys.getsizeof(v) for v in list(self.model._baseline))
        except Exception:
            pass
        return round(total / 1e6, 2)

    # ── Feature extraction (NGAV behavioural vector) ────────────────────────────
    def _features(self, snap: Snapshot) -> list:
        lolbin_remote = no_image = suspect = 0
        max_growth = 0.0
        max_entropy = 0.0
        for pi in snap.procs:
            name = pi.get("name", "")
            max_entropy = max(max_entropy, _shannon(os.path.splitext(name)[0]))
            exe = pi.get("exe")
            if bool(exe) and not os.path.exists(exe) and pi.get("rss", 0) > 8 * 1024 * 1024:
                no_image += 1
            if name.lower() in _LOLBINS and self._pid_has_remote(pi["pid"]):
                lolbin_remote += 1
            growth = self._rss_growth(pi["pid"], pi.get("rss", 0))
            max_growth = max(max_growth, growth / 1e6)
        ips = {c["raddr_ip"] for c in snap.conns}
        for c in snap.conns:
            if c["raddr_port"] in _SUSPECT_REMOTE_PORTS:
                suspect += 1
        return [
            float(len(snap.procs)), float(len(snap.new_pids)), float(len(snap.conns)),
            float(len(ips)), float(lolbin_remote), float(no_image), round(max_growth, 2),
            float(suspect), round(len(snap.new_pids) / max(self.sample_interval, 1), 2),
            round(max_entropy, 2), float(len(self._beacon_candidates())),
        ]

    # ── Sampling internals ────────────────────────────────────────────────────
    def _sample(self) -> Snapshot:
        procs, cur_pids = [], set()
        for p in psutil.process_iter(["pid", "name", "exe", "memory_info", "ppid", "create_time"]):
            try:
                info = p.info
                pid = info["pid"]
                cur_pids.add(pid)
                rss = info["memory_info"].rss if info.get("memory_info") else 0
                procs.append({"pid": pid, "name": info.get("name") or "?",
                              "exe": info.get("exe") or "", "rss": rss,
                              "ppid": info.get("ppid"), "create_time": info.get("create_time")})
                self._pid_names[pid] = info.get("name") or "?"
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        new_pids = cur_pids - self._prev_pids if self._prev_pids else set()
        self._prev_pids = cur_pids

        conns = []
        cur_conn_set = set()
        try:
            for c in psutil.net_connections(kind="inet"):
                if c.raddr and c.pid:
                    key = (c.pid, c.raddr.ip, c.raddr.port)
                    cur_conn_set.add(key)
                    conns.append({"pid": c.pid, "raddr_ip": c.raddr.ip,
                                  "raddr_port": c.raddr.port, "status": c.status})
            # A beaconing "event" is a connection that is NEW this sample (was not
            # present last sample). A persistent connection therefore fires once.
            for (pid, ip, port) in (cur_conn_set - self._prev_conns):
                self._conn_events[(pid, ip)].append(time.time())
            self._prev_conns = cur_conn_set
            live = {(pid, ip) for (pid, ip, _p) in cur_conn_set} | {
                (pid, ip) for (pid, ip) in self._conn_events}
            for dead in [k for k in self._conn_events
                         if k[0] not in cur_pids and k not in live]:
                self._conn_events.pop(dead, None)
        except (psutil.AccessDenied, PermissionError):
            pass  # elevation needed for full conn→pid mapping; degrade gracefully

        self._last_conns = conns
        return Snapshot(ts=time.time(), procs=procs, new_pids=new_pids, conns=conns)

    def _pid_name(self, pid): return self._pid_names.get(pid, f"PID {pid}")

    def _pid_has_remote(self, pid):
        return any(c["pid"] == pid for c in getattr(self, "_last_conns", []))

    def _pid_suspect_port(self, pid):
        for c in getattr(self, "_last_conns", []):
            if c["pid"] == pid and c["raddr_port"] in _SUSPECT_REMOTE_PORTS:
                return c["raddr_port"]
        return None

    def _beacon_candidates(self) -> dict:
        """(pid, ip) -> reconnect timestamps, only where there are repeat events."""
        return {k: list(v) for k, v in self._conn_events.items() if len(v) >= 4}

    def _rss_growth(self, pid, rss):
        last = self._rss_last.get(pid, rss)
        self._rss_last[pid] = rss
        if len(self._rss_last) > 4000:
            self._rss_last = {p: r for p, r in self._rss_last.items() if p in self._prev_pids}
        return max(0, rss - last)

    def _recent_audit(self, within_s):
        now, out = time.time(), []
        for e in audit.get_entries(limit=25):
            try:
                ts = time.mktime(time.strptime(e["timestamp"], "%Y-%m-%dT%H:%M:%S"))
                if now - ts <= within_s:
                    out.append(e)
            except Exception:
                continue
        return out

    def _startup_files(self) -> set:
        """Cheap cross-platform enumeration of user-writable auto-start locations."""
        paths = set()
        home = os.path.expanduser("~")
        candidates = [
            os.path.join(home, ".config", "autostart"),                       # Linux XDG
            os.path.join(home, ".config", "systemd", "user"),                 # Linux user units
            os.path.join(home, "Library", "LaunchAgents"),                    # macOS
            os.path.join(home, "AppData", "Roaming", "Microsoft", "Windows",  # Windows Startup
                         "Start Menu", "Programs", "Startup"),
        ]
        for d in candidates:
            try:
                if os.path.isdir(d):
                    for f in os.listdir(d):
                        paths.add(os.path.join(d, f))
            except (OSError, PermissionError):
                continue
        return paths


# Module-level singleton the UI imports.
probe = ProbeEngine()


# ── Optional LLM triage factory (documented, opt-in) ────────────────────────────
def make_anthropic_verdict_fn(model: str = "claude-haiku-4-5-20251001") -> Callable[[dict], dict]:
    """Opt-in remote triage. Not wired on by default; makes no calls unless
    installed via probe.set_ai_analyzer(). Sends only tiny structural signals."""
    def _verdict(summary: dict) -> dict:
        try:
            import anthropic
            client = anthropic.Anthropic()
            prompt = (
                "You are a defensive endpoint security triage assistant. Given this "
                "structured, signature-free behavioural signal from an endpoint sensor, "
                "decide if it indicates malicious activity. Respond ONLY with compact JSON: "
                '{"malicious": bool, "confidence": 0..1, "reason": "<12 words"}.\n\n'
                + json.dumps(summary, separators=(",", ":")))
            msg = client.messages.create(model=model, max_tokens=120,
                                         messages=[{"role": "user", "content": prompt}])
            text = "".join(b.text for b in msg.content if getattr(b, "type", "") == "text")
            return json.loads(text[text.find("{"): text.rfind("}") + 1])
        except Exception:
            return {"malicious": False, "confidence": 0.0, "reason": "ai unavailable"}
    return _verdict
