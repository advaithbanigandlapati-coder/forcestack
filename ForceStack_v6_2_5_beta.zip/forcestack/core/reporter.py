"""
core/reporter.py — TXT and PDF report generation.
Issues fixed: #26 (timestamped filenames), #27 (degraded fallback signal),
              #28 (Paragraph word-wrap for NIST matrix), #29 (atomic TXT write),
              #15 (use audit.snapshot_entries() under lock)
"""

from __future__ import annotations
import datetime
import os
import platform
import logging
from pathlib import Path
from typing import Optional

from core.constants import (
    APP_NAME, APP_VERSION, CURRENT_USER, HOSTNAME,
    REPORTS_DIR, NIST_MAP, NIST_CONTROL_NAMES,
)
from core.audit import audit

log = logging.getLogger("forcestack")

PDF_ENTRY_LIMIT = 200   # entries shown in PDF (rest in CSV)


# Sentinel exception so callers know PDF degraded to TXT
class PDFUnavailable(Exception):
    """Raised when reportlab is absent and PDF was requested."""
    def __init__(self, txt_path: str):
        self.txt_path = txt_path
        super().__init__(f"reportlab not installed; saved as TXT: {txt_path}")


def _ts() -> str:
    """Fix #26: timestamp suffix so same-day reports don't overwrite."""
    return datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")


def _build_content(entries: Optional[list] = None, pdf_limit: int = 0) -> dict:
    """
    Build structured report content.
    Fix #15: caller passes pre-snapshotted entries to avoid lock contention.
    """
    if entries is None:
        entries = audit.snapshot_entries()   # fix #15: thread-safe copy

    from core.tools import ALL_TOOLS
    st    = audit.stats()
    score = audit.compliance_score(len(ALL_TOOLS))

    limited = entries[:pdf_limit] if pdf_limit else entries
    truncated = pdf_limit > 0 and len(entries) > pdf_limit

    all_controls = sorted({c for ctrls in NIST_MAP.values() for c in ctrls})
    nist_rows = []
    for ctrl in all_controls:
        tools = [tid.replace("_", " ").title() for tid, ctrls in NIST_MAP.items() if ctrl in ctrls]
        nist_rows.append((ctrl, NIST_CONTROL_NAMES.get(ctrl, ""), ", ".join(tools)))

    return {
        "generated":     datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "hostname":      HOSTNAME,
        "os":            platform.platform(),
        "user":          CURRENT_USER,
        "stats":         st,
        "score":         score,
        "entries":       limited,
        "truncated":     truncated,
        "total_entries": len(entries),
        "nist_rows":     nist_rows,
    }


# ── Text Report ───────────────────────────────────────────────────────────────
def generate_txt(path: Optional[str] = None) -> str:
    if path is None:
        REPORTS_DIR.mkdir(parents=True, exist_ok=True)
        path = str(REPORTS_DIR / f"ForceStack_Report_{_ts()}.txt")  # fix #26

    c = _build_content()
    lines = [
        "=" * 72,
        f"  {APP_NAME} v{APP_VERSION}  —  Security Hardening Report",
        f"  Generated  : {c['generated']}",
        f"  Host       : {c['hostname']}",
        f"  OS         : {c['os'][:60]}",
        f"  User       : {c['user']}",
        f"  Posture    : {c['score']}/100",
        "=" * 72, "",
        "EXECUTIVE SUMMARY",
        "-" * 72,
        f"  Total runs   : {c['stats']['total']}",
        f"  Successful   : {c['stats']['success']}",
        f"  Warnings     : {c['stats']['warnings']}",
        f"  Errors       : {c['stats']['errors']}",
        f"  Score        : {c['score']}/100", "",
        f"AUDIT LOG  ({c['total_entries']} total entries)",
        "-" * 72,
    ]
    for e in c["entries"]:
        nist_val = e.get("nist", [])
        nist_str = ", ".join(nist_val) if isinstance(nist_val, list) else str(nist_val)
        lines.append(
            f"  [{e['timestamp']}]  {e['tool_name']:<33}  {e['status'].upper():<10}  "
            f"NIST: {nist_str}"
        )
        if e.get("detail"):
            lines.append(f"      Detail   : {e['detail']}")
        lines.append(f"      Duration : {e.get('duration_s', 0):.2f}s")
        lines.append("")

    lines += [
        "NIST SP 800-53 Rev 5 CONTROL COVERAGE",
        "-" * 72,
    ]
    for ctrl, name, tools in c["nist_rows"]:
        lines.append(f"  {ctrl:<10}  {name:<45}  {tools}")

    lines += ["", "─" * 72,
              f"  {APP_NAME} v{APP_VERSION}  —  For internal compliance use only.",
              "─" * 72]

    # Fix #29: atomic write via temp → rename
    tmp = Path(path).with_suffix(".tmp")
    try:
        tmp.write_text("\n".join(lines), encoding="utf-8")
        tmp.replace(path)
        # Restrict report file to owner-read/write only (security issue #7)
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
    except (PermissionError, OSError) as e:
        # Clean up temp if present
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass
        raise OSError(f"Cannot write report to {path}: {e}") from e
    return path


# ── PDF Report ────────────────────────────────────────────────────────────────
def generate_pdf(path: Optional[str] = None) -> str:
    """
    Fix #26: timestamped filename.
    Fix #27: raises PDFUnavailable(txt_path) when reportlab absent so
             caller can inform user the format degraded.
    Fix #28: NIST matrix uses Paragraph for word-wrap.
    """
    if path is None:
        REPORTS_DIR.mkdir(parents=True, exist_ok=True)
        path = str(REPORTS_DIR / f"ForceStack_Report_{_ts()}.pdf")  # fix #26

    try:
        from reportlab.lib.pagesizes import letter
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.lib.units import inch
        from reportlab.lib import colors
        from reportlab.platypus import (
            SimpleDocTemplate, Paragraph, Spacer, Table,
            TableStyle, HRFlowable, PageBreak,
        )

        TEAL  = colors.HexColor("#00D4C0")
        LIGHT = colors.HexColor("#E4EEF8")
        MID   = colors.HexColor("#7A9FBF")
        DIM   = colors.HexColor("#4A6A8B")
        BG1   = colors.HexColor("#0F1A2E")
        BG2   = colors.HexColor("#142236")
        BG3   = colors.HexColor("#1A2D47")

        def _page_footer(canvas, doc):
            canvas.saveState()
            canvas.setFont("Helvetica", 7)
            canvas.setFillColor(MID)
            canvas.drawRightString(
                letter[0] - 0.75 * inch, 0.5 * inch,
                f"Page {doc.page}  |  {APP_NAME} v{APP_VERSION}  |  {datetime.date.today()}"
            )
            canvas.restoreState()

        doc = SimpleDocTemplate(
            path, pagesize=letter,
            leftMargin=0.75*inch, rightMargin=0.75*inch,
            topMargin=0.75*inch, bottomMargin=0.9*inch,
        )

        h1   = ParagraphStyle("h1", fontSize=20, textColor=TEAL,  fontName="Helvetica-Bold", spaceAfter=4)
        h2   = ParagraphStyle("h2", fontSize=13, textColor=LIGHT, fontName="Helvetica-Bold", spaceAfter=4)
        body = ParagraphStyle("body", fontSize=9, textColor=MID, leading=14, fontName="Helvetica")
        mono = ParagraphStyle("mono", fontSize=8, textColor=LIGHT, fontName="Courier", leading=12)
        foot = ParagraphStyle("foot", fontSize=7, textColor=DIM, fontName="Helvetica")
        # Fix #28: paragraph style for NIST matrix cells — word-wrap, not hard truncation
        cell = ParagraphStyle("cell", fontSize=7, textColor=LIGHT, fontName="Helvetica",
                               leading=9, wordWrap="CJK")

        c     = _build_content(pdf_limit=PDF_ENTRY_LIMIT)
        st    = c["stats"]
        story = []

        story.append(Paragraph(f"{APP_NAME} v{APP_VERSION}", h1))
        story.append(Paragraph("Enterprise Cybersecurity Hardening Report", h2))
        story.append(HRFlowable(width="100%", thickness=1, color=TEAL))
        story.append(Spacer(1, 8))

        meta = [
            ["Generated", c["generated"]], ["Host", c["hostname"]],
            ["OS", c["os"][:62]], ["User", c["user"]],
            ["Posture Score", f"{c['score']}/100"],
        ]
        mt = Table(meta, colWidths=[1.4*inch, 5.5*inch])
        mt.setStyle(TableStyle([
            ("FONTNAME",    (0,0),(-1,-1), "Helvetica"),
            ("FONTSIZE",    (0,0),(-1,-1), 9),
            ("TEXTCOLOR",   (0,0),(0,-1),  MID),
            ("TEXTCOLOR",   (1,0),(1,-1),  LIGHT),
            ("ROWBACKGROUNDS", (0,0),(-1,-1), [BG1, BG2]),
            ("PADDING",     (0,0),(-1,-1), 5),
        ]))
        story += [mt, Spacer(1, 16)]

        story.append(Paragraph("Executive Summary", h2))
        summary = [
            ["Metric", "Value"],
            ["Posture Score", f"{c['score']}/100"],
            ["Total Runs",    str(st["total"])],
            ["Successful",    str(st["success"])],
            ["Warnings",      str(st["warnings"])],
            ["Errors",        str(st["errors"])],
        ]
        st_tbl = Table(summary, colWidths=[3*inch, 3.9*inch])
        st_tbl.setStyle(TableStyle([
            ("BACKGROUND",  (0,0),(-1,0),  BG3),
            ("TEXTCOLOR",   (0,0),(-1,0),  TEAL),
            ("FONTNAME",    (0,0),(-1,0),  "Helvetica-Bold"),
            ("FONTSIZE",    (0,0),(-1,-1), 9),
            ("ROWBACKGROUNDS", (0,1),(-1,-1), [BG1, BG2]),
            ("TEXTCOLOR",   (0,1),(-1,-1), LIGHT),
            ("PADDING",     (0,0),(-1,-1), 6),
            ("GRID",        (0,0),(-1,-1), 0.3, colors.HexColor("#1E304D")),
        ]))
        story += [st_tbl, Spacer(1, 16)]

        if c["truncated"]:
            story.append(Paragraph(
                f"Note: Audit log limited to {PDF_ENTRY_LIMIT} of "
                f"{c['total_entries']} entries. Export as CSV for the complete record.",
                body,
            ))
            story.append(Spacer(1, 8))

        story.append(Paragraph("Audit Log", h2))
        rows = [["Timestamp", "Tool", "Status", "NIST", "Duration"]]
        for e in c["entries"]:
            s = e["status"]
            sc_hex = "#22D3A0" if s == "success" else ("#FBBF24" if s == "warning" else "#F87171")
            nist_val = e.get("nist", [])
            nist_str = ", ".join(nist_val[:2]) if isinstance(nist_val, list) else str(nist_val)[:20]
            rows.append([
                e["timestamp"][:19],
                e["tool_name"][:30],
                Paragraph(f'<font color="{sc_hex}">{s.upper()}</font>', mono),
                nist_str,
                f"{e.get('duration_s', 0):.1f}s",
            ])
        log_tbl = Table(rows, colWidths=[1.4*inch, 2.0*inch, 0.7*inch, 1.2*inch, 0.6*inch])
        log_tbl.setStyle(TableStyle([
            ("BACKGROUND",  (0,0),(-1,0),  BG3),
            ("TEXTCOLOR",   (0,0),(-1,0),  TEAL),
            ("FONTNAME",    (0,0),(-1,0),  "Helvetica-Bold"),
            ("FONTSIZE",    (0,0),(-1,-1), 7.5),
            ("ROWBACKGROUNDS", (0,1),(-1,-1), [BG1, BG2]),
            ("TEXTCOLOR",   (0,1),(-1,-1), LIGHT),
            ("PADDING",     (0,0),(-1,-1), 4),
            ("GRID",        (0,0),(-1,-1), 0.3, colors.HexColor("#1E304D")),
        ]))
        story += [log_tbl, Spacer(1, 16)]

        # NIST coverage matrix — fix #28: Paragraph cells for word-wrap
        story.append(PageBreak())
        story.append(Paragraph("NIST SP 800-53 Rev 5 Control Coverage", h2))
        nist_rows_pdf = [["Control", "Name", "Covered By Scripts"]]
        for ctrl, name, tools in c["nist_rows"]:
            nist_rows_pdf.append([
                Paragraph(ctrl, cell),
                Paragraph(name, cell),
                Paragraph(tools, cell),   # fix #28: word-wraps instead of [:55] hard cut
            ])
        nist_tbl = Table(nist_rows_pdf, colWidths=[0.7*inch, 2.4*inch, 3.8*inch])
        nist_tbl.setStyle(TableStyle([
            ("BACKGROUND",  (0,0),(-1,0),  BG3),
            ("TEXTCOLOR",   (0,0),(-1,0),  TEAL),
            ("FONTNAME",    (0,0),(-1,0),  "Helvetica-Bold"),
            ("FONTSIZE",    (0,0),(-1,-1), 7),
            ("ROWBACKGROUNDS", (0,1),(-1,-1), [BG1, BG2]),
            ("VALIGN",      (0,0),(-1,-1), "TOP"),
            ("PADDING",     (0,0),(-1,-1), 4),
            ("GRID",        (0,0),(-1,-1), 0.3, colors.HexColor("#1E304D")),
        ]))
        story += [nist_tbl, Spacer(1, 8)]

        story.append(HRFlowable(width="100%", thickness=0.5, color=MID))
        story.append(Spacer(1, 4))
        story.append(Paragraph(
            f"{APP_NAME} v{APP_VERSION}  —  For internal compliance use only.", foot
        ))

        doc.build(story, onFirstPage=_page_footer, onLaterPages=_page_footer)
        # Restrict to owner-read/write only (security issue #7)
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
        return path

    except ImportError:
        # Fix #27: raise PDFUnavailable with the txt_path so caller can
        # tell the user exactly what happened rather than silently returning
        # a .pdf path that points at a .txt file.
        txt_path = str(Path(path).with_suffix(".txt"))
        generate_txt(txt_path)
        raise PDFUnavailable(txt_path) from None
