"""
core/runner.py — Script execution engine.
Issues fixed: #22 (per-tool timeout), #23 (module cache note), #24 (unique thread names),
              #25 (audit before done_cb documented), #31 (ScriptResult type + runtime check),
              #50 (structured dict emit: intercept payload, show title+fix in terminal, fire toast_cb),
              #55 (dry-run holder missing tname — IndexError on result_holder[2]),
              #56 (_make_emit factory removes duplicated _emit closure between run_script/run_all)
"""

from __future__ import annotations
import threading
import time
import importlib
import logging
from typing import Callable, List, Optional, Tuple

from core.audit import audit
from core.constants import OS_NAME
from core.utils import TIMEOUT_LONG

log = logging.getLogger("forcestack")

# Fix #31: canonical return type for all script execute() functions
ScriptResult = Tuple[bool, str]

OutputCB = Callable[[str, str], None]         # (line, level)
DoneCB   = Callable[[bool, str, float], None]  # (success, detail, duration_s)
ToastCB  = Callable[[dict], None]              # structured error payload → display toast


def _make_emit(
    output_cb: OutputCB,
    payload_list: list,
) -> Callable:
    """
    Fix #56: factory that returns a dict-intercepting emit callable.
    Replaces the duplicated _emit closure that previously existed in both
    run_script and run_all.

    Intercepts dict payloads (structured ErrorPayload errors), writes the
    title and first fix line to the terminal via output_cb, and appends
    the full payload to payload_list for toast_cb to consume after the
    script completes. Plain string lines pass through unchanged.
    """
    def _emit(line, level: str = "info") -> None:
        if isinstance(line, dict):
            payload_list.append(line)
            output_cb(
                f"  {'ERR' if level == 'err' else 'WARN'}  "
                f"{line.get('title', 'Error occurred')}",
                level,
            )
            fix = line.get("fix", "")
            if fix:
                output_cb(f"  →  {fix.splitlines()[0]}", "info")
        else:
            output_cb(line, level)
    return _emit


def _load_module(tool_id: str):
    """
    Load (or retrieve cached) script module.
    Fix #23: importlib caches in sys.modules — scripts must be stateless
    at module level for multiple run_all() invocations to be safe.
    """
    return importlib.import_module(f"scripts.{tool_id}")


def _validate_result(result, tool_id: str) -> ScriptResult:
    """
    Fix #31: runtime validation that execute() returned (bool, str).
    A mistyped script returning (str, bool) raises immediately rather than
    silently corrupting the audit log.
    """
    if (
        not isinstance(result, tuple)
        or len(result) != 2
        or not isinstance(result[0], bool)
        or not isinstance(result[1], str)
    ):
        raise TypeError(
            f"scripts/{tool_id}.py execute() must return (bool, str), "
            f"got {type(result)}: {result!r}"
        )
    return result


def run_script(
    tool_id: str,
    output_cb: OutputCB,
    done_cb: DoneCB,
    dry_run: bool = False,
    toast_cb: Optional[ToastCB] = None,
) -> threading.Thread:
    """Execute a single script in a daemon thread. Returns thread for caller to store."""

    def _worker():
        t0        = time.time()
        tool_name = tool_id
        _error_payloads: list[dict] = []

        # Fix #56: use shared factory instead of duplicated closure
        _emit = _make_emit(output_cb, _error_payloads)

        try:
            mod       = _load_module(tool_id)
            tool_name = getattr(mod, "TOOL_NAME", tool_id)

            if dry_run:
                _emit(f"  [DRY RUN] Would execute: {tool_name}", "info")
                _emit("  No system changes made.", "info")
                ok, detail = True, "dry-run"
            else:
                raw    = mod.execute(_emit, OS_NAME)
                ok, detail = _validate_result(raw, tool_id)  # fix #31

        except ModuleNotFoundError:
            _emit(f"  Script 'scripts/{tool_id}.py' not found.", "err")
            ok, detail = False, "module not found"
            log.error("Missing script module: %s", tool_id)
        except TypeError as e:
            _emit(f"  Script return-type error: {e}", "err")
            ok, detail = False, str(e)
        except Exception as e:
            _emit(f"  Unexpected error: {e}", "err")
            ok, detail = False, str(e)
            log.exception("Script %s crashed", tool_id)

        duration = time.time() - t0
        status   = "success" if ok else "error"

        # Fix #25: audit.record() BEFORE done_cb so UI re-renders always see the entry
        audit.record(tool_id, tool_name, status, detail, duration)
        done_cb(ok, detail, duration)
        # Fix #50: fire toast_cb for any structured error payloads stashed during execution
        if toast_cb and _error_payloads:
            for payload in _error_payloads:
                toast_cb(payload)

    # Fix #24: unique thread name with timestamp
    t = threading.Thread(
        target=_worker, daemon=True,
        name=f"forcestack-{tool_id}-{int(time.time())}"
    )
    t.start()
    return t


def run_all(
    tool_ids: List[str],
    output_cb: OutputCB,
    per_tool_done_cb: Callable[[str, bool, str], None],
    all_done_cb: Callable[[int, int], None],
    stop_event: Optional[threading.Event] = None,
    dry_run: bool = False,
    toast_cb: Optional[ToastCB] = None,
    # Fix #57: three optional callbacks that let the UI wire run_all without
    # reimplementing the loop. All default to None for full headless compatibility.
    per_tool_start_cb: Optional[Callable[[str], None]] = None,
    tool_output_cb: Optional[Callable[[str, str, str], None]] = None,
    # (tid, line, level) — per-tool terminal routing; falls back to output_cb
    progress_cb: Optional[Callable[[float], None]] = None,
    # (fraction 0.0–1.0) — called after each tool completes
) -> threading.Thread:
    """
    Run all tools sequentially in a daemon thread.

    Headless usage (all optional callbacks omitted):
        run_all(tool_ids, output_cb, per_tool_done_cb, all_done_cb)

    UI usage (per-tool routing + progress):
        run_all(tool_ids, output_cb, per_tool_done_cb, all_done_cb,
                stop_event=stop, toast_cb=self._show_toast,
                per_tool_start_cb=_mark_running,
                tool_output_cb=_per_emit,
                progress_cb=prog.set_target)
    """
    total = len(tool_ids)

    def _worker():
        passed = 0
        failed = 0

        for i, tool_id in enumerate(tool_ids):
            if stop_event and stop_event.is_set():
                output_cb("▸ Run All stopped by user.", "warn")
                break

            output_cb(f"\n{'═' * 58}", "info")
            output_cb(f"  {tool_id.replace('_', ' ').title()}", "info")
            output_cb(f"{'═' * 58}", "info")

            # Notify UI that this tool is now running
            if per_tool_start_cb:
                per_tool_start_cb(tool_id)

            t0        = time.time()
            tool_name = tool_id

            # Fix #22: per-tool timeout via a sub-thread with join timeout
            result_holder: list = [False, "timeout", tool_id]  # [ok, detail, tool_name]
            sub_done = threading.Event()
            _error_payloads: list[dict] = []

            # Fix #56: use shared factory.
            # Fix #57: if tool_output_cb provided, route per-tool output through it;
            # otherwise fall back to output_cb (headless path unchanged).
            _base_cb: OutputCB = (
                (lambda line, lv, t=tool_id: tool_output_cb(t, line, lv))
                if tool_output_cb else output_cb
            )
            _emit = _make_emit(_base_cb, _error_payloads)

            def _sub(tid=tool_id, holder=result_holder, done_evt=sub_done,
                     emit=_emit):
                try:
                    mod  = _load_module(tid)
                    tname = getattr(mod, "TOOL_NAME", tid)
                    if dry_run:
                        emit(f"  [DRY RUN] {tname}", "info")
                        # Fix #55: include tname so result_holder[2] doesn't IndexError
                        holder[:] = [True, "dry-run", tname]
                    else:
                        raw = mod.execute(emit, OS_NAME)
                        ok2, det2 = _validate_result(raw, tid)
                        holder[:] = [ok2, det2, tname]
                except Exception as exc:
                    emit(f"  Error: {exc}", "err")
                    holder[:] = [False, str(exc), tid]
                    log.exception("run_all sub: %s", tid)
                finally:
                    done_evt.set()

            # Fix #57 / Fix #24: sub-thread names now include run-start timestamp
            # for uniqueness across sequential run-all invocations
            sub_thread = threading.Thread(
                target=_sub, daemon=True,
                name=f"forcestack-sub-{tool_id}-{int(time.time())}"
            )
            sub_thread.start()
            if not sub_done.wait(timeout=TIMEOUT_LONG * 2):
                output_cb(f"  TIMEOUT after {TIMEOUT_LONG * 2}s — skipping", "err")
                result_holder[:] = [False, "timeout", tool_id]  # fix #28: mutate in-place
            sub_thread.join(timeout=1)

            ok, detail, tool_name = result_holder[0], result_holder[1], result_holder[2]
            duration = time.time() - t0
            status   = "success" if ok else "error"

            # Fix #25: audit before callback (documented ordering)
            audit.record(tool_id, tool_name, status, detail, duration)
            per_tool_done_cb(tool_id, ok, detail)
            # Fix #50 (run_all): fire toast_cb for any structured payloads from this tool
            if toast_cb and _error_payloads:
                for payload in _error_payloads:
                    toast_cb(payload)
            # Progress callback — after done_cb so UI state is consistent
            if progress_cb and total:
                progress_cb((i + 1) / total)

            if ok:
                passed += 1
            else:
                failed += 1

        all_done_cb(passed, failed)

    t = threading.Thread(
        target=_worker, daemon=True,
        name=f"forcestack-run-all-{int(time.time())}"   # fix #24
    )
    t.start()
    return t
