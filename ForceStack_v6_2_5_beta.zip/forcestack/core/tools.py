"""
core/tools.py — Canonical tool registry.
Single source of truth for all 20 tool definitions.
Imported by runner.py, reporter.py, and ui/app.py.
Fixes: #46 (ALL_TOOLS in ui module), #10 (NIST_MAP completeness)
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import List


@dataclass
class Tool:
    id:         str
    icon:       str
    name:       str
    short:      str
    desc:       str
    nist:       List[str]
    cis:        str
    risk:       str        # "low" | "medium" | "high" | "critical"
    section:    str
    confirm:    bool = False   # True = show confirmation dialog before running (#38)
    how_to_fix: str  = ""     # Plain-English remediation for issues this tool discovers


ALL_TOOLS: List[Tool] = [
    # ── System Hardening ──────────────────────────────────────────────
    Tool(
        id="disable_services", icon="🛡",
        name="Disable Risky Services",
        short="Turns off legacy and exploitable system services",
        desc=(
            "Disables services like Telnet, FTP, SMBv1, SSDP, and Remote Registry that "
            "are rarely needed but constantly exploited. Attackers scan entire IP ranges "
            "for these open doors within seconds. Eliminating them shrinks your attack "
            "surface without impacting everyday operations."
        ),
        nist=["CM-7", "AC-17", "SI-3"], cis="4.8", risk="medium", section="hardening",
        how_to_fix=(
            "Windows: Win+R → services.msc → right-click each flagged service → "
            "Properties → Startup type: Disabled → Stop.\n"
            "Linux: sudo systemctl disable --now <service-name>\n"
            "macOS: System Settings → Sharing → turn off Remote Login, Remote Management, "
            "File Sharing (each is a separate service toggle).\n"
            "Verify nothing breaks: test normal workflows before assuming it's safe to leave disabled."
        ),
    ),
    Tool(
        id="firewall_config", icon="🔥",
        name="Configure Firewall",
        short="Default-deny inbound policy and blocks dangerous ports",
        desc=(
            "Enables the host-based firewall and enforces a default-deny inbound ruleset. "
            "Only traffic you explicitly allow gets through. Firewall logging is enabled "
            "for incident response (NIST AU-12). Redundant per-port rules are avoided — "
            "the default-deny policy already covers them."
        ),
        nist=["SC-7", "CA-3", "AC-4"], cis="12.1", risk="low", section="hardening",
        how_to_fix=(
            "Windows: Search → 'Windows Defender Firewall' → Turn Windows Defender Firewall on "
            "(both private and public).\n"
            "macOS: System Settings → Network → Firewall → Turn On Firewall.\n"
            "Linux: sudo ufw enable && sudo ufw default deny incoming && sudo ufw default allow outgoing\n"
            "This tool applies these settings automatically when run as Administrator/root."
        ),
    ),
    Tool(
        id="usb_lockdown", icon="🔌",
        name="USB Lockdown",
        short="Blocks malicious USB devices from auto-executing or mounting",
        desc=(
            "Disables AutoRun, AutoPlay, and the USB storage class driver on Windows. "
            "BadUSB and rubber ducky attacks rely entirely on auto-execution. "
            "Note: this disables USB drives for ALL users including administrators — "
            "ensure you have alternative recovery media before applying. "
            "macOS limitation: only disables Finder auto-open; drives still mount. "
            "Full macOS USB block requires MDM (Jamf/Mosyle)."
        ),
        nist=["MP-7", "AC-19", "SC-41"], cis="10.3", risk="medium", section="hardening",
        confirm=True,
        how_to_fix=(
            "This tool disables USB auto-run automatically. To re-enable USB drives later:\n"
            "Windows: Device Manager → Universal Serial Bus controllers → "
            "right-click USB Mass Storage Driver → Enable device.\n"
            "macOS: Full USB block requires MDM (Jamf/Mosyle). This tool only disables "
            "Finder auto-open — physical USB drives will still mount.\n"
            "Important: keep a recovery USB or alternative access method before applying on servers."
        ),
    ),
    Tool(
        id="encryption_check", icon="🔐",
        name="Full-Disk Encryption Check",
        short="Verifies BitLocker / FileVault / LUKS is active",
        desc=(
            "Without full-disk encryption, a stolen laptop gives an attacker instant "
            "access to every file — no password bypass needed. This tool checks encryption "
            "status on all drives and provides step-by-step remediation guidance. "
            "Aligns with NIST SC-28."
        ),
        nist=["SC-28", "SC-12", "CP-9"], cis="3.6", risk="critical", section="hardening",
        how_to_fix=(
            "Windows: Settings → System → BitLocker → Turn on BitLocker. "
            "Save your recovery key to a USB or your Microsoft account — losing it means "
            "permanent data loss. Encryption takes 1–4 hours on a full drive.\n"
            "macOS: System Settings → Privacy & Security → FileVault → Turn On FileVault. "
            "Save the recovery key shown — you will need it if you forget your password.\n"
            "Linux: Encryption must be set up at install time (LUKS). If not already encrypted, "
            "you must back up all data, reinstall with 'Encrypt disk' checked, and restore."
        ),
    ),
    Tool(
        id="rdp_hardening", icon="🖥",
        name="Harden Remote Desktop / SSH",
        short="Enforces NLA, TLS, and disables RDP if not needed",
        desc=(
            "RDP is the most scanned service on the internet. Enforces Network Level "
            "Authentication, requires TLS transport, disables clipboard redirection to "
            "prevent data exfiltration, and can disable RDP entirely. SSH hardened on "
            "Linux/macOS with modern crypto suites only."
        ),
        nist=["AC-17", "IA-2", "SC-8"], cis="4.1", risk="high", section="hardening",
        confirm=True,
        how_to_fix=(
            "RDP: disable it when not in use. Windows: Settings → System → Remote Desktop → Off.\n"
            "When RDP is needed: always place it behind a VPN — never expose port 3389 directly "
            "to the internet. Change the RDP port from 3389 to a non-standard port as an "
            "additional layer.\n"
            "SSH (Linux/macOS): if not needed, sudo systemctl stop ssh && sudo systemctl disable ssh.\n"
            "If SSH is needed: ensure only key-based auth is configured "
            "(PasswordAuthentication no in sshd_config) and restrict to known IPs via firewall."
        ),
    ),
    Tool(
        id="screen_lock", icon="🌑",
        name="Screen Lock Timeout",
        short="Enforces 10-minute idle lock with password required",
        desc=(
            "Walk-up access to an unattended workstation is a classic and underestimated "
            "threat. Enforces a 10-minute screen lock with an immediate password requirement "
            "on resume. Ctrl+Alt+Del required to unlock on Windows. Aligns with NIST AC-11."
        ),
        nist=["AC-11", "AC-12", "IA-11"], cis="4.3", risk="low", section="hardening",
        how_to_fix=(
            "This tool applies the setting automatically. To set manually:\n"
            "Windows: Settings → System → Power & Sleep → Screen: 5 minutes. "
            "Settings → Accounts → Sign-in options → Require sign-in: When PC wakes from sleep.\n"
            "macOS: System Settings → Screen Saver → Start after: 5 min. "
            "Privacy & Security → Require password: immediately after sleep or screen saver.\n"
            "Linux (GNOME): Settings → Privacy → Screen Lock → Blank screen delay: 5 min, "
            "Automatic Screen Lock Delay: immediately."
        ),
    ),
    # ── Passwords & Accounts ──────────────────────────────────────────
    Tool(
        id="nist_password", icon="📋",
        name="NIST Password Policy",
        short="Applies NIST SP 800-63B compliant password rules",
        desc=(
            "Modern NIST guidance (SP 800-63B) says longer is better, complexity rules "
            "backfire, and frequent resets cause weak passwords. Sets minimum 15-char "
            "length, 365-day max age, 24-password history — without arbitrary complexity "
            "requirements."
        ),
        nist=["IA-5", "IA-11", "AC-2"], cis="5.2", risk="low", section="passwords",
        how_to_fix=(
            "This tool applies NIST SP 800-63B policy automatically with admin/root access.\n"
            "Windows manual: Group Policy → Computer Configuration → Windows Settings → "
            "Security Settings → Account Policies → Password Policy → set Minimum password length: 15.\n"
            "macOS manual: System Settings → Users & Groups → Password policies (macOS 14+) or "
            "use this tool with sudo.\n"
            "Linux manual: sudo nano /etc/security/pwquality.conf → add 'minlen = 15'\n"
            "For all users: prompt them to update passwords that don't meet the new minimum — "
            "existing passwords are not forced to change until expiry."
        ),
    ),
    Tool(
        id="admin_audit", icon="👤",
        name="Local Admin Auditor",
        short="Lists all privileged accounts for review",
        desc=(
            "Shadow admin accounts are a primary attacker persistence technique. Malware "
            "and insider threats create hidden admin accounts that survive reboots. "
            "Enumerates every privileged account across admin groups, scheduled tasks, "
            "and services. Requires your manual review of the results."
        ),
        nist=["AC-2", "AC-6", "IA-4"], cis="5.1", risk="medium", section="passwords",
        how_to_fix=(
            "This tool lists — it does not change anything. You must review the output.\n"
            "For any admin account you don't recognize:\n"
            "Windows: net user <username> /delete (or Computer Management → Local Users and Groups)\n"
            "Linux: sudo deluser <username> sudo (removes from sudo group without deleting account)\n"
            "macOS: System Settings → Users & Groups → click user → uncheck "
            "'Allow user to administer this computer'\n"
            "Document every legitimate admin account and review this list monthly."
        ),
    ),
    Tool(
        id="guest_disable", icon="🚫",
        name="Disable Guest Account",
        short="Removes unauthenticated access via built-in guest",
        desc=(
            "The built-in Guest account grants access without any password, and is "
            "flagged in every major compliance framework. Also blocks anonymous network "
            "enumeration — which lets attackers list shares and users without credentials."
        ),
        nist=["AC-2", "AC-3", "IA-2"], cis="5.1", risk="low", section="passwords",
        how_to_fix=(
            "This tool disables the guest account automatically.\n"
            "Windows manual: Control Panel → User Accounts → Manage Accounts → Guest → Turn off.\n"
            "macOS manual: System Settings → Users & Groups → Guest User → toggle 'Allow guests "
            "to log in to this computer' off.\n"
            "Linux: sudo passwd -l guest (locks the account). "
            "If guest user doesn't exist, no action needed."
        ),
    ),
    Tool(
        id="account_lockout", icon="🔒",
        name="Account Lockout Policy",
        short="Locks accounts after 5 failed login attempts",
        desc=(
            "Online brute-force and password-spray attacks depend on unlimited login "
            "attempts. Locking accounts after 5 failures within 15 minutes stops these "
            "attacks immediately. Duration is 30 minutes. Applies even_deny_root on "
            "Linux to prevent root account brute-force."
        ),
        nist=["AC-7", "SI-10", "IA-5"], cis="5.2", risk="medium", section="passwords",
        how_to_fix=(
            "This tool applies lockout policy automatically.\n"
            "Windows manual: Group Policy → Computer Config → Windows Settings → Security Settings "
            "→ Account Policies → Account Lockout Policy → Threshold: 5, Duration: 30 min.\n"
            "Linux manual: sudo apt install libpam-faillock → edit /etc/pam.d/common-auth → "
            "add 'auth required pam_faillock.so deny=5 unlock_time=1800'\n"
            "macOS manual: sudo pwpolicy -setaccountpolicies (complex — use this tool).\n"
            "Note: this will lock out your own account if you mistype your password 5 times — "
            "ensure you know your admin password before applying."
        ),
    ),
    # ── Threat Scanning ───────────────────────────────────────────────
    Tool(
        id="audit_logging", icon="📝",
        name="Enable Audit Logging",
        short="Turns on comprehensive system event and security logging",
        desc=(
            "You cannot detect or investigate what you don't log. Enables all NIST AU-2 "
            "required event categories: logon/logoff, privilege use, account changes, "
            "object access, and policy changes. PowerShell Script Block Logging and "
            "process command-line logging enabled on Windows."
        ),
        nist=["AU-2", "AU-3", "AU-12"], cis="8.1", risk="low", section="scanning",
        how_to_fix=(
            "This tool enables logging automatically.\n"
            "Windows manual: Event Viewer → look for Security logs. If empty: Group Policy → "
            "Computer Config → Security Settings → Advanced Audit Policy Configuration → "
            "enable Logon/Logoff, Account Management, Policy Change.\n"
            "Linux manual: sudo systemctl enable --now auditd && sudo systemctl enable --now rsyslog\n"
            "macOS: audit daemon runs by default — this tool configures additional categories.\n"
            "After enabling: check logs monthly. Windows Event IDs 4624 (logon), "
            "4625 (failed logon), and 4720 (new account created) are the highest priority."
        ),
    ),
    Tool(
        id="open_ports", icon="🌐",
        name="Open Ports Scanner",
        short="Lists all services listening on the network",
        desc=(
            "Every open port is a potential entry point. Scans all listening ports "
            "locally, identifies the owning process, and flags well-known dangerous "
            "ports: RDP, SMB, VNC, Telnet, FTP, Metasploit default (4444), MongoDB, "
            "Oracle, and more. Requires admin for process names on Linux."
        ),
        nist=["CM-7", "RA-5", "SC-7"], cis="9.2", risk="medium", section="scanning",
        how_to_fix=(
            "For each risky port flagged:\n"
            "1. Identify the service: the owning process name is shown next to the port.\n"
            "2. If you don't need it: stop and disable the service.\n"
            "   Linux: sudo systemctl stop <service> && sudo systemctl disable <service>\n"
            "   Windows: services.msc → right-click → Stop → Properties → Startup: Disabled\n"
            "3. Block it at the firewall even if you disable the service (defence in depth):\n"
            "   Linux: sudo ufw deny <port>\n"
            "   Windows: Windows Firewall → Inbound Rules → New Rule → Port → Block\n"
            "4. If you can't identify the process, run the Startup Auditor and AV check next."
        ),
    ),
    Tool(
        id="startup_audit", icon="🚀",
        name="Startup Items Auditor",
        short="Finds all programs that launch at boot",
        desc=(
            "Malware universally establishes persistence via startup mechanisms to survive "
            "reboots. Checks all registry Run keys, scheduled tasks, LaunchAgents/Daemons "
            "on macOS, and systemd services on Linux. Results require manual review — "
            "flagging is heuristic, not definitive."
        ),
        nist=["CM-7", "SI-3", "CM-8"], cis="10.6", risk="high", section="scanning",
        how_to_fix=(
            "This tool lists — it does not remove anything. Each flagged item needs your review.\n"
            "For each entry you don't recognize:\n"
            "1. Search the exact name online — most will be legitimate installed software.\n"
            "2. If you still can't identify it:\n"
            "   Windows: reg delete \"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run\" "
            "/v \"<name>\" /f  (or right-click in Task Manager → Startup → Disable)\n"
            "   macOS: launchctl unload ~/Library/LaunchAgents/<name>.plist\n"
            "   Linux: sudo systemctl disable --now <service>\n"
            "3. Reboot and check if it reappears — if it does, run the AV scan immediately."
        ),
    ),
    Tool(
        id="av_status", icon="🦠",
        name="Antivirus and EDR Status",
        short="Verifies AV is running, current, and tamper-protected",
        desc=(
            "An AV with outdated signatures is nearly as useless as no AV. Checks Windows "
            "Defender status, real-time protection, tamper protection, and signature age "
            "via Get-CimInstance (not deprecated WMI). Checks for third-party AV and "
            "Linux/macOS equivalents."
        ),
        nist=["SI-3", "SI-8", "RA-5"], cis="10.1", risk="high", section="scanning",
        how_to_fix=(
            "Windows — if real-time protection is off:\n"
            "Open Windows Security (search in Start) → Virus & threat protection → "
            "Virus & threat protection settings → turn on Real-time protection.\n"
            "If it won't turn on: check if a third-party AV disabled it, or run "
            "'sfc /scannow' in an Administrator command prompt to repair system files.\n"
            "macOS — if Gatekeeper is off:\n"
            "System Settings → Privacy & Security → Security → select "
            "'App Store and identified developers'.\n"
            "Linux — to install ClamAV:\n"
            "sudo apt install clamav clamav-daemon && sudo freshclam && "
            "sudo systemctl enable --now clamav-freshclam"
        ),
    ),
    Tool(
        id="cve_scan", icon="🔍",
        name="CVE Vulnerability Scanner",
        short="Checks installed software versions against known CVEs",
        desc=(
            "Unpatched software is the #1 initial access vector in enterprise breaches. "
            "Enumerates installed applications via Get-Package / winget (not deprecated "
            "WMIC), checks for pending security updates, and integrates with safety and "
            "Trivy if available. NVD links provided for manual CVE lookup."
        ),
        nist=["RA-5", "SI-2", "CM-8"], cis="7.1", risk="high", section="scanning",
        how_to_fix=(
            "For each flagged outdated package:\n"
            "Windows: Settings → Windows Update → Check for updates. "
            "For third-party apps: winget upgrade --all (in Administrator terminal).\n"
            "macOS: App Store → Updates tab. For Homebrew packages: brew upgrade.\n"
            "Linux: sudo apt update && sudo apt upgrade (Debian/Ubuntu)  or  "
            "sudo dnf upgrade (Fedora/RHEL)\n"
            "For software with a known CVE and no update available: evaluate whether it can "
            "be uninstalled or isolated. Check https://nvd.nist.gov for severity and workarounds.\n"
            "Re-run this scan after updating to confirm the vulnerability is closed."
        ),
    ),
    # ── Network Security ──────────────────────────────────────────────
    Tool(
        id="dns_over_https", icon="🌍",
        name="DNS-over-HTTPS",
        short="Encrypts DNS lookups to prevent snooping and hijacking",
        desc=(
            "Standard DNS queries are unencrypted plaintext — visible to your ISP and "
            "network attackers. DNS-over-HTTPS encrypts every lookup. Sets Cloudflare "
            "and Google as resolvers, detected dynamically across all network interfaces "
            "regardless of interface name or locale."
        ),
        nist=["SC-20", "SC-21", "SC-22"], cis="9.2", risk="low", section="network",
        how_to_fix=(
            "This tool applies DoH configuration automatically.\n"
            "To verify it worked: open a terminal and run 'nslookup example.com 1.1.1.1' — "
            "it should return an IP address.\n"
            "Windows manual (if tool failed):\n"
            "Settings → Network & Internet → select your adapter → DNS server assignment → "
            "Edit → Manual → enter 1.1.1.1 and 8.8.8.8 → DNS over HTTPS: On.\n"
            "macOS manual: System Settings → Network → select adapter → DNS → "
            "add 1.1.1.1 and 8.8.8.8.\n"
            "Linux manual: edit /etc/systemd/resolved.conf → add DNS=1.1.1.1 and DNSOverTLS=yes "
            "→ sudo systemctl restart systemd-resolved"
        ),
    ),
    Tool(
        id="wifi_security", icon="📡",
        name="Wi-Fi Security Audit",
        short="Flags weak protocols (WEP/WPA1) and open networks",
        desc=(
            "WEP can be cracked in under 60 seconds with freely available tools. "
            "WPA (v1) with TKIP is nearly as weak. Audits all saved and visible wireless "
            "networks, flags dangerous security configurations, and reports the active "
            "connection's security level."
        ),
        nist=["SC-8", "AC-18", "SC-7"], cis="12.3", risk="medium", section="network",
        how_to_fix=(
            "To fix weak Wi-Fi security:\n"
            "1. Log in to your router admin page — usually http://192.168.1.1 or "
            "http://192.168.0.1 (printed on the bottom of your router).\n"
            "2. Find Wireless Settings → Security Mode → change to WPA2 (AES/CCMP) or WPA3.\n"
            "3. Save and reconnect all devices using the same password.\n"
            "Remove old weak profiles after the router is fixed:\n"
            "Windows: Settings → Network & Internet → Wi-Fi → Manage known networks → "
            "Forget the old network, then reconnect.\n"
            "macOS: System Settings → Wi-Fi → Known Networks → remove old entry.\n"
            "Linux: nmcli connection delete '<network name>'"
        ),
    ),
    Tool(
        id="hosts_blocklist", icon="🚧",
        name="Hosts File Blocklist",
        short="Blocks known malware, phishing, and tracking domains at OS level",
        desc=(
            "Adds malicious domain entries to your system hosts file, blocking malware "
            "C2 communication before any network connection is made. Ships with "
            "instructions to integrate the StevenBlack 50,000-domain unified list. "
            "Existing ForceStack entries are removed before re-applying to ensure idempotency."
        ),
        nist=["SC-7", "SI-3", "SC-20"], cis="9.3", risk="low", section="network",
        how_to_fix=(
            "This tool applies the blocklist automatically — requires Administrator/root.\n"
            "To undo: open your hosts file and remove lines between the "
            "'# ForceStack SC-7' markers.\n"
            "  Windows: C:\\Windows\\System32\\drivers\\etc\\hosts (open as Administrator)\n"
            "  Linux/macOS: /etc/hosts (sudo nano /etc/hosts)\n"
            "To update to the latest StevenBlack list: re-run this tool. "
            "The blocklist is always replaced, never duplicated.\n"
            "If a legitimate site is blocked: remove its '0.0.0.0' entry from the hosts file "
            "or add it to a whitelist by placing '127.0.0.1 <domain>' before the block section."
        ),
    ),
    # ── Compliance & Patching ─────────────────────────────────────────
    Tool(
        id="auto_updates", icon="🔄",
        name="Automatic Updates and Patching",
        short="Enables automatic security patch installation",
        desc=(
            "Unpatched vulnerabilities are exploited within hours of CVE publication. "
            "Enables unattended-upgrades on Linux, automatic macOS updates, or Windows "
            "Update auto-install scheduled for 3 AM. Also reports currently pending updates "
            "so you can act immediately."
        ),
        nist=["SI-2", "CM-3", "SI-7"], cis="7.3", risk="medium", section="compliance",
        how_to_fix=(
            "This tool enables automatic updates — requires Administrator/root.\n"
            "Windows manual: Settings → Windows Update → Advanced options → "
            "Automatic (recommended) → Download updates over metered connections: on.\n"
            "macOS manual: System Settings → General → Software Update → "
            "click the ⓘ icon → turn on all automatic options.\n"
            "Linux manual: sudo apt install unattended-upgrades && "
            "sudo dpkg-reconfigure unattended-upgrades\n"
            "After enabling: run the update check immediately:\n"
            "  Windows: Settings → Windows Update → Check for updates\n"
            "  Linux: sudo apt update && sudo apt upgrade\n"
            "  macOS: System Settings → General → Software Update"
        ),
    ),
    Tool(
        id="tls_config", icon="🔑",
        name="TLS and SSL Hardening",
        short="Disables SSLv3/TLS 1.0/1.1 and enforces TLS 1.2+ with strong ciphers",
        desc=(
            "SSLv3, TLS 1.0, and TLS 1.1 are vulnerable to POODLE, BEAST, SWEET32, and "
            "Lucky13 attacks. Disables all weak protocol versions and cipher suites via "
            "Windows Schannel registry keys. Generates an nginx hardening snippet and "
            "hardens SSH crypto on Linux. Network test is skipped on air-gapped machines."
        ),
        nist=["SC-8", "SC-23", "SC-17"], cis="9.4", risk="medium", section="compliance",
        confirm=True,
        how_to_fix=(
            "This tool disables weak TLS versions automatically.\n"
            "Windows: requires a reboot after registry changes take effect.\n"
            "To verify: after reboot, run 'nmap --script ssl-enum-ciphers -p 443 localhost' — "
            "TLS 1.0 and 1.1 should no longer appear.\n"
            "Linux (nginx): the tool outputs a hardened nginx snippet. Apply it:\n"
            "  sudo nano /etc/nginx/nginx.conf → replace ssl_protocols line with "
            "'ssl_protocols TLSv1.2 TLSv1.3;'\n"
            "  sudo nginx -t && sudo systemctl reload nginx\n"
            "If an application breaks after disabling TLS 1.0/1.1: that application needs "
            "to be updated — disabling weak TLS is correct and the application is the problem."
        ),
    ),

    # ── Advanced Hardening "superscripts" (comprehensive, fully reversible) ──
    Tool(
        id="kernel_hardening", icon="🧬",
        name="Kernel & Network Stack Hardening",
        short="Applies a vetted set of kernel/network sysctl protections",
        desc=(
            "Applies a bundle of kernel and network-stack protections in one pass: "
            "restricts kernel pointer/dmesg exposure, limits ptrace, enables SYN-cookie "
            "flood protection and reverse-path filtering, ignores ICMP redirects and "
            "source-routed packets, and hardens hardlink/symlink and core-dump behaviour. "
            "Every value is written through the apply-verify-rollback layer, so the whole "
            "bundle can be undone from the Change Journal."
        ),
        nist=["SC-7", "SI-3", "CM-7"], cis="3.3", risk="high", section="hardening",
        confirm=True,
        how_to_fix=(
            "Linux: writes /etc/sysctl.d/99-forcestack-hardening.conf and reloads with "
            "'sudo sysctl --system'. Revert removes the file and reloads.\n"
            "Windows: sets Tcpip parameters (source-routing, ICMP redirects, SYN attack "
            "protection) via registry; revert restores the prior values."
        ),
    ),
    Tool(
        id="smb_protocol_lockdown", icon="📡",
        name="Legacy Protocol Lockdown",
        short="Disables SMBv1, LLMNR and requires SMB signing",
        desc=(
            "Shuts the doors used by worms and lateral-movement tooling: disables the "
            "obsolete SMBv1 protocol (the EternalBlue/WannaCry vector), requires SMB "
            "packet signing to block relay attacks, and turns off LLMNR name resolution "
            "(a classic credential-poisoning path). Each change is verified and reversible."
        ),
        nist=["CM-7", "SC-8", "AC-17"], cis="4.8", risk="high", section="hardening",
        confirm=True,
        how_to_fix=(
            "Windows: sets LanmanServer/LanmanWorkstation and DNSClient policy registry "
            "keys; revert restores prior values.\n"
            "Linux/macOS: SMBv1 is not enabled by default; the tool reports status only."
        ),
    ),
    Tool(
        id="credential_protection", icon="🛡",
        name="Credential Theft Protection",
        short="Blocks cleartext credential caching and LSASS scraping",
        desc=(
            "Hardens the store attackers go after first: enables LSA Protection (RunAsPPL) "
            "so tools like Mimikatz can't read LSASS, disables WDigest cleartext credential "
            "caching, forces NTLMv2-only, and shrinks the number of cached domain logons. "
            "On Linux it strengthens password hashing and default umask. All reversible."
        ),
        nist=["IA-5", "AC-3", "AC-6"], cis="5.4", risk="high", section="hardening",
        confirm=True,
        how_to_fix=(
            "Windows: sets LSA / WDigest / Winlogon registry keys (LSA Protection needs a "
            "reboot to fully engage); revert restores prior values.\n"
            "Linux: backs up and edits /etc/login.defs (ENCRYPT_METHOD, UMASK); revert "
            "restores the backup."
        ),
    ),
    Tool(
        id="exec_logging", icon="📝",
        name="Command & Script Execution Logging",
        short="Turns on deep logging of scripts and process launches",
        desc=(
            "Gives you the evidence trail that catches fileless and 'living off the land' "
            "attacks: enables PowerShell script-block and module logging plus command-line "
            "process auditing on Windows, and installs an auditd execve rule on Linux. This "
            "is what makes an intrusion reconstructable after the fact. Fully reversible."
        ),
        nist=["AU-2", "AU-12", "SI-4"], cis="8.8", risk="medium", section="hardening",
        how_to_fix=(
            "Windows: sets PowerShell logging and Audit ProcessCreation registry policy; "
            "revert restores prior values.\n"
            "Linux: writes /etc/audit/rules.d/99-forcestack.rules and reloads auditd; revert "
            "removes the rule file and reloads."
        ),
    ),
    Tool(
        id="filesystem_hardening", icon="🗄",
        name="Filesystem & Removable Media Hardening",
        short="Blocks AutoRun and uncommon filesystems used to smuggle payloads",
        desc=(
            "Closes off common payload-delivery paths: disables AutoRun/AutoPlay and turns "
            "on SmartScreen on Windows, and blacklists rarely-needed kernel filesystem "
            "modules (cramfs, freevxfs, jffs2, hfs, hfsplus, udf) on Linux so a malicious "
            "USB image can't auto-mount an exotic filesystem. Reversible from the journal."
        ),
        nist=["CM-7", "MP-7", "SC-18"], cis="1.1", risk="medium", section="hardening",
        confirm=True,
        how_to_fix=(
            "Windows: sets Explorer AutoRun and SmartScreen policy registry keys; revert "
            "restores prior values.\n"
            "Linux: writes /etc/modprobe.d/99-forcestack-blacklist.conf; revert removes it."
        ),
    ),
]

# Fast lookup by id — O(1) vs O(n) linear scan (#6 equivalent for tools)
TOOL_MAP: dict[str, Tool] = {t.id: t for t in ALL_TOOLS}

# Grouped by section
SECTIONS = {
    "hardening":  "🛡  System Hardening",
    "passwords":  "🔑  Passwords and Accounts",
    "scanning":   "🔍  Threat Scanning",
    "network":    "🌐  Network Security",
    "compliance": "📊  Compliance and Patching",
}

def tools_by_section(section: str) -> List[Tool]:
    return [t for t in ALL_TOOLS if t.section == section]
