"""
core/utils.py — Shared utilities.
Issues fixed: #17 (logging moved to configure_logging() in main.py),
              #18 (OS_NAME re-exported from constants, not redefined),
              #19 (already_applied streams file, doesn't load all into memory)
"""

from __future__ import annotations
import subprocess
import logging
from pathlib import Path
from typing import Optional

# Fix #18: re-export from constants rather than redefining
from core.constants import OS_NAME  # noqa: F401 — re-exported for scripts._base

log = logging.getLogger("forcestack")

# ── Timeouts ──────────────────────────────────────────────────────────────────
TIMEOUT_SHORT  = 20   # registry edits, service changes
TIMEOUT_MEDIUM = 30   # network operations, system queries
TIMEOUT_LONG   = 60   # package enumeration, AV scans


def run_cmd(
    cmd,
    shell: bool = False,
    timeout: int = TIMEOUT_SHORT,
    input_text: Optional[str] = None,
) -> tuple[str, bool]:
    """
    Run a subprocess command. Returns (stdout+stderr, success).
    Never raises — all exceptions become error strings.
    """
    try:
        r = subprocess.run(
            cmd,
            shell=shell,
            capture_output=True,
            text=True,
            timeout=timeout,
            input=input_text,
        )
        return r.stdout + r.stderr, r.returncode == 0
    except subprocess.TimeoutExpired:
        return f"[TIMEOUT after {timeout}s]", False
    except FileNotFoundError as e:
        return f"[NOT FOUND] {e}", False
    except Exception as e:
        log.warning("run_cmd error: %s", e)
        return str(e), False


def reg_add(path: str, name: str, type_: str, value) -> tuple[str, bool]:
    """Windows registry write helper."""
    return run_cmd(["reg", "add", path, "/v", name, "/t", type_, "/d", str(value), "/f"])


def already_applied(marker_file: Path, marker_key: Optional[str] = None) -> bool:
    """
    Idempotency check.
    Fix #19: streams file line-by-line rather than loading all into memory.
    """
    if not marker_file.exists():
        return False
    if marker_key is None:
        return True
    # Stream line-by-line to avoid loading large config files fully into memory
    needle = marker_key.encode("utf-8", errors="ignore")
    try:
        with open(marker_file, "rb") as f:
            for line in f:
                if needle in line:
                    return True
    except OSError:
        pass
    return False


def clean_temp(path: Path) -> None:
    """Delete a temp file silently."""
    try:
        if path.exists():
            path.unlink()
    except Exception:
        pass


def sudo_prefix() -> list[str]:
    """
    Fix #30: return [] when already root, ["sudo"] otherwise.
    Fix #6: os.geteuid() does not exist on Windows — guard against AttributeError.
    """
    import os
    if OS_NAME == "Windows":
        return []
    return [] if os.geteuid() == 0 else ["sudo"]
