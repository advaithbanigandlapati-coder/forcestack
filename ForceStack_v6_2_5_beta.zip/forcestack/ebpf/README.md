# ForceStack — eBPF process monitor (kernel-level telemetry)

This is the optional, kernel-level telemetry backend for the Sentinel Probe. It
runs an eBPF program **in the kernel**, attached to the `sched_process_exec` and
`sched_process_exit` tracepoints, and streams events to userland via a ring
buffer — giving event-driven, gap-free process visibility that a userland
`psutil` vantage point cannot achieve.

## Why this and not a kernel module
An out-of-tree kernel module can panic the box and breaks across kernel
versions. eBPF programs are checked by the in-kernel verifier before they run
and use CO-RE (Compile Once, Run Everywhere) to stay portable. This is the
approach modern EDR (Falco, Tetragon) use.

## Build
```
sudo apt-get install clang llvm libbpf-dev bpftool linux-tools-$(uname -r)
cd ebpf && make
```
Requires a BTF-enabled kernel (`/sys/kernel/btf/vmlinux` present; standard on
recent distros).

## Run / wire into the probe
The collector prints one JSON event per line:
```
sudo ./proc_monitor            # needs root or CAP_BPF+CAP_PERFMON
{"type":"exec","pid":1234,"ppid":1000,"comm":"bash"}
```
Point the probe at it and the Sentinel Probe will use it automatically as its
top-priority telemetry source:
```
export FORCESTACK_EBPF_COLLECTOR=/path/to/ebpf/proc_monitor
```
The probe is fail-safe: if the collector is missing, unbuilt, or lacks
privilege, it silently falls back to the netlink proc connector and then to
polling, and it only reports "kernel events (ebpf)" once events actually arrive.

## What this does and does not do
- Does: event-driven, kernel-sourced process exec/exit telemetry with no polling
  gap; portable across kernels via CO-RE.
- Does not: inline-block a process in-kernel (this is a *sensor*; containment is
  still done from userland by suspending the PID), and does not use hardware
  telemetry such as Intel TDT (not reachable without vendor drivers).
