// proc_monitor.bpf.c — kernel-side eBPF program (CO-RE) for ForceStack.
//
// Attaches to the kernel's process-lifecycle tracepoints and streams exec/exit
// events to userland via a ring buffer. This runs IN THE KERNEL (verified by
// the in-kernel BPF verifier), so it sees every process as it happens — no
// polling, no sampling gap — which is the visibility a userland psutil vantage
// point cannot get. This is the same mechanism modern EDR (Falco, Tetragon) use.
//
// Build: see ebpf/Makefile (needs clang, libbpf, and kernel BTF).
#include "vmlinux.h"
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_core_read.h>
#include <bpf/bpf_tracing.h>

char LICENSE[] SEC("license") = "GPL";

#define ETYPE_EXEC 1
#define ETYPE_EXIT 3

struct event {
    __u32 pid;
    __u32 ppid;
    __u8  etype;
    char  comm[16];
};

// Ring buffer: kernel pushes, userland loader consumes.
struct {
    __uint(type, BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 1 << 20);   // 1 MiB
} rb SEC(".maps");

SEC("tp/sched/sched_process_exec")
int handle_exec(struct trace_event_raw_sched_process_exec *ctx)
{
    struct event *e = bpf_ringbuf_reserve(&rb, sizeof(*e), 0);
    if (!e)
        return 0;
    struct task_struct *task = (struct task_struct *)bpf_get_current_task();
    e->pid   = bpf_get_current_pid_tgid() >> 32;
    e->ppid  = BPF_CORE_READ(task, real_parent, tgid);
    e->etype = ETYPE_EXEC;
    bpf_get_current_comm(&e->comm, sizeof(e->comm));
    bpf_ringbuf_submit(e, 0);
    return 0;
}

SEC("tp/sched/sched_process_exit")
int handle_exit(struct trace_event_raw_sched_process_template *ctx)
{
    struct event *e = bpf_ringbuf_reserve(&rb, sizeof(*e), 0);
    if (!e)
        return 0;
    e->pid   = bpf_get_current_pid_tgid() >> 32;
    e->ppid  = 0;
    e->etype = ETYPE_EXIT;
    bpf_get_current_comm(&e->comm, sizeof(e->comm));
    bpf_ringbuf_submit(e, 0);
    return 0;
}
