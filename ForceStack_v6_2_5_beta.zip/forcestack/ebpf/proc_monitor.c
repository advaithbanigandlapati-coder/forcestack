// proc_monitor.c — userland loader for the ForceStack eBPF process monitor.
//
// Loads proc_monitor.bpf.o into the kernel, attaches its tracepoints, and
// prints one JSON event per line to stdout (line-buffered). The Python
// EBPFProcessSource runs this as a subprocess and reads those lines, so the
// kernel-side C and the userland sensor stay cleanly decoupled by language.
//
// Emits: {"type":"exec"|"exit","pid":N,"ppid":N,"comm":"name"}
//
// Requires: libbpf, root or CAP_BPF+CAP_PERFMON, and a BTF-enabled kernel.
#include <argp.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <bpf/libbpf.h>
#include <bpf/bpf.h>

struct event {
    unsigned int pid;
    unsigned int ppid;
    unsigned char etype;
    char comm[16];
};

static volatile sig_atomic_t exiting = 0;
static void sig_handler(int sig) { exiting = 1; }

static int handle_event(void *ctx, void *data, size_t size)
{
    if (size < sizeof(struct event))
        return 0;
    const struct event *e = data;
    const char *type = e->etype == 1 ? "exec" : (e->etype == 3 ? "exit" : "fork");
    // Minimal JSON; comm is a fixed 16-byte kernel field, safe to print.
    printf("{\"type\":\"%s\",\"pid\":%u,\"ppid\":%u,\"comm\":\"%.16s\"}\n",
           type, e->pid, e->ppid, e->comm);
    fflush(stdout);
    return 0;
}

int main(int argc, char **argv)
{
    struct bpf_object *obj;
    struct ring_buffer *rb = NULL;
    struct bpf_program *prog;
    int map_fd, err;

    libbpf_set_strict_mode(LIBBPF_STRICT_ALL);
    signal(SIGINT, sig_handler);
    signal(SIGTERM, sig_handler);

    const char *obj_path = (argc > 1) ? argv[1] : "proc_monitor.bpf.o";
    obj = bpf_object__open_file(obj_path, NULL);
    if (!obj || libbpf_get_error(obj)) {
        fprintf(stderr, "failed to open %s\n", obj_path);
        return 1;
    }
    err = bpf_object__load(obj);
    if (err) {
        fprintf(stderr, "failed to load BPF object: %d (need root/CAP_BPF, BTF)\n", err);
        return 1;
    }
    bpf_object__for_each_program(prog, obj) {
        if (!bpf_program__attach(prog)) {
            fprintf(stderr, "failed to attach %s\n", bpf_program__name(prog));
            return 1;
        }
    }
    map_fd = bpf_object__find_map_fd_by_name(obj, "rb");
    if (map_fd < 0) {
        fprintf(stderr, "ring buffer map not found\n");
        return 1;
    }
    rb = ring_buffer__new(map_fd, handle_event, NULL, NULL);
    if (!rb) {
        fprintf(stderr, "failed to create ring buffer\n");
        return 1;
    }
    fprintf(stderr, "proc_monitor: attached; streaming events\n");
    while (!exiting) {
        err = ring_buffer__poll(rb, 100 /* ms */);
        if (err == -4)   // EINTR
            continue;
        if (err < 0) {
            fprintf(stderr, "ring buffer poll error: %d\n", err);
            break;
        }
    }
    ring_buffer__free(rb);
    bpf_object__close(obj);
    return 0;
}
