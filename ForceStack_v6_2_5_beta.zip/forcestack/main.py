"""
ForceStack v3 — Entry point.
Issues fixed here: #6 (timeout sys.exit 1), #7 (quoted exe path),
                   #8 (--version), #9 (--list-tools), #10 (dynamic timeout)
"""

from __future__ import annotations
import sys
import os
import ctypes
import platform
import argparse


import subprocess
from core.constants import APP_VERSION  # fix #4: single source of truth


def is_admin() -> bool:
    try:
        if platform.system() == "Windows":
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        return os.geteuid() == 0
    except Exception:
        return False


def request_admin() -> None:
    """Re-launch with elevation on Windows. Fix #7: quoted exe path."""
    if platform.system() != "Windows":
        return
    try:
        exe   = sys.executable
        # subprocess.list2cmdline produces Windows-native double-quote escaping,
        # which is what Python's own arg parser (and ShellExecuteW) expects.
        # shlex.quote() produces POSIX single-quote syntax that breaks on Windows.
        args  = subprocess.list2cmdline(sys.argv[1:])
        ctypes.windll.shell32.ShellExecuteW(None, "runas", exe, args, None, 1)
        sys.exit(0)
    except Exception as e:
        print(f"[WARN] Could not elevate: {e}")


def configure_logging(headless: bool = False) -> None:
    """
    Must be called AFTER imports settle so LOG_FILE directory exists.
    Fix #17: moved from utils.py module-level.
    Fix #12: in headless/CI mode, also emit warnings/errors to stderr
             so CI systems (GitHub Actions, Jenkins) capture them without
             needing to tail ~/.forcestack/app.log.
    """
    import logging
    import sys
    from core.constants import LOG_FILE
    logging.basicConfig(
        filename=str(LOG_FILE),
        level=logging.WARNING,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    if headless:
        stderr_handler = logging.StreamHandler(sys.stderr)
        stderr_handler.setLevel(logging.WARNING)
        stderr_handler.setFormatter(
            logging.Formatter("[%(levelname)s] %(name)s: %(message)s")
        )
        logging.getLogger().addHandler(stderr_handler)


def parse_args():
    p = argparse.ArgumentParser(
        prog="forcestack",
        description="ForceStack — Enterprise Cybersecurity Hardening Toolkit",
    )
    p.add_argument("--version", action="version", version=f"%(prog)s {APP_VERSION}")  # fix #8
    p.add_argument("--dry-run", action="store_true",
                   help="Preview without making system changes")
    p.add_argument("--headless", action="store_true",
                   help="Run all scripts without UI (CI/CD)")
    p.add_argument("--tool", metavar="TOOL_ID",
                   help="Run a single tool by ID (headless)")
    p.add_argument("--list-tools", action="store_true",         # fix #9
                   help="Print all available tool IDs and exit")
    # Fix #11: machine-readable output for CI/SIEM integrations
    p.add_argument("--json-output", action="store_true",
                   help="Write headless results to stdout as JSON (tool_id, status, detail, duration, nist)")
    # Fix #13: configurable policy values so enterprises don't need to edit source
    p.add_argument("--timeout-secs", type=int, default=None, metavar="N",
                   help="Screen lock idle timeout in seconds (default: 600)")
    p.add_argument("--min-pw-len",   type=int, default=None, metavar="N",
                   help="Minimum password length (default: 15)")
    p.add_argument("--max-pw-age",   type=int, default=None, metavar="N",
                   help="Maximum password age in days (default: 365)")
    return p.parse_args()


def main() -> None:
    args = parse_args()

    # Fix #9: --list-tools before anything else
    if args.list_tools:
        from core.tools import ALL_TOOLS
        print(f"{'ID':<25} {'SECTION':<12} RISK")
        print("─" * 55)
        for t in ALL_TOOLS:
            print(f"{t.id:<25} {t.section:<12} {t.risk.upper()}")
        sys.exit(0)

    configure_logging(headless=args.headless)   # fix #17, fix #12

    if not is_admin():
        if platform.system() == "Windows" and not args.dry_run:
            print("[INFO] Requesting administrator elevation…")
            request_admin()
        else:
            print(
                "[WARN] Not running as Administrator/root.\n"
                "       Some scripts will fail without elevated privileges.\n"
                "       On Linux/macOS: sudo python3 main.py\n"
            )

    if args.headless:
        _headless(args)
        return

    from ui.app import ForceStackApp
    app = ForceStackApp()
    app.mainloop()


def _headless(args) -> None:
    """
    Fix #11: --json-output writes machine-readable results to stdout.
    Fix #13: CLI policy flags are applied via os.environ overrides read by scripts.
    """
    from core.tools import ALL_TOOLS, TOOL_MAP
    from core.runner import run_script, run_all
    from core.utils import TIMEOUT_LONG
    import threading
    import json as _json

    # Fix #13: propagate CLI policy overrides as environment variables so
    # scripts can pick them up without changing their function signatures.
    if args.timeout_secs is not None:
        os.environ["FORCESTACK_TIMEOUT_SECS"] = str(args.timeout_secs)
    if args.min_pw_len is not None:
        os.environ["FORCESTACK_MIN_PW_LEN"] = str(args.min_pw_len)
    if args.max_pw_age is not None:
        os.environ["FORCESTACK_MAX_PW_AGE"] = str(args.max_pw_age)

    json_results: list[dict] = []

    def emit(line: str, level: str = "info") -> None:
        if not args.json_output:
            prefix = {"ok": "✓", "err": "✗", "warn": "⚠", "info": "·"}.get(level, " ")
            print(f"  {prefix}  {line}")

    if args.tool:
        tool = TOOL_MAP.get(args.tool)
        if not tool:
            print(f"[ERROR] Unknown tool: {args.tool}", file=sys.stderr)
            print("Available:", ", ".join(t.id for t in ALL_TOOLS), file=sys.stderr)
            sys.exit(1)

        done_evt = threading.Event()
        result: list = [True, "", 0.0]

        def done(ok: bool, detail: str, dur: float) -> None:
            result[:] = [ok, detail, dur]
            if not args.json_output:
                print(f"\n[{'PASS' if ok else 'FAIL'}] {tool.name}  ({dur:.1f}s)")
            done_evt.set()

        run_script(args.tool, emit, done, dry_run=args.dry_run)
        if not done_evt.wait(timeout=TIMEOUT_LONG * 2):
            print("[ERROR] Tool timed out", file=sys.stderr)
            sys.exit(1)
        ok, detail, dur = result
        if args.json_output:
            print(_json.dumps([{
                "tool_id": args.tool, "tool_name": tool.name,
                "status": "success" if ok else "error",
                "detail": detail, "duration_s": round(dur, 2),
                "nist": tool.nist,
            }]))
        sys.exit(0 if ok else 1)

    else:
        done_evt = threading.Event()
        result = [True]

        def all_done(passed: int, failed: int) -> None:
            if not args.json_output:
                print(f"\n[COMPLETE] {passed} passed, {failed} failed")
            result[0] = failed == 0
            done_evt.set()

        def per_tool_done(tid: str, ok: bool, detail: str) -> None:
            if args.json_output:
                t = TOOL_MAP.get(tid)
                json_results.append({
                    "tool_id": tid,
                    "tool_name": t.name if t else tid,
                    "status": "success" if ok else "error",
                    "detail": detail,
                    "nist": t.nist if t else [],
                })

        tool_ids = [t.id for t in ALL_TOOLS]
        total_timeout = len(tool_ids) * TIMEOUT_LONG + 120
        run_all(tool_ids, emit, per_tool_done, all_done, dry_run=args.dry_run)
        if not done_evt.wait(timeout=total_timeout):
            print("[ERROR] Run All timed out", file=sys.stderr)
            sys.exit(1)
        if args.json_output:
            print(_json.dumps(json_results))
        sys.exit(0 if result[0] else 1)


if __name__ == "__main__":
    main()
