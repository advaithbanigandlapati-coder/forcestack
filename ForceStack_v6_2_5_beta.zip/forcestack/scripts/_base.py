"""
scripts/_base.py — Shared imports for every script module.
Issues fixed: #30 (sudo_prefix() for root-aware sudo), #33 (TOOL_ID validation),
              #54 (ErrorPayload TypedDict — enforces structured emit contract at definition site)
"""
from typing import TypedDict

from core.utils import (
    run_cmd, reg_add, already_applied, clean_temp,
    TIMEOUT_SHORT, TIMEOUT_MEDIUM, TIMEOUT_LONG,
    OS_NAME, sudo_prefix,
)
from core.constants import NIST_MAP
from core.tools import TOOL_MAP


class ErrorPayload(TypedDict):
    """
    Structured error payload for emit() calls on failure paths.

    Pass an ErrorPayload dict instead of a plain string when a failure needs
    user-facing guidance. The runner intercepts it, shows title + first fix line
    in the terminal immediately, and fires a toast notification with a link to
    the full detail page.

    All four keys are required. Wrong or missing keys produce an empty card in
    the UI with no error — use this TypedDict to catch that at definition time.

    Example:
        emit({
            "title": "Real-time protection is OFF",
            "why":   "Malware can execute undetected until a manual scan runs.",
            "fix":   "Open Windows Security → Virus & threat protection → Turn on Real-time protection",
            "raw":   out[:500],
        }, "err")
    """
    title: str   # Plain-English description of what is wrong — no jargon
    why:   str   # One sentence on the security consequence
    fix:   str   # Step-by-step resolution; newline-separated steps rendered as bullets
    raw:   str   # Diagnostic output shown in the detail page terminal


__all__ = [
    "run_cmd", "reg_add", "already_applied", "clean_temp",
    "TIMEOUT_SHORT", "TIMEOUT_MEDIUM", "TIMEOUT_LONG",
    "OS_NAME", "sudo_prefix", "NIST_MAP",
    "assert_tool_registered", "ErrorPayload",
]


def assert_tool_registered(tool_id: str) -> None:
    """
    Fix #33: assert at import time that TOOL_ID matches the canonical registry.
    Fix #8: validate against TOOL_MAP (ALL_TOOLS), not NIST_MAP — NIST_MAP and
    TOOL_MAP are maintained separately and could diverge. TOOL_MAP is the true
    source of truth for registered tools.
    """
    if tool_id not in TOOL_MAP:
        raise RuntimeError(
            f"Script declares TOOL_ID={tool_id!r} but it is not in TOOL_MAP (ALL_TOOLS). "
            "Update core/tools.py ALL_TOOLS to register it."
        )
