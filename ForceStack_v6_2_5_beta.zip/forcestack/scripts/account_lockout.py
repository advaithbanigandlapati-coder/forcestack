"""scripts/account_lockout.py — NIST AC-7.
Fix #34: macOS /tmp plist cleanup. Fix #35: Linux merge-write faillock.conf.
"""
TOOL_NAME = "Account Lockout Policy"
TOOL_ID   = "account_lockout"
from scripts._base import run_cmd, clean_temp, sudo_prefix, assert_tool_registered
import tempfile, os
from pathlib import Path
assert_tool_registered(TOOL_ID)

THRESHOLD = 5; DURATION = 30; WINDOW = 15
FORCESTACK_TAG = "# ForceStack NIST AC-7"


def execute(emit, os_name):
    emit(f"  Account lockout: {THRESHOLD} attempts, {DURATION}min lock (NIST AC-7)...\n", "info")
    ok = True

    if os_name == "Windows":
        _, ok = run_cmd(["net", "accounts",
                         f"/lockoutthreshold:{THRESHOLD}",
                         f"/lockoutduration:{DURATION}",
                         f"/lockoutwindow:{WINDOW}"])
        emit(f"  {'OK' if ok else 'ERR'}  Lockout policy applied", "ok" if ok else "err")
        inf = (f"[Unicode]\nUnicode=yes\n[System Access]\n"
               f"LockoutBadCount={THRESHOLD}\nResetLockoutCount={WINDOW}\n"
               f"LockoutDuration={DURATION}\n[Version]\nSignature=\"$CHICAGO$\"\nRevision=1\n")
        tmp = Path(tempfile.gettempdir()) / "forcestack_lock.inf"
        db  = Path(tempfile.gettempdir()) / "forcestack_lock.sdb"
        try:
            tmp.write_text(inf)
            run_cmd(["secedit", "/configure", "/db", str(db),
                     "/cfg", str(tmp), "/quiet"])
            emit("  OK  secedit lockout policy applied", "ok")
        finally:
            clean_temp(tmp); clean_temp(db)
        detail = f"Lockout: {THRESHOLD} attempts, {DURATION}min"

    elif os_name == "Darwin":
        plist = (f'<?xml version="1.0"?><plist version="1.0"><array><dict>'
                 f'<key>policyContent</key><string>policyAttributeFailedAuthentications &lt; '
                 f'policyAttributeMaximumFailedAuthentications</string>'
                 f'<key>policyIdentifier</key><string>max failed logins</string>'
                 f'<key>policyParameters</key><dict>'
                 f'<key>policyAttributeMaximumFailedAuthentications</key>'
                 f'<integer>{THRESHOLD}</integer></dict></dict></array></plist>')
        # Fix #34: use NamedTemporaryFile with delete=True via context manager
        tmp_fd, tmp_path = tempfile.mkstemp(suffix=".plist", prefix="forcestack_")
        try:
            os.write(tmp_fd, plist.encode())
            os.close(tmp_fd)
            _, ok = run_cmd(sudo_prefix() + ["pwpolicy", "-setaccountpolicies", tmp_path])  # fix #38
            emit(f"  {'OK' if ok else 'ERR'}  macOS lockout after {THRESHOLD} attempts",
                 "ok" if ok else "err")
        finally:
            clean_temp(Path(tmp_path))  # fix #34: always deleted
        detail = f"macOS lockout {THRESHOLD} attempts"

    else:
        conf = Path("/etc/security/faillock.conf")
        # Fix #35: merge-write — preserve existing keys, only update managed ones
        managed = {
            "deny":          str(THRESHOLD),
            "unlock_time":   str(DURATION * 60),
            "fail_interval": str(WINDOW * 60),
            "audit":         "",
            "even_deny_root":"",
        }
        try:
            from core.hardening import backup_file
            if conf.exists():
                backup_file(TOOL_ID, conf, "faillock.conf before lockout policy")
            existing_lines = conf.read_text().splitlines() if conf.exists() else []
            new_lines = [FORCESTACK_TAG]
            managed_written = set()
            for line in existing_lines:
                if line.strip().startswith("#") and FORCESTACK_TAG in line:
                    continue  # drop old ForceStack tag
                key = line.split("=")[0].strip().split(" ")[0].strip() if "=" in line or " " in line else line.strip()
                if key in managed:
                    val = managed[key]
                    new_lines.append(f"{key} = {val}" if val else key)
                    managed_written.add(key)
                else:
                    new_lines.append(line)
            # Append any managed keys not already in file
            for k, v in managed.items():
                if k not in managed_written:
                    new_lines.append(f"{k} = {v}" if v else k)
            conf.write_text("\n".join(new_lines) + "\n")
            emit("  OK  faillock.conf merged (site settings preserved)", "ok")
        except PermissionError:
            emit("  ERR  Permission denied — run as root", "err")
            ok = False
        detail = f"faillock: deny={THRESHOLD}, unlock={DURATION}min"

    emit("\n  NIST AC-7 complete.", "info")
    return ok, detail
