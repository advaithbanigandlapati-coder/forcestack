"""scripts/admin_audit.py — NIST AC-2, AC-6.
Fix #36: audit adm, disk, shadow, plugdev groups on Linux.
"""
TOOL_NAME = "Local Admin Auditor"
TOOL_ID   = "admin_audit"
from scripts._base import run_cmd, assert_tool_registered
assert_tool_registered(TOOL_ID)

# Fix #36: expanded group list for Debian/Ubuntu and common distros
LINUX_PRIV_GROUPS = ["sudo", "wheel", "adm", "disk", "shadow", "lpadmin", "plugdev"]


def execute(emit, os_name):
    emit("  Auditing privileged accounts (NIST AC-2, AC-6)...\n", "info")

    if os_name == "Windows":
        out, _ = run_cmd(["net", "localgroup", "administrators"])
        emit("  ── Administrators group ─────────────────", "info")
        emit(out, "info")
        # Fix #65 (v2): parse Account active line directly
        out3, _ = run_cmd(["net", "user", "Administrator"])
        for line in out3.splitlines():
            if line.lower().startswith("account active"):
                is_active = "yes" in line.lower()
                if is_active:
                    emit("  WARN  Built-in 'Administrator' account ENABLED — rename or disable", "warn")
                else:
                    emit("  OK  Built-in 'Administrator' account disabled or renamed", "ok")
                break
        detail = "Admin accounts listed; review required"

    elif os_name == "Darwin":
        out, _ = run_cmd(["dscl", ".", "read", "/Groups/admin", "GroupMembership"])
        emit(out, "info")
        detail = "macOS admin group listed"

    else:
        detail_parts = []
        # Fix #36: check all privileged groups, not just sudo/wheel
        for grp in LINUX_PRIV_GROUPS:
            out, _ = run_cmd(["getent", "group", grp])
            if out.strip():
                emit(f"  ── {grp} ──", "info")
                emit(f"  {out.strip()}", "info")
                members = out.strip().split(":")[-1]
                if members:
                    detail_parts.append(f"{grp}: {members[:40]}")
            else:
                emit(f"  --  {grp}: group not found on this system", "info")
        detail = "; ".join(detail_parts) or "No privileged members found"

    emit("\n  NIST AC-2 audit complete — review results manually.", "info")
    return True, detail
