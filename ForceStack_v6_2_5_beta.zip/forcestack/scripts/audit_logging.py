"""scripts/audit_logging.py — NIST AU-2, AU-3, AU-12.
Fix #37: Windows log retention uses auto-overwrite not disk-fill.
Fix #38: macOS audit_control merge-write.
"""
TOOL_NAME = "Enable Audit Logging"
TOOL_ID   = "audit_logging"
from scripts._base import run_cmd, sudo_prefix, assert_tool_registered
from pathlib import Path
assert_tool_registered(TOOL_ID)

FORCESTACK_TAG = "# ForceStack NIST AU-2"
SUBCATS = [
    "Credential Validation", "User Account Management", "Logon", "Logoff",
    "Account Lockout", "File System", "Audit Policy Change",
    "Sensitive Privilege Use", "Security System Extension", "System Integrity",
]


def execute(emit, os_name):
    emit("  Enabling audit logging (NIST AU-2, AU-12)...\n", "info")
    ok = True

    if os_name == "Windows":
        for sub in SUBCATS:
            run_cmd(["auditpol", "/set", f"/subcategory:{sub}",
                     "/success:enable", "/failure:enable"])
        emit(f"  OK  {len(SUBCATS)} audit subcategories enabled", "ok")
        run_cmd(["wevtutil", "sl", "Security", "/ms:1073741824"])
        emit("  OK  Security log size: 1 GB", "ok")
        # Fix #37: auto-overwrite (rt:true = retain-and-overwrite) not disk-fill (/rt:false)
        for log_name in ["Security", "System", "Application"]:
            run_cmd(["wevtutil", "sl", log_name, "/rt:true"])
        emit("  OK  Log retention: auto-overwrite oldest (prevents disk exhaustion)", "ok")
        run_cmd(["reg", "add",
                 r"HKLM\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging",
                 "/v", "EnableScriptBlockLogging", "/t", "REG_DWORD", "/d", "1", "/f"])
        run_cmd(["reg", "add",
                 r"HKLM\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ModuleLogging",
                 "/v", "EnableModuleLogging", "/t", "REG_DWORD", "/d", "1", "/f"])
        emit("  OK  PowerShell Script Block + Module logging enabled", "ok")
        run_cmd(["reg", "add",
                 r"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit",
                 "/v", "ProcessCreationIncludeCmdLine_Enabled",
                 "/t", "REG_DWORD", "/d", "1", "/f"])
        emit("  OK  Process creation command-line logging enabled", "ok")
        detail = f"{len(SUBCATS)} categories + PowerShell + process"

    elif os_name == "Darwin":
        pfx = sudo_prefix()  # fix #37: use sudo_prefix() not hardcoded "sudo"
        run_cmd(pfx + ["launchctl", "load", "-w",
                 "/System/Library/LaunchDaemons/com.apple.auditd.plist"])
        emit("  OK  auditd enabled", "ok")
        ac = Path("/etc/security/audit_control")
        # Fix #38: merge-write — only update managed keys
        managed = {
            "dir":       "/var/audit",
            "flags":     "lo,aa,ad,pc,nt,ex",
            "minfree":   "5",
            "naflags":   "lo,aa",
            "policy":    "cnt,argv,arge",
            "filesz":    "2M",
            "expire-after": "60d",
        }
        if ac.exists():
            lines = ac.read_text().splitlines()
            written = set()
            new_lines = [FORCESTACK_TAG] if FORCESTACK_TAG not in "\n".join(lines) else []
            for line in lines:
                if line.strip().startswith("#") and FORCESTACK_TAG in line:
                    continue
                key = line.split(":")[0].strip()
                if key in managed:
                    new_lines.append(f"{key}:{managed[key]}")
                    written.add(key)
                else:
                    new_lines.append(line)
            for k, v in managed.items():
                if k not in written:
                    new_lines.append(f"{k}:{v}")
        else:
            new_lines = [FORCESTACK_TAG] + [f"{k}:{v}" for k, v in managed.items()]
        try:
            ac.write_text("\n".join(new_lines) + "\n")
            run_cmd(pfx + ["audit", "-s"])
            emit("  OK  audit_control configured (site settings preserved)", "ok")
        except PermissionError:
            emit("  INFO  Cannot write audit_control — run as root", "info")
        detail = "macOS auditd + merged audit_control"

    else:
        pfx = sudo_prefix()
        rules = [
            "-a always,exit -F arch=b64 -S execve -k exec",
            "-w /etc/passwd -p wa -k passwd_changes",
            "-w /etc/shadow -p wa -k shadow_changes",
            "-w /etc/sudoers -p wa -k sudoers",
            "-a always,exit -F arch=b64 -S open -F exit=-EACCES -k access_denied",
        ]
        rp = Path("/etc/audit/rules.d/forcestack-nist.rules")
        try:
            rp.parent.mkdir(parents=True, exist_ok=True)
            rp.write_text(f"{FORCESTACK_TAG}\n" + "\n".join(rules) + "\n")
            run_cmd(pfx + ["augenrules", "--load"])
            run_cmd(pfx + ["systemctl", "enable", "--now", "auditd"])
            emit(f"  OK  {len(rules)} audit rules installed and loaded", "ok")
        except PermissionError:
            emit("  ERR  Permission denied — run as root", "err")
            ok = False
        detail = f"auditd: {len(rules)} rules"

    emit("\n  NIST AU-2 complete.", "info")
    return ok, detail
