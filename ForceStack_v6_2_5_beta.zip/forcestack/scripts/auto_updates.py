"""scripts/auto_updates.py — NIST SI-2, CM-3.
Fix #39: dnf branch reports pending count. Fix #40: macOS --no-scan.
Fix #36: use shutil.which() for package manager detection instead of run_cmd(["which"]).
Fix #52: structured PermissionError emit with context for unattended-upgrades config.
"""
TOOL_NAME = "Automatic Updates and Patching"
TOOL_ID   = "auto_updates"
import shutil
from scripts._base import run_cmd, sudo_prefix, assert_tool_registered, TIMEOUT_MEDIUM, TIMEOUT_LONG
assert_tool_registered(TOOL_ID)


def execute(emit, os_name):
    emit("  Enabling automatic security updates (NIST SI-2)...\n", "info")
    ok = True

    if os_name == "Windows":
        from core.hardening import apply_registry, record_undo
        wu = r"HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU"
        for k, t, v, lbl in [
            ("NoAutoUpdate",            "REG_DWORD", 0, "Automatic updates enabled"),
            ("AUOptions",               "REG_DWORD", 4, "Auto download + install"),
            ("AutoInstallMinorUpdates", "REG_DWORD", 1, "Install minor updates automatically"),
            ("ScheduledInstallDay",     "REG_DWORD", 0, "Install every day"),
            ("ScheduledInstallTime",    "REG_DWORD", 3, "Install at 3 AM"),
        ]:
            ok &= apply_registry(emit, TOOL_ID, wu, k, t, v, lbl)
        ps_ms = (
            "try { "
            "(New-Object -ComObject Microsoft.Update.ServiceManager).AddService2("
            "'7971f918-a847-4430-9279-4a52d1efe18d',7,'') | Out-Null; "
            "Write-Output 'MS_UPDATE_OK'"
            "} catch { Write-Output ('MS_UPDATE_FAIL: ' + $_.Exception.Message) }"
        )
        out, _ = run_cmd(["powershell", "-NonInteractive", "-Command", ps_ms],
                         timeout=TIMEOUT_MEDIUM)
        if "MS_UPDATE_OK" in out:
            emit("  OK  Microsoft Update (Office+) enabled", "ok")
            try:
                record_undo(TOOL_ID, ["powershell", "-NonInteractive", "-Command",
                    "(New-Object -ComObject Microsoft.Update.ServiceManager)."
                    "RemoveService('7971f918-a847-4430-9279-4a52d1efe18d')"],
                    "Remove Microsoft Update service registration")
            except Exception:
                pass
        elif "MS_UPDATE_FAIL" in out:
            msg = out.split("MS_UPDATE_FAIL:", 1)[-1].strip()[:80]
            emit(f"  WARN  Microsoft Update COM unavailable: {msg}", "warn")
            emit("  INFO  Enable manually: Settings > Windows Update > Advanced options", "info")
        out2, _ = run_cmd(["powershell", "-Command",
                           "Get-HotFix | Sort-Object InstalledOn -Descending | "
                           "Select-Object -First 5 HotFixID,InstalledOn | Format-Table -AutoSize"],
                          timeout=TIMEOUT_MEDIUM)
        emit("\n  Last 5 hotfixes:\n" + (out2 or "  (none)"), "info")
        detail = "Windows auto-update enabled + daily schedule"

    elif os_name == "Darwin":
        pfx = sudo_prefix()
        settings = [
            ("AutomaticCheckEnabled",         "true"),
            ("AutomaticDownload",             "true"),
            ("AutomaticallyInstallMacOSUpdates","true"),
            ("CriticalUpdateInstall",         "true"),
            ("ConfigDataInstall",             "true"),
        ]
        for k, v in settings:
            run_cmd(pfx + ["defaults", "write",
                     "/Library/Preferences/com.apple.SoftwareUpdate", k, f"-bool {v}"])
        run_cmd(pfx + ["softwareupdate", "--schedule", "on"])
        emit(f"  OK  {len(settings)} auto-update preferences set", "ok")
        # Fix #40: --no-scan avoids triggering a network scan on every run
        out, _ = run_cmd(["softwareupdate", "-l", "--no-scan"], timeout=TIMEOUT_MEDIUM)
        emit(out or "  (no cached update list — run without --no-scan to check)", "info")
        detail = "macOS auto-update enabled"

    else:
        pfx = sudo_prefix()
        from pathlib import Path

        has_apt = shutil.which("apt") is not None   # fix #36
        has_dnf = shutil.which("dnf") is not None   # fix #36

        if has_apt:
            run_cmd(pfx + ["apt-get", "install", "-y", "unattended-upgrades"],
                    timeout=TIMEOUT_LONG)
            conf = Path("/etc/apt/apt.conf.d/20auto-upgrades")
            try:
                from core.hardening import backup_file, record_undo
                backup_file(TOOL_ID, conf, "20auto-upgrades before auto-update")
                conf.write_text(
                    'APT::Periodic::Update-Package-Lists "1";\n'
                    'APT::Periodic::Download-Upgradeable-Packages "1";\n'
                    'APT::Periodic::AutocleanInterval "7";\n'
                    'APT::Periodic::Unattended-Upgrade "1";\n'
                )
                run_cmd(pfx + ["systemctl", "enable", "--now", "unattended-upgrades"])
                record_undo(TOOL_ID, pfx + ["systemctl", "disable", "--now", "unattended-upgrades"],
                            "Disable unattended-upgrades")
                emit("  OK  unattended-upgrades: daily security patches enabled", "ok")
            except PermissionError:
                emit({
                    "title": "Cannot enable automatic security updates",
                    "why": (
                        "The file /etc/apt/apt.conf.d/20auto-upgrades tells the system to "
                        "automatically download and install security patches. Without it, "
                        "critical vulnerabilities will not be patched until someone manually "
                        "runs updates — which may never happen."
                    ),
                    "fix": (
                        "Run ForceStack with elevated privileges: sudo python3 main.py\n"
                        "Or manually create the file:\n"
                        "  sudo nano /etc/apt/apt.conf.d/20auto-upgrades\n"
                        'Add: APT::Periodic::Unattended-Upgrade "1";'
                    ),
                    "raw": f"PermissionError writing {conf}",
                }, "err")
                ok = False
            out2, _ = run_cmd(["apt", "list", "--upgradable"], timeout=TIMEOUT_MEDIUM)
            count = len([l for l in out2.splitlines() if "/" in l])
            emit(f"  Upgradable packages: {count}", "warn" if count > 0 else "ok")
            detail = f"unattended-upgrades enabled; {count} pending"

        elif has_dnf:
            run_cmd(pfx + ["dnf", "install", "-y", "dnf-automatic"], timeout=TIMEOUT_LONG)
            run_cmd(pfx + ["systemctl", "enable", "--now", "dnf-automatic.timer"])
            try:
                from core.hardening import record_undo
                record_undo(TOOL_ID, pfx + ["systemctl", "disable", "--now", "dnf-automatic.timer"],
                            "Disable dnf-automatic timer")
            except Exception:
                pass
            emit("  OK  dnf-automatic enabled (security updates)", "ok")
            # Fix #39: report pending count for dnf branch too
            out3, _ = run_cmd(["dnf", "check-update", "--security"], timeout=TIMEOUT_MEDIUM)
            lines3 = [l for l in out3.splitlines() if l and not l.startswith("Last") and not l.startswith("Red Hat") and "/" in l]
            emit(f"  Pending security updates: {len(lines3)}", "warn" if lines3 else "ok")
            detail = f"dnf-automatic enabled; {len(lines3)} security updates pending"

        else:
            emit("  INFO  No recognized package manager — run updates manually", "info")
            detail = "No recognized package manager for automation"

    emit("\n  NIST SI-2 complete.", "info")
    return ok, detail
