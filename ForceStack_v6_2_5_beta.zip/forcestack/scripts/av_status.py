"""scripts/av_status.py — NIST SI-3, SI-8, RA-5.
Fix #57: Get-CimInstance not deprecated WMI. Fix #34: assert_tool_registered added.
Fix #51: structured error emits with plain-English fix paths for all failure cases.
"""
TOOL_NAME = "Antivirus and EDR Status"
TOOL_ID   = "av_status"
from scripts._base import run_cmd, TIMEOUT_MEDIUM, assert_tool_registered
assert_tool_registered(TOOL_ID)


def execute(emit, os_name):
    emit("  Checking AV/EDR status (NIST SI-3)...\n", "info")
    ok = True

    if os_name == "Windows":
        ps = (
            "Get-MpComputerStatus | Select-Object AMRunningMode,AMServiceEnabled,"
            "AntivirusEnabled,RealTimeProtectionEnabled,AntivirusSignatureLastUpdated,"
            "AntivirusSignatureAge,QuickScanAge"
        )
        out, _ = run_cmd(["powershell", "-NonInteractive", "-Command", ps],
                         timeout=TIMEOUT_MEDIUM)
        emit(out or "  Could not query Windows Defender", "info")
        if "True" in out and "RealTimeProtectionEnabled" in out:
            emit("  OK  Real-time protection ON", "ok")
        else:
            emit({
                "title": "Real-time protection is OFF",
                "why": (
                    "Windows Defender is not actively scanning files as they are opened, "
                    "downloaded, or run. Malware can execute undetected until a manual scan "
                    "is performed — which may already be too late."
                ),
                "fix": (
                    "Open Windows Security → Virus & threat protection → "
                    "Virus & threat protection settings → "
                    "Turn on Real-time protection"
                ),
                "raw": out[:500] if out else "No output from Get-MpComputerStatus",
            }, "err")
            ok = False

        ps2 = (
            "Get-CimInstance -Namespace 'root/SecurityCenter2' -ClassName AntiVirusProduct "
            "| Select-Object displayName,productState,pathToSignedProductExe"
        )
        out2, _ = run_cmd(["powershell", "-NonInteractive", "-Command", ps2],
                          timeout=TIMEOUT_MEDIUM)
        emit("\n  Third-party AV (CimInstance):", "info")
        emit(out2 or "  (none found)", "info")

        ps3 = "Get-MpPreference | Select-Object DisableTamperProtection"
        out3, _ = run_cmd(["powershell", "-NonInteractive", "-Command", ps3],
                          timeout=TIMEOUT_MEDIUM)
        if "False" in out3:
            emit("  OK  Tamper protection ON", "ok")
        else:
            emit({
                "title": "Tamper protection is OFF",
                "why": (
                    "Tamper protection prevents malware from disabling Windows Defender. "
                    "Without it, ransomware can silently turn off your antivirus before "
                    "infecting your system."
                ),
                "fix": (
                    "Open Windows Security → Virus & threat protection → "
                    "Virus & threat protection settings → "
                    "Turn on Tamper protection"
                ),
                "raw": out3[:200] if out3 else "No output from Get-MpPreference",
            }, "warn")
        detail = "Windows Defender + CimInstance AV check"

    elif os_name == "Darwin":
        out, _ = run_cmd(["spctl", "--status"])
        if "enabled" in out:
            emit(f"  OK  Gatekeeper: {out.strip()}", "ok")
        else:
            emit({
                "title": "Gatekeeper is disabled",
                "why": (
                    "Gatekeeper verifies that apps are from the App Store or an identified "
                    "developer before they run. Without it, any downloaded file can execute "
                    "on your Mac regardless of whether it is safe or signed."
                ),
                "fix": (
                    "Open System Settings → Privacy & Security → "
                    "scroll to the Security section → "
                    "select 'App Store and identified developers' or 'App Store'"
                ),
                "raw": out.strip() or "spctl --status returned no output",
            }, "warn")
        out2, _ = run_cmd(["ls", "/Library/Apple/System/Library/CoreServices/MRT.app"])
        if "MRT.app" in out2:
            emit("  OK  MRT present", "ok")
        out3, _ = run_cmd([
            "defaults", "read",
            "/Library/Apple/System/Library/CoreServices/XProtect.bundle"
            "/Contents/Resources/XProtect.meta.plist", "Version",
        ])
        emit(f"  XProtect version: {out3.strip() or 'unknown'}", "info")
        detail = f"macOS Gatekeeper {'enabled' if 'enabled' in out else 'DISABLED'}"

    else:
        tools = {
            "clamscan": "ClamAV", "sophos-av": "Sophos", "esets_daemon": "ESET",
            "rkhunter": "RKHunter", "aide": "AIDE", "lynis": "Lynis",
        }
        found = []
        for binary, name in tools.items():
            out, _ = run_cmd(["which", binary])
            if out.strip():
                emit(f"  OK  {name} detected", "ok")
                found.append(name)
        if not found:
            emit({
                "title": "No antivirus or endpoint protection detected",
                "why": (
                    "Without AV/EDR software, malware, ransomware, and rootkits can run "
                    "on this Linux system completely undetected. Linux is increasingly "
                    "targeted, especially in enterprise and server environments."
                ),
                "fix": (
                    "Install ClamAV (free): sudo apt install clamav clamav-daemon && sudo freshclam\n"
                    "For enterprise: consider CrowdStrike Falcon, Sophos, or ESET for Linux\n"
                    "For servers: sudo apt install rkhunter chkrootkit provides rootkit detection"
                ),
                "raw": "Checked for: " + ", ".join(tools.keys()),
            }, "err")
            ok = False
        detail = f"Linux AV: {', '.join(found) or 'NONE'}"

    emit("\n  NIST SI-3 check complete.", "info")
    return ok, detail
