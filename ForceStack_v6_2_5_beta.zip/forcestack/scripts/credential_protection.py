"""scripts/credential_protection.py — Credential theft protection. NIST IA-5, AC-3, AC-6.
Windows: LSA Protection, WDigest off, NTLMv2-only, fewer cached logons. Linux: login.defs
hardening. All reversible."""
TOOL_NAME = "Credential Theft Protection"
TOOL_ID   = "credential_protection"
from scripts._base import assert_tool_registered
from pathlib import Path
assert_tool_registered(TOOL_ID)


def execute(emit, os_name):
    from core.hardening import apply_registry, backup_file
    emit("  Protecting credentials from theft (NIST IA-5, AC-6)...\n", "info")
    ok = True

    if os_name == "Windows":
        lsa = r"HKLM\SYSTEM\CurrentControlSet\Control\Lsa"
        wdig = r"HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest"
        win = r"HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"
        ok &= apply_registry(emit, TOOL_ID, lsa, "RunAsPPL", "REG_DWORD", 1,
                             "LSA Protection — blocks LSASS credential scraping (reboot to engage)")
        ok &= apply_registry(emit, TOOL_ID, lsa, "LmCompatibilityLevel", "REG_DWORD", 5,
                             "Send NTLMv2 only, refuse LM/NTLM")
        ok &= apply_registry(emit, TOOL_ID, wdig, "UseLogonCredential", "REG_DWORD", 0,
                             "Disable WDigest cleartext credential caching")
        ok &= apply_registry(emit, TOOL_ID, win, "CachedLogonsCount", "REG_SZ", "4",
                             "Limit cached domain logons")
        detail = "Windows credential protections (verified, reversible)"

    elif os_name == "Darwin":
        emit("  INFO  macOS stores credentials in Keychain; no changes made by this tool.", "info")
        return True, "not applicable on macOS"

    else:
        conf = Path("/etc/login.defs")
        managed = {"ENCRYPT_METHOD": "SHA512", "UMASK": "077",
                   "PASS_MAX_DAYS": "365", "SHA_CRYPT_MIN_ROUNDS": "100000"}
        try:
            if conf.exists():
                backup_file(TOOL_ID, conf, "login.defs before credential hardening")
                lines = conf.read_text().splitlines()
            else:
                backup_file(TOOL_ID, conf, "login.defs (created)")
                lines = []
            written, out = set(), []
            for ln in lines:
                key = ln.split()[0] if ln.split() else ""
                if key in managed:
                    out.append(f"{key}\t{managed[key]}")
                    written.add(key)
                else:
                    out.append(ln)
            for k, v in managed.items():
                if k not in written:
                    out.append(f"{k}\t{v}")
            conf.write_text("\n".join(out) + "\n")
            emit("  OK  login.defs hardened (SHA512 hashing, umask 077) — site keys preserved", "ok")
            detail = "Linux login.defs hardened (reversible)"
        except (PermissionError, OSError) as _e:
            emit(f"  ERR  Could not apply (run as root?): {_e}", "err")
            return False, f"apply failed: {_e}"

    emit("\n  Credential protection complete.", "info")
    return ok, detail
