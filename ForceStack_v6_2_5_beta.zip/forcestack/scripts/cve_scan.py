"""scripts/cve_scan.py — NIST RA-5, SI-2.
Fix #41: safety v3+ uses 'safety scan' not 'safety check'. Fix #42: check all available PMs.
"""
TOOL_NAME = "CVE Vulnerability Scanner"
TOOL_ID   = "cve_scan"
import shutil
from scripts._base import run_cmd, assert_tool_registered, TIMEOUT_LONG, TIMEOUT_MEDIUM
assert_tool_registered(TOOL_ID)


def execute(emit, os_name):
    emit("  CVE vulnerability scan (NIST RA-5, SI-2)...\n", "info")
    ok = True
    issues = []

    if os_name == "Windows":
        emit("  Enumerating installed software...\n", "info")
        ps = ("Get-Package | Select-Object Name,Version | Sort-Object Name | "
              "Format-Table -AutoSize | Out-String -Width 120")
        out, ok1 = run_cmd(["powershell", "-NonInteractive", "-Command", ps],
                           timeout=TIMEOUT_LONG)
        if not ok1 or not out.strip():
            out2, ok2 = run_cmd(["winget", "list", "--disable-interactivity"],
                                timeout=TIMEOUT_LONG)
            if ok2:
                emit(out2[:3000], "info")
            else:
                emit("  Install winget for package enumeration", "info")
        else:
            lines = [l for l in out.splitlines() if l.strip() and not l.startswith("-")]
            emit(f"  Found {len(lines)} packages via Get-Package\n", "info")
            emit(out[:3000], "info")
        out3, _ = run_cmd(["powershell", "-Command",
                           "Get-HotFix | Sort-Object InstalledOn -Descending | "
                           "Select-Object -First 10 | Format-Table HotFixID,InstalledOn -AutoSize"],
                          timeout=TIMEOUT_MEDIUM)
        emit("\n  Recent hotfixes:\n" + (out3 or "  (none found)"), "info")
        emit("  NVD: https://nvd.nist.gov/vuln/search", "info")
        detail = "Get-Package enumeration complete"

    elif os_name == "Darwin":
        out, _ = run_cmd(["softwareupdate", "-l"], timeout=TIMEOUT_MEDIUM)
        emit(out or "  (no updates found)", "info")
        if "No new software" in out or not out.strip():
            emit("  OK  macOS up to date", "ok")
        else:
            emit("  WARN  Pending updates found", "warn")
            issues.append("Pending macOS updates")
            ok = False
        out2, _ = run_cmd(["brew", "outdated"], timeout=TIMEOUT_MEDIUM)
        if out2.strip():
            emit(f"  WARN  Outdated Homebrew packages:\n{out2}", "warn")
            issues.append("Outdated Homebrew")
        else:
            emit("  OK  Homebrew up to date (or not installed)", "ok")
        detail = f"macOS: {'updates needed' if issues else 'up to date'}"

    else:
        # Fix #42: check ALL available package managers, not just first found
        pm_found = False
        for pm, cmd in [
            ("apt",    ["apt", "list", "--upgradable"]),
            ("dnf",    ["dnf", "check-update"]),
            ("yum",    ["yum", "check-update"]),
            ("pacman", ["pacman", "-Qu"]),
            ("zypper", ["zypper", "list-updates"]),
        ]:
            if not shutil.which(pm):  # fix #15: shutil.which is stdlib, reliable, no subprocess
                continue
            pm_found = True
            emit(f"\n  [{pm.upper()}]", "info")
            out2, _ = run_cmd(cmd, timeout=TIMEOUT_MEDIUM)
            emit(out2[:2000] or f"  ({pm} output empty)", "info")
            pending = [l for l in out2.splitlines() if l.strip() and "/" in l]
            if len(pending) > 1:
                emit(f"  WARN  {len(pending)} upgradable packages", "warn")
                issues.append(f"{pm}: {len(pending)} pending")
                ok = False
            else:
                emit(f"  OK  {pm}: no pending security updates", "ok")

        if not pm_found:
            emit("  INFO  No recognized package manager found", "info")

        # Fix #41: safety v3+ renamed 'check' to 'scan'
        if shutil.which("safety"):  # fix #15
            emit("\n  safety scan on Python packages:", "info")
            # Try v3 first ('scan'), fall back to v2 ('check')
            out4, ok4 = run_cmd(["safety", "scan", "--output", "text"],
                                timeout=TIMEOUT_MEDIUM)
            if not ok4 or "No such command" in out4 or "Error" in out4[:50]:
                out4, _ = run_cmd(["safety", "check", "--output", "text"],
                                  timeout=TIMEOUT_MEDIUM)
            emit(out4[:1500] or "  (no issues)", "info")

        detail = f"Linux: {len(issues)} issue groups"

    emit("\n  NIST RA-5 scan complete.", "info")
    return ok, detail
