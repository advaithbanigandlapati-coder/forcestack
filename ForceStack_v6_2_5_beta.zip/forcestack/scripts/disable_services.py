"""scripts/disable_services.py — NIST CM-7, AC-17, SI-3.
Fix #43: SMBv1 actually disabled via Set-SmbServerConfiguration.
"""
TOOL_NAME = "Disable Risky Services"
TOOL_ID   = "disable_services"
from scripts._base import run_cmd, sudo_prefix, assert_tool_registered
assert_tool_registered(TOOL_ID)

WIN_SERVICES = [
    ("Telnet",         "Telnet — unencrypted remote shell"),
    ("FtpSvc",         "FTP Server — cleartext credentials"),
    ("SSDPSRV",        "SSDP Discovery — DDoS amplification"),
    ("upnphost",       "UPnP — automatic port-forwarding exploits"),
    ("RemoteRegistry", "Remote Registry — off-machine registry edits"),
    ("Fax",            "Fax Service — legacy"),
]
LINUX_SERVICES = ["telnetd", "vsftpd", "rsh-server", "rlogin", "xinetd", "finger"]
MACOS_SERVICES = ["com.apple.telnetd", "com.apple.ftp-proxy"]


def execute(emit, os_name):
    emit("  Disabling risky services (NIST CM-7)...\n", "info")
    disabled = []
    ok = True

    if os_name == "Windows":
        # Fix #43: SMBv1 via PowerShell (sc config does not control it)
        smb_out, smb_ok = run_cmd([
            "powershell", "-NonInteractive", "-Command",
            "Set-SmbServerConfiguration -EnableSMB1Protocol $false -Force; "
            "Set-SmbClientConfiguration -EnableSMB1Protocol $false -Force; "
            "Write-Output 'SMB1_DONE'"
        ])
        if "SMB1_DONE" in smb_out:
            emit("  OK  SMBv1 disabled (EternalBlue/WannaCry protection)", "ok")
            disabled.append("SMBv1")
            try:
                from core.hardening import record_undo
                record_undo(TOOL_ID, ["powershell", "-NonInteractive", "-Command",
                            "Set-SmbServerConfiguration -EnableSMB1Protocol $true -Force"],
                            "Re-enable SMBv1 (server)")
            except Exception:
                pass
        else:
            emit("  WARN  SMBv1 disable returned: " + smb_out[:80], "warn")
            ok = False

        for svc, reason in WIN_SERVICES:
            out, _ = run_cmd(["sc", "query", svc])
            if "FAILED 1060" in out or "does not exist" in out:
                emit(f"  --  {svc:<24} not installed", "info")
                continue
            cfg, _ = run_cmd(["sc", "qc", svc])
            if "DISABLED" in cfg:
                emit(f"  OK  {svc:<24} already disabled", "ok")
                disabled.append(svc)
                continue
            orig = "auto" if "AUTO_START" in cfg else "demand"
            _, cok = run_cmd(["sc", "config", svc, "start=", "disabled"])
            run_cmd(["sc", "stop", svc])
            ok = ok and cok
            emit(f"  {'OK' if cok else 'ERR'}  {svc:<24} {'disabled — ' + reason if cok else 'FAILED'}",
                 "ok" if cok else "err")
            disabled.append(svc)
            try:
                from core.hardening import record_undo
                record_undo(TOOL_ID, ["sc", "config", svc, "start=", orig],
                            f"Restore service {svc} (start={orig})")
            except Exception:
                pass
        detail = f"Disabled {len(disabled)} services (incl. SMBv1)"

    elif os_name == "Darwin":
        pfx = sudo_prefix()  # fix #41: use sudo_prefix() not hardcoded "sudo"
        for svc in MACOS_SERVICES:
            run_cmd(pfx + ["launchctl", "disable", f"system/{svc}"])
            run_cmd(pfx + ["launchctl", "bootout",  f"system/{svc}"])
            emit(f"  OK  {svc}", "ok")
            try:
                from core.hardening import record_undo
                record_undo(TOOL_ID, pfx + ["launchctl", "enable", f"system/{svc}"],
                            f"Re-enable {svc}")
            except Exception:
                pass
        detail = f"Disabled {len(MACOS_SERVICES)} macOS services"

    else:
        pfx = sudo_prefix()  # fix #30: no sudo when already root
        for svc in LINUX_SERVICES:
            out, _ = run_cmd(["systemctl", "is-enabled", svc])
            if "not-found" in out:
                emit(f"  --  {svc} not installed", "info")
                continue
            if "disabled" in out:
                emit(f"  OK  {svc} already disabled", "ok")
                disabled.append(svc)
                continue
            _, sok = run_cmd(pfx + ["systemctl", "disable", "--now", svc])
            ok = ok and sok
            emit(f"  {'OK' if sok else 'ERR'}  {svc} {'disabled' if sok else 'FAILED to disable'}",
                 "ok" if sok else "err")
            disabled.append(svc)
            try:
                from core.hardening import record_undo
                record_undo(TOOL_ID, pfx + ["systemctl", "enable", "--now", svc],
                            f"Re-enable service {svc}")
            except Exception:
                pass
        detail = f"Disabled {len(disabled)} Linux services"

    emit("\n  NIST CM-7 complete.", "info")
    return ok, detail
