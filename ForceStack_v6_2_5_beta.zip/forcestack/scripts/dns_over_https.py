"""scripts/dns_over_https.py — NIST SC-20, SC-21.
Fix #44: Linux merge-write resolved.conf. Fix #45: macOS filter connected-only.
"""
TOOL_NAME = "DNS-over-HTTPS Configuration"
TOOL_ID   = "dns_over_https"
from scripts._base import run_cmd, sudo_prefix, assert_tool_registered
from pathlib import Path
assert_tool_registered(TOOL_ID)

FORCESTACK_TAG = "# ForceStack NIST SC-20"
DOH_SERVERS = {
    "DNS":         "1.1.1.1#cloudflare-dns.com 1.0.0.1#cloudflare-dns.com "
                   "8.8.8.8#dns.google 8.8.4.4#dns.google",
    "FallbackDNS": "9.9.9.9#dns.quad9.net",
    "DNSOverTLS":  "yes",
    "DNSSEC":      "yes",
    "DNSStubListener": "yes",
}


def execute(emit, os_name):
    emit("  Configuring DNS-over-HTTPS (NIST SC-20, SC-21)...\n", "info")
    ok = True

    if os_name == "Windows":
        ps = ("Get-NetAdapter -Physical | Where-Object {$_.Status -eq 'Up'} | "
              "Select-Object -ExpandProperty Name")
        out, _ = run_cmd(["powershell", "-NonInteractive", "-Command", ps])
        ifaces = [l.strip() for l in out.splitlines() if l.strip()]
        if not ifaces:
            emit("  WARN  No active network adapters found via Get-NetAdapter", "warn")
        for iface in ifaces:
            run_cmd(["powershell", "-Command",
                     f"Set-DnsClientServerAddress -InterfaceAlias '{iface}' "
                     "-ServerAddresses ('1.1.1.1','1.0.0.1','8.8.8.8','8.8.4.4')"])
            emit(f"  OK  DNS set on: {iface}", "ok")
        run_cmd(["reg", "add",
                 r"HKLM\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters",
                 "/v", "EnableAutoDoh", "/t", "REG_DWORD", "/d", "2", "/f"])
        emit("  OK  Auto DoH enabled (EnableAutoDoh=2)", "ok")
        detail = f"DoH DNS configured on {len(ifaces)} adapter(s)"

    elif os_name == "Darwin":
        # Fix #45: filter to connected services only
        all_out, _ = run_cmd(["networksetup", "-listallnetworkservices"])
        connected = []
        for svc_name in all_out.splitlines()[1:]:
            svc_name = svc_name.strip().lstrip("*")
            if not svc_name:
                continue
            status_out, _ = run_cmd(["networksetup", "-getnetworkserviceenabled", svc_name])
            if "enabled" in status_out.lower():
                ip_out, _ = run_cmd(["networksetup", "-getinfo", svc_name])
                if "IP address:" in ip_out and "none" not in ip_out.lower():
                    connected.append(svc_name)

        if not connected:
            emit("  INFO  No active network services detected — setting all enabled services", "info")
            connected = [l.strip() for l in all_out.splitlines()[1:] if l.strip() and not l.startswith("*")]

        for svc in connected:
            run_cmd(["networksetup", "-setdnsservers", svc, "1.1.1.1", "1.0.0.1"])
            emit(f"  OK  Cloudflare DNS on: {svc}", "ok")
        emit("  INFO  For full DoH: brew install cloudflare/cloudflare/cloudflared", "info")
        detail = f"Cloudflare DNS on {len(connected)} connected service(s)"

    else:
        conf = Path("/etc/systemd/resolved.conf")
        # Fix #44: merge-write — update [Resolve] keys, preserve other sections
        if conf.exists():
            lines = conf.read_text().splitlines()
            tag_present = any(FORCESTACK_TAG in l for l in lines)
            if tag_present:
                managed_written = set()
                new_lines = []
                in_resolve = False
                for line in lines:
                    if line.strip() == "[Resolve]":
                        in_resolve = True
                        new_lines.append(line)
                        continue
                    elif line.strip().startswith("[") and in_resolve:
                        # Append any un-updated managed keys before leaving section
                        for k, v in DOH_SERVERS.items():
                            if k not in managed_written:
                                new_lines.append(f"{k}={v}")
                                managed_written.add(k)
                        in_resolve = False
                    if in_resolve:
                        # Strip leading # and whitespace to catch commented-out keys
                        key = line.split("=")[0].strip().lstrip("#").strip()
                        if key in DOH_SERVERS:
                            new_lines.append(f"{key}={DOH_SERVERS[key]}")
                            managed_written.add(key)
                            continue
                    new_lines.append(line)
                # Append any managed keys not yet written ([Resolve] was last section)
                for k, v in DOH_SERVERS.items():
                    if k not in managed_written:
                        new_lines.append(f"{k}={v}")
                try:
                    conf.write_text("\n".join(new_lines) + "\n")
                    pfx = sudo_prefix()
                    run_cmd(pfx + ["systemctl", "restart", "systemd-resolved"])
                    emit("  OK  systemd-resolved: DoH settings refreshed (idempotent)", "ok")
                except PermissionError:
                    emit("  ERR  Permission denied — run as root", "err")
                    ok = False
                detail = "DoH settings refreshed"
            else:
                # First application: add [Resolve] section with DoH settings
                new_lines = lines + ["", FORCESTACK_TAG, "[Resolve]"] + [f"{k}={v}" for k, v in DOH_SERVERS.items()]
                try:
                    conf.write_text("\n".join(new_lines) + "\n")
                    pfx = sudo_prefix()
                    run_cmd(pfx + ["systemctl", "restart", "systemd-resolved"])
                    run_cmd(pfx + ["ln", "-sf",
                                   "/run/systemd/resolve/stub-resolv.conf",
                                   "/etc/resolv.conf"])
                    emit("  OK  systemd-resolved: DoH + DNSSEC enabled (site settings preserved)", "ok")
                    detail = "Linux DoH: systemd-resolved + DNSSEC"
                except PermissionError:
                    emit("  ERR  Permission denied — run as root", "err")
                    ok = False
                    detail = "Permission denied"
        else:
            # No resolved.conf — create fresh
            content = f"{FORCESTACK_TAG}\n[Resolve]\n" + "\n".join(f"{k}={v}" for k, v in DOH_SERVERS.items()) + "\n"
            try:
                conf.parent.mkdir(parents=True, exist_ok=True)
                conf.write_text(content)
                pfx = sudo_prefix()
                run_cmd(pfx + ["systemctl", "restart", "systemd-resolved"])
                emit("  OK  systemd-resolved configured", "ok")
                detail = "Linux DoH configured"
            except PermissionError:
                emit("  ERR  Permission denied — run as root", "err")
                ok = False
                detail = "Permission denied"

    emit("\n  NIST SC-20/SC-21 complete.", "info")
    return ok, detail
