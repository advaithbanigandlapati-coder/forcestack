"""scripts/encryption_check.py — NIST SC-28.
Fix #46: locale-independent manage-bde via -protectionaserrorcode.
"""
TOOL_NAME = "Full-Disk Encryption Check"
TOOL_ID   = "encryption_check"
from scripts._base import run_cmd, assert_tool_registered, TIMEOUT_MEDIUM
import re
assert_tool_registered(TOOL_ID)


def execute(emit, os_name):
    emit("  Checking full-disk encryption (NIST SC-28)...\n", "info")
    ok = True

    if os_name == "Windows":
        # Fix #46: use -protectionaserrorcode which returns numeric codes
        # regardless of Windows display language
        out_codes, found = run_cmd(
            ["manage-bde", "-status", "-protectionaserrorcode"],
            timeout=TIMEOUT_MEDIUM
        )
        if not found or not out_codes.strip():
            # Fall back to regular output if the flag isn't supported (older Windows)
            out_codes, found = run_cmd(["manage-bde", "-status"], timeout=TIMEOUT_MEDIUM)
            if not found:
                emit("  ERR  manage-bde not found. BitLocker requires Win Pro/Enterprise.", "err")
                return False, "manage-bde unavailable"

        # Parse drive letter blocks using position, not the word "Volume"
        drive_blocks = re.split(r'(?=^\s*(?:Volume|Laufwerk|Volumen)\s)', out_codes, flags=re.M)
        encrypted = []; unencrypted = []

        for block in drive_blocks:
            drive_m = re.search(r'\[([A-Z]:)\]', block)
            if not drive_m:
                continue
            drive = drive_m.group(1)
            # Numeric protection code: 0 = Protected, 1 = Off
            code_m = re.search(r'Protection\s+Status\s*:\s*(\d+)', block, re.I)
            # Fallback for non -protectionaserrorcode output (text)
            pct_m = re.search(r'Percentage\s+Encrypted\s*:\s*([\d.]+)%', block, re.I)
            if code_m and code_m.group(1) == "0":
                emit(f"  OK  {drive}  BitLocker ON (code 0 = Protected)", "ok")
                encrypted.append(drive)
            elif pct_m and float(pct_m.group(1)) >= 100.0:
                emit(f"  OK  {drive}  BitLocker ON (100%)", "ok")
                encrypted.append(drive)
            elif pct_m and float(pct_m.group(1)) > 0:
                emit(f"  WARN  {drive}  Encrypting...  {pct_m.group(1)}% done", "warn")
            else:
                emit(f"  ERR  {drive}  BitLocker OFF — DATA EXPOSED", "err")
                unencrypted.append(drive)

        if unencrypted:
            emit("\n  -> Control Panel > BitLocker Drive Encryption > Turn On", "info")
            ok = False
            detail = f"BitLocker OFF on {', '.join(unencrypted)}"
        else:
            detail = f"BitLocker ON: {', '.join(encrypted)}"

    elif os_name == "Darwin":
        out, _ = run_cmd(["fdesetup", "status"])
        emit(f"  {out.strip()}", "info")
        if "FileVault is On" in out:
            emit("  OK  FileVault ACTIVE", "ok")
            detail = "FileVault ON"
        else:
            emit("  ERR  FileVault OFF — System Settings > Privacy & Security > FileVault", "err")
            ok = False
            detail = "FileVault OFF"

    else:
        out, _ = run_cmd(["lsblk", "-o", "NAME,TYPE,FSTYPE,SIZE"])
        emit(out, "info")
        if "crypto_LUKS" in out:
            emit("  OK  LUKS encrypted volumes detected", "ok")
            detail = "LUKS found"
        else:
            emit("  ERR  No LUKS volumes found", "err")
            emit("  INFO  Enable during OS install or: cryptsetup luksFormat /dev/sdX", "info")
            ok = False
            detail = "No LUKS"

    emit("\n  NIST SC-28 check complete.", "info")
    return ok, detail
