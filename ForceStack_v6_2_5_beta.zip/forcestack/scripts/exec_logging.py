"""scripts/exec_logging.py — Command & script execution logging. NIST AU-2, AU-12, SI-4.
Windows: PowerShell script-block/module logging + command-line process auditing.
Linux: auditd execve rule. Reversible."""
TOOL_NAME = "Command & Script Execution Logging"
TOOL_ID   = "exec_logging"
from scripts._base import run_cmd, sudo_prefix, assert_tool_registered, TIMEOUT_MEDIUM
from pathlib import Path
assert_tool_registered(TOOL_ID)

_AUDIT_RULES = (
    "## ForceStack execution logging (NIST AU-12, SI-4) — remove file to revert\n"
    "-a always,exit -F arch=b64 -S execve -k forcestack_exec\n"
    "-a always,exit -F arch=b32 -S execve -k forcestack_exec\n"
)


def execute(emit, os_name):
    from core.hardening import apply_registry, backup_file
    emit("  Enabling deep execution logging (NIST AU-12, SI-4)...\n", "info")
    ok = True

    if os_name == "Windows":
        sb = r"HKLM\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging"
        ml = r"HKLM\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ModuleLogging"
        au = r"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit"
        ok &= apply_registry(emit, TOOL_ID, sb, "EnableScriptBlockLogging", "REG_DWORD", 1,
                             "PowerShell script-block logging (catches fileless attacks)")
        ok &= apply_registry(emit, TOOL_ID, ml, "EnableModuleLogging", "REG_DWORD", 1,
                             "PowerShell module logging")
        ok &= apply_registry(emit, TOOL_ID, au, "ProcessCreationIncludeCmdLine_Enabled",
                             "REG_DWORD", 1, "Record full command lines on process creation")
        detail = "Windows execution logging (verified, reversible)"

    elif os_name == "Darwin":
        emit("  INFO  Use macOS unified logging / EndpointSecurity; no changes made here.", "info")
        return True, "not applicable on macOS"

    else:
        rules = Path("/etc/audit/rules.d/99-forcestack.rules")
        try:
            backup_file(TOOL_ID, rules, "auditd execve rule (created)")
            rules.write_text(_AUDIT_RULES)
            loaded = run_cmd(sudo_prefix() + ["augenrules", "--load"], timeout=TIMEOUT_MEDIUM)[1] \
                or run_cmd(sudo_prefix() + ["auditctl", "-R", str(rules)], timeout=TIMEOUT_MEDIUM)[1]
            if rules.exists():
                emit("  OK  auditd execve logging rule installed"
                     + ("" if loaded else " (will load on next auditd restart)"), "ok")
            detail = "Linux auditd execve logging (reversible)"
        except (PermissionError, OSError) as _e:
            emit(f"  ERR  Could not apply (run as root?): {_e}", "err")
            return False, f"apply failed: {_e}"

    emit("\n  Execution logging complete.", "info")
    return ok, detail
