"""scripts/filesystem_hardening.py — Filesystem & removable-media hardening.
NIST CM-7, MP-7, SC-18. Windows: disable AutoRun/AutoPlay, enable SmartScreen.
Linux: blacklist uncommon filesystem modules. Reversible."""
TOOL_NAME = "Filesystem & Removable Media Hardening"
TOOL_ID   = "filesystem_hardening"
from scripts._base import assert_tool_registered
from pathlib import Path
assert_tool_registered(TOOL_ID)

_BLACKLIST_FS = ["cramfs", "freevxfs", "jffs2", "hfs", "hfsplus", "udf"]


def execute(emit, os_name):
    from core.hardening import apply_registry, backup_file
    emit("  Hardening filesystems and removable media (NIST CM-7, MP-7)...\n", "info")
    ok = True

    if os_name == "Windows":
        exp = r"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer"
        sys = r"HKLM\SOFTWARE\Policies\Microsoft\Windows\System"
        ok &= apply_registry(emit, TOOL_ID, exp, "NoDriveTypeAutoRun", "REG_DWORD", 255,
                             "Disable AutoRun on all drive types")
        ok &= apply_registry(emit, TOOL_ID, exp, "NoAutorun", "REG_DWORD", 1,
                             "Disable AutoPlay")
        ok &= apply_registry(emit, TOOL_ID, sys, "EnableSmartScreen", "REG_DWORD", 1,
                             "Enable SmartScreen reputation checks")
        detail = "Windows AutoRun/AutoPlay off, SmartScreen on (verified, reversible)"

    elif os_name == "Darwin":
        emit("  INFO  macOS does not auto-mount exotic filesystems; no changes made.", "info")
        return True, "not applicable on macOS"

    else:
        bl = Path("/etc/modprobe.d/99-forcestack-blacklist.conf")
        try:
            backup_file(TOOL_ID, bl, "filesystem module blacklist (created)")
            body = ("# ForceStack filesystem hardening (NIST CM-7) — remove file to revert\n"
                    + "\n".join(f"install {fs} /bin/true" for fs in _BLACKLIST_FS) + "\n")
            bl.write_text(body)
            emit(f"  OK  Blacklisted {len(_BLACKLIST_FS)} uncommon filesystem modules "
                 f"({', '.join(_BLACKLIST_FS)})", "ok")
            detail = f"Linux fs blacklist: {len(_BLACKLIST_FS)} modules (reversible)"
        except (PermissionError, OSError) as _e:
            emit(f"  ERR  Could not apply (run as root?): {_e}", "err")
            return False, f"apply failed: {_e}"

    emit("\n  Filesystem hardening complete.", "info")
    return ok, detail
