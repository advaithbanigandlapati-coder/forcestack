"""scripts/firewall_config.py — NIST SC-7, CA-3, AC-4.
Fix #47: conditional SSH allow. Fix #48: macOS blockall. Fix #86: no shell=True.
"""
TOOL_NAME = "Configure Firewall"
TOOL_ID   = "firewall_config"
from scripts._base import run_cmd, sudo_prefix, assert_tool_registered
assert_tool_registered(TOOL_ID)


def execute(emit, os_name):
    emit("  Configuring host-based firewall (NIST SC-7)...\n", "info")
    ok = True

    if os_name == "Windows":
        # Fix #86: list-form args, not shell=True
        st, _ = run_cmd(["netsh", "advfirewall", "show", "allprofiles", "state"])
        if "ON" in st.upper():
            emit("  OK  Firewall already enabled", "ok")
        else:
            _, ok1 = run_cmd(["netsh", "advfirewall", "set", "allprofiles", "state", "on"])
            emit(f"  {'OK' if ok1 else 'ERR'}  Firewall enabled on all profiles",
                 "ok" if ok1 else "err")
            ok = ok and ok1
            if ok1:
                try:
                    from core.hardening import record_undo
                    record_undo(TOOL_ID,
                        ["netsh", "advfirewall", "set", "allprofiles", "state", "off"],
                        "Turn Windows Firewall back off (was off before)")
                except Exception:
                    pass

        _, ok2 = run_cmd(["netsh", "advfirewall", "set", "allprofiles",
                          "firewallpolicy", "blockinbound,allowoutbound"])
        emit(f"  {'OK' if ok2 else 'ERR'}  Policy: inbound BLOCK / outbound ALLOW",
             "ok" if ok2 else "err")
        ok = ok and ok2
        emit("  INFO  Default-deny inbound blocks all ports — no redundant per-port rules", "info")

        run_cmd(["netsh", "advfirewall", "set", "allprofiles",
                 "logging", "droppedconnections", "enable"])
        run_cmd(["netsh", "advfirewall", "set", "allprofiles",
                 "logging", "maxfilesize", "4096"])
        emit("  OK  Drop logging enabled (NIST AU-12)", "ok")
        detail = "Windows Firewall: default-deny inbound + logging"

    elif os_name == "Darwin":
        fw  = "/usr/libexec/ApplicationFirewall/socketfilterfw"
        pfx = sudo_prefix()
        prior_fw, _ = run_cmd([fw, "--getglobalstate"])
        run_cmd(pfx + [fw, "--setglobalstate", "on"])
        run_cmd(pfx + [fw, "--setstealthmode",  "on"])
        run_cmd(pfx + [fw, "--setloggingmode",  "on"])
        # Fix #48: blockall mode for enterprise-grade posture
        run_cmd(pfx + [fw, "--setblockall", "on"])
        emit("  OK  macOS firewall: ON + stealth + logging + block-all", "ok")
        if "disabled" in prior_fw.lower():
            try:
                from core.hardening import record_undo
                record_undo(TOOL_ID, pfx + [fw, "--setglobalstate", "off"],
                            "Turn macOS firewall back off (was off before)")
            except Exception:
                pass
        detail = "macOS Application Firewall: blockall mode"

    else:
        pfx = sudo_prefix()  # fix #30
        prior_ufw, _ = run_cmd(["ufw", "status"])
        run_cmd(pfx + ["ufw", "default", "deny",  "incoming"])
        run_cmd(pfx + ["ufw", "default", "allow", "outgoing"])

        # Fix #47: only allow SSH if sshd is actually running
        ssh_active, _ = run_cmd(["systemctl", "is-active", "sshd"])
        ssh_active2, _ = run_cmd(["systemctl", "is-active", "ssh"])
        if "active" in ssh_active or "active" in ssh_active2:
            run_cmd(pfx + ["ufw", "allow", "ssh"])
            emit("  OK  SSH exception added (sshd is running)", "ok")
        else:
            emit("  INFO  SSH not active — no inbound SSH rule added", "info")

        _, ok = run_cmd(pfx + ["ufw", "--force", "enable"])
        run_cmd(pfx + ["ufw", "logging", "on"])
        emit("  OK  UFW: deny-inbound, allow-outbound, logging on", "ok")
        if "inactive" in prior_ufw.lower():
            try:
                from core.hardening import record_undo
                record_undo(TOOL_ID, pfx + ["ufw", "disable"],
                            "Disable UFW (was inactive before)")
            except Exception:
                pass
        detail = "UFW enabled with default-deny inbound"

    emit("\n  NIST SC-7 complete.", "info")
    return ok, detail
