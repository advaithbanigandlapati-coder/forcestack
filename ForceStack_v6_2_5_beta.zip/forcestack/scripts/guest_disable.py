"""scripts/guest_disable.py — NIST AC-2, AC-3.
Fix #29: ok never updated from ok1 in Linux branch — script always returned True.
Fix #30: detail always said "locked" regardless of outcome.
Fix #31: missing assert_tool_registered(TOOL_ID).
Fix #32: sudo_prefix() not imported; Linux branch hardcoded "sudo".
Fix #33: macOS branch hardcoded "sudo" instead of using sudo_prefix().
"""
TOOL_NAME = "Disable Guest Account"
TOOL_ID   = "guest_disable"
from scripts._base import run_cmd, sudo_prefix, assert_tool_registered
assert_tool_registered(TOOL_ID)


def execute(emit, os_name):
    emit("  Disabling guest accounts (NIST AC-2)…\n", "info")
    ok = True

    if os_name == "Windows":
        from core.hardening import apply_registry
        _, ok1 = run_cmd(["net", "user", "Guest", "/active:no"])
        emit(f"  {'✓' if ok1 else '✗'}  Guest account disabled", "ok" if ok1 else "err")
        lsa = r"HKLM\SYSTEM\CurrentControlSet\Control\Lsa"
        ok2 = apply_registry(emit, TOOL_ID,
            r"HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\SpecialAccounts\UserList",
            "Guest", "REG_DWORD", 0, "Guest hidden from login screen")
        ok3 = apply_registry(emit, TOOL_ID, lsa, "RestrictAnonymous", "REG_DWORD", 1,
                             "Anonymous enumeration blocked (RestrictAnonymous)")
        ok4 = apply_registry(emit, TOOL_ID, lsa, "RestrictAnonymousSAM", "REG_DWORD", 1,
                             "Anonymous SAM enumeration blocked")
        ok = ok1 and ok2 and ok3 and ok4
        detail = "Guest disabled + anonymous enumeration blocked (verified, reversible)"

    elif os_name == "Darwin":
        pfx = sudo_prefix()  # fix #33
        run_cmd(pfx + ["defaults", "write",
                        "/Library/Preferences/com.apple.loginwindow",
                        "GuestEnabled", "-bool", "NO"])
        run_cmd(pfx + ["defaults", "write",
                        "/Library/Preferences/com.apple.loginwindow",
                        "ShowGuestAccount", "-bool", "NO"])
        emit("  ✓  macOS Guest disabled and hidden", "ok")
        detail = "macOS Guest disabled"

    else:
        pfx = sudo_prefix()  # fix #32
        locked = []
        failed = []
        for acc in ["guest", "nobody", "ftp"]:
            _, ok1 = run_cmd(pfx + ["passwd", "-l", acc])
            if ok1:
                locked.append(acc)
                emit(f"  ✓  {acc}: locked", "ok")
            else:
                failed.append(acc)
                emit(f"  ⊘  {acc}: not found or already locked", "info")
        ok = len(failed) == 0 or (locked and not failed)  # fix #29: reflect actual outcome
        detail = (
            f"Linux locked: {', '.join(locked) or 'none'}; "
            f"skipped: {', '.join(failed) or 'none'}"
        )  # fix #30: accurate detail

    emit("\n  NIST AC-2 complete.", "info")
    return ok, detail

