"""scripts/hosts_blocklist.py — NIST SC-7, SI-3.
Fix #49: atomic write. Fix #50: MS telemetry domains moved to opt-in aggressive list.
"""
TOOL_NAME = "Hosts File Blocklist"
TOOL_ID   = "hosts_blocklist"
from scripts._base import run_cmd, sudo_prefix, assert_tool_registered
import platform
from pathlib import Path
from datetime import datetime
assert_tool_registered(TOOL_ID)

HOSTS_PATH = (Path(r"C:\Windows\System32\drivers\etc\hosts")
              if platform.system() == "Windows" else Path("/etc/hosts"))
FORCESTACK_TAG = "# ForceStack SC-7"

# Fix #50: ONLY real malware/tracking domains — no MS telemetry that breaks Windows Update
BLOCKLIST_DEFAULT = [
    "0.0.0.0 doubleclick.net",
    "0.0.0.0 googleadservices.com",
    "0.0.0.0 pagead2.googlesyndication.com",
    "0.0.0.0 adservice.google.com",
    "0.0.0.0 coinhive.com",
    "0.0.0.0 coin-hive.com",
    "0.0.0.0 jsecoin.com",
    "0.0.0.0 cryptoloot.pro",
    "0.0.0.0 tracking.opencandy.com",
    "0.0.0.0 stats.g.doubleclick.net",
    "0.0.0.0 securepubads.g.doubleclick.net",
    "0.0.0.0 ade.googlesyndication.com",
    "0.0.0.0 cdn.cloudfront-dl.com",
]

# Opt-in aggressive list — not applied by default (fix #50)
BLOCKLIST_AGGRESSIVE = [
    "# AGGRESSIVE (may break Windows Update / Defender — use only on offline systems)",
    "# 0.0.0.0 telemetry.microsoft.com",
    "# 0.0.0.0 vortex.data.microsoft.com",
    "# 0.0.0.0 settings-win.data.microsoft.com",
    "# 0.0.0.0 metrics.apple.com",
]

STEVENBLACK_URL = (
    "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts"
)


def _fetch_stevenblack(emit) -> list[str]:
    """
    Fix #14: attempt to fetch the StevenBlack unified 50k-domain list.
    Falls back gracefully to BLOCKLIST_DEFAULT if network is unavailable.
    """
    try:
        import urllib.request
        emit("  INFO  Fetching StevenBlack unified hosts list...", "info")
        req = urllib.request.Request(STEVENBLACK_URL, headers={"User-Agent": "ForceStack/3.4"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            raw = resp.read().decode("utf-8", errors="ignore")
        # Extract only the 0.0.0.0 block lines (skip comments and localhost section)
        lines = [
            l for l in raw.splitlines()
            if l.startswith("0.0.0.0 ") and not l.startswith("0.0.0.0 0.0.0.0")
        ]
        emit(f"  OK  Fetched {len(lines):,} block entries from StevenBlack", "ok")
        return lines
    except Exception as e:
        emit(f"  WARN  Could not fetch StevenBlack list ({e}) — using built-in defaults", "warn")
        return []


def execute(emit, os_name):
    emit("  Updating hosts blocklist (NIST SC-7, SI-3)...\n", "info")
    emit(f"  Hosts file: {HOSTS_PATH}", "info")
    ok = True

    # Fix #14: try to fetch live StevenBlack list; fall back to built-in defaults
    fetched = _fetch_stevenblack(emit)
    domains = fetched if fetched else BLOCKLIST_DEFAULT
    source_label = "StevenBlack unified" if fetched else "built-in defaults"
    emit(f"  INFO  Applying {len(domains):,} entries ({source_label})...\n", "info")

    try:
        existing = HOSTS_PATH.read_text(encoding="utf-8", errors="ignore")
        # Idempotent: strip previous ForceStack block
        lines = [l for l in existing.splitlines() if FORCESTACK_TAG not in l]
        header = [
            "",
            f"{FORCESTACK_TAG} — {datetime.now().strftime('%Y-%m-%d %H:%M')}",
            "# Remove lines containing '# ForceStack SC-7' to undo",
        ]
        new_content = "\n".join(lines + header + domains +
                                [""] + BLOCKLIST_AGGRESSIVE) + "\n"

        # Fix #49: atomic write via temp → replace (not in-place overwrite)
        tmp = HOSTS_PATH.with_suffix(".forcestack_tmp")
        tmp.write_text(new_content, encoding="utf-8")
        tmp.replace(HOSTS_PATH)

        emit(f"  OK  {len(domains):,} domains blocked via {source_label} (atomic write, idempotent)", "ok")
        emit("  OK  Aggressive telemetry block is commented out (opt-in only)", "info")

        # Flush DNS
        if os_name == "Windows":
            run_cmd(["ipconfig", "/flushdns"])
        elif os_name == "Darwin":
            pfx = sudo_prefix()
            run_cmd(pfx + ["dscacheutil", "-flushcache"])
            run_cmd(pfx + ["killall", "-HUP", "mDNSResponder"])
        else:
            pfx = sudo_prefix()
            run_cmd(pfx + ["systemctl", "restart", "systemd-resolved"])
        emit("  OK  DNS cache flushed", "ok")
        detail = f"{len(domains):,} domains blocked ({source_label})"

    except PermissionError:
        emit("  ERR  Permission denied — run as Administrator/root", "err")
        ok = False
        detail = "Permission denied"
    except Exception as e:
        emit({
            "title": "Could not update hosts file",
            "why": (
                "The hosts file controls which domains your computer is allowed to reach. "
                "The update failed, so none of the blocklist entries were applied and "
                "your previous hosts file is unchanged."
            ),
            "fix": (
                "Check that no other program has the hosts file open (e.g. a text editor)\n"
                f"Hosts file location: {HOSTS_PATH}\n"
                "On Windows: run ForceStack as Administrator\n"
                "On Linux/macOS: run with sudo python3 main.py"
            ),
            "raw": f"{type(e).__name__}: {e}",
        }, "err")
        ok = False
        detail = str(e)

    emit("\n  NIST SC-7 hosts blocklist applied.", "info")
    return ok, detail
