"""scripts/kernel_hardening.py — Kernel & network stack hardening. NIST SC-7, SI-3, CM-7.
Fully reversible: Linux writes a sysctl.d drop-in (backed up first); Windows uses the
verified apply_registry path. Undo from the Change Journal."""
TOOL_NAME = "Kernel & Network Stack Hardening"
TOOL_ID   = "kernel_hardening"
from scripts._base import run_cmd, sudo_prefix, assert_tool_registered, TIMEOUT_MEDIUM
from pathlib import Path
assert_tool_registered(TOOL_ID)

_SYSCTL = [
    ("kernel.kptr_restrict", "2"), ("kernel.dmesg_restrict", "1"),
    ("kernel.yama.ptrace_scope", "1"), ("net.ipv4.tcp_syncookies", "1"),
    ("net.ipv4.conf.all.rp_filter", "1"), ("net.ipv4.conf.all.accept_redirects", "0"),
    ("net.ipv4.conf.all.send_redirects", "0"), ("net.ipv4.conf.all.accept_source_route", "0"),
    ("fs.protected_hardlinks", "1"), ("fs.protected_symlinks", "1"), ("fs.suid_dumpable", "0"),
]


def execute(emit, os_name):
    from core.hardening import apply_registry, backup_file
    emit("  Hardening kernel and network stack (NIST SC-7, SI-3)...\n", "info")
    ok = True

    if os_name == "Windows":
        tcp = r"HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters"
        ok &= apply_registry(emit, TOOL_ID, tcp, "DisableIPSourceRouting", "REG_DWORD", 2,
                             "Block IP source routing")
        ok &= apply_registry(emit, TOOL_ID, tcp, "EnableICMPRedirect", "REG_DWORD", 0,
                             "Ignore ICMP redirects")
        ok &= apply_registry(emit, TOOL_ID, tcp, "SynAttackProtect", "REG_DWORD", 1,
                             "SYN-flood protection")
        detail = "Windows TCP/IP hardening (verified, reversible)"

    elif os_name == "Darwin":
        emit("  INFO  macOS uses different tunables; no changes made by this tool.", "info")
        return True, "not applicable on macOS"

    else:
        conf = Path("/etc/sysctl.d/99-forcestack-hardening.conf")
        try:
            backup_file(TOOL_ID, conf, "sysctl hardening drop-in")
            body = ("# ForceStack kernel hardening (NIST SC-7, SI-3) — remove to revert\n"
                    + "\n".join(f"{k} = {v}" for k, v in _SYSCTL) + "\n")
            conf.write_text(body)
            run_cmd(sudo_prefix() + ["sysctl", "--system"], timeout=TIMEOUT_MEDIUM)
            good = 0
            for k, v in _SYSCTL:
                out, _ = run_cmd(["sysctl", "-n", k])
                if out.strip() == v:
                    good += 1
            emit(f"  OK  Wrote {len(_SYSCTL)} protections; verified {good}/{len(_SYSCTL)} live", "ok")
            ok = good > 0
            detail = f"kernel hardening: {good}/{len(_SYSCTL)} sysctls verified"
        except (PermissionError, OSError) as _e:
            emit(f"  ERR  Could not apply (run as root?): {_e}", "err")
            return False, f"apply failed: {_e}"

    emit("\n  Kernel hardening complete.", "info")
    return ok, detail
