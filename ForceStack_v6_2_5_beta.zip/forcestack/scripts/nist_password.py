"""scripts/nist_password.py — NIST IA-5, SP 800-63B.
Fix #51: macOS plist cleanup. Fix #52: append missing keys. Fix #53: pwquality merge.
Fix #4: MIN_LEN/MAX_AGE read inside execute() so re-runs see updated env vars.
Fix #53: structured PermissionError emit explains pwquality.conf and how to get access.
"""
TOOL_NAME = "NIST Password Policy"
TOOL_ID   = "nist_password"
from scripts._base import run_cmd, clean_temp, sudo_prefix, assert_tool_registered
import tempfile, os, re
from pathlib import Path
assert_tool_registered(TOOL_ID)

_MIN_LEN_DEFAULT = 15
_MAX_AGE_DEFAULT = 365
MIN_AGE  = 1
HISTORY  = 24


def execute(emit, os_name):
    # Fix #4: read env vars here, not at module level, so re-runs in the same
    # process (e.g. after changing settings in the GUI) see fresh values.
    MIN_LEN = int(os.environ.get("FORCESTACK_MIN_PW_LEN", _MIN_LEN_DEFAULT))
    MAX_AGE = int(os.environ.get("FORCESTACK_MAX_PW_AGE", _MAX_AGE_DEFAULT))
    emit(f"  NIST SP 800-63B: min {MIN_LEN} chars, max {MAX_AGE} days, history {HISTORY}...\n", "info")
    ok = True

    if os_name == "Windows":
        _, ok1 = run_cmd(["net", "accounts",
                          f"/minpwlen:{MIN_LEN}", f"/maxpwage:{MAX_AGE}",
                          f"/minpwage:{MIN_AGE}", f"/uniquepw:{HISTORY}"])
        emit(f"  {'OK' if ok1 else 'ERR'}  net accounts policy applied", "ok" if ok1 else "err")
        inf = (f"[Unicode]\nUnicode=yes\n[System Access]\n"
               f"MinimumPasswordLength={MIN_LEN}\nMaximumPasswordAge={MAX_AGE}\n"
               f"MinimumPasswordAge={MIN_AGE}\nPasswordHistorySize={HISTORY}\n"
               f"ClearTextPassword=0\nPasswordComplexity=0\n"
               f"[Version]\nSignature=\"$CHICAGO$\"\nRevision=1\n")
        tmp = Path(tempfile.gettempdir()) / "forcestack_pw.inf"
        db  = Path(tempfile.gettempdir()) / "forcestack_pw.sdb"
        try:
            tmp.write_text(inf)
            run_cmd(["secedit", "/configure", "/db", str(db),
                     "/cfg", str(tmp), "/quiet"])
            emit("  OK  secedit policy applied", "ok")
        finally:
            clean_temp(tmp); clean_temp(db)
        ok = ok1
        detail = f"NIST policy: {MIN_LEN} chars, {MAX_AGE}d, history {HISTORY}"

    elif os_name == "Darwin":
        plist = (f'<?xml version="1.0"?><plist version="1.0"><dict>'
                 f'<key>minChars</key><integer>{MIN_LEN}</integer>'
                 f'<key>maxMinutesUntilChangePassword</key><integer>{MAX_AGE * 1440}</integer>'
                 f'<key>usingHistory</key><integer>{HISTORY}</integer>'
                 f'<key>requiresNumeric</key><false/></dict></plist>')
        # Fix #51: use mkstemp and always clean up
        tmp_fd, tmp_path = tempfile.mkstemp(suffix=".plist", prefix="forcestack_pw_")
        try:
            os.write(tmp_fd, plist.encode())
            os.close(tmp_fd)
            _, ok = run_cmd(sudo_prefix() + ["pwpolicy", "-setaccountpolicies", tmp_path])
            emit(f"  {'OK' if ok else 'ERR'}  macOS pwpolicy applied", "ok" if ok else "err")
        finally:
            clean_temp(Path(tmp_path))  # fix #51: always deleted
        detail = f"macOS pwpolicy: {MIN_LEN} chars, {MAX_AGE}d"

    else:
        # Fix #53: merge-write pwquality.conf
        conf = Path("/etc/security/pwquality.conf")
        managed = {
            "minlen":    str(MIN_LEN),
            "dcredit":   "0",
            "ucredit":   "0",
            "lcredit":   "0",
            "ocredit":   "0",
            "maxrepeat": "3",
        }
        try:
            existing = conf.read_text().splitlines() if conf.exists() else []
            new_lines = []
            written = set()
            for line in existing:
                key = line.split("=")[0].strip().lstrip("#").strip()
                if key in managed:
                    new_lines.append(f"{key}={managed[key]}")
                    written.add(key)
                else:
                    new_lines.append(line)
            for k, v in managed.items():
                if k not in written:
                    new_lines.append(f"{k}={v}")
            conf.write_text("\n".join(new_lines) + "\n")
            emit(f"  OK  {conf} merged (site settings preserved)", "ok")
        except PermissionError:
            emit({
                "title": "Cannot write password policy (pwquality.conf)",
                "why": (
                    "/etc/security/pwquality.conf is the Linux PAM configuration that enforces "
                    "password strength rules — minimum length, complexity, and history. Without "
                    "write access, the NIST SP 800-63B password policy cannot be applied and "
                    "users can continue setting weak passwords."
                ),
                "fix": (
                    "Run ForceStack with elevated privileges: sudo python3 main.py\n"
                    "Or apply manually:\n"
                    f"  sudo nano /etc/security/pwquality.conf\n"
                    f"  Add: minlen={int(__import__('os').environ.get('FORCESTACK_MIN_PW_LEN', 15))}"
                ),
                "raw": "PermissionError writing /etc/security/pwquality.conf",
            }, "err")
            ok = False

        # Fix #52: regex + append-if-missing for login.defs
        defs = Path("/etc/login.defs")
        if defs.exists():
            try:
                content = defs.read_text()
                targets = {
                    "PASS_MAX_DAYS": str(MAX_AGE),
                    "PASS_MIN_LEN":  str(MIN_LEN),
                }
                for key, val in targets.items():
                    if re.search(rf'^{key}\s', content, re.M):
                        content = re.sub(rf'^({key})\s+\S+', rf'\1   {val}', content, flags=re.M)
                    else:
                        # Fix #52: append if key absent
                        content += f"\n{key}   {val}\n"
                defs.write_text(content)
                emit("  OK  /etc/login.defs updated (append-if-missing)", "ok")
            except PermissionError:
                emit("  INFO  Cannot write login.defs — run as root", "info")
        detail = f"PAM pwquality merged: {MIN_LEN} chars, {MAX_AGE}d max"

    emit("\n  NIST IA-5 / SP 800-63B complete.", "info")
    return ok, detail
