"""scripts/open_ports.py — Fix #54: real Windows admin check. Fix #55: process-based flagging.
Fix #52: structured access-denied emit; RISKY dict includes plain-English descriptions.
"""
TOOL_NAME = "Open Ports Scanner"; TOOL_ID = "open_ports"
from scripts._base import assert_tool_registered
import os, psutil
assert_tool_registered(TOOL_ID)

# Each entry: port → (service name, plain-English risk description)
RISKY: dict[int, tuple[str, str]] = {
    21:    ("FTP",        "transmits files and passwords in plain text — trivially intercepted on any network"),
    23:    ("Telnet",     "unencrypted remote login — your keystrokes are visible to anyone on the network"),
    25:    ("SMTP",       "mail relay — an open mail server can be abused to send spam or phishing email"),
    135:   ("MS-RPC",     "Windows remote procedure calls — exploited by worms like Blaster and Conficker"),
    137:   ("NetBIOS-NS", "Windows name service — leaks machine names and network layout to attackers"),
    139:   ("NetBIOS",    "legacy Windows file sharing — multiple known exploits, superseded by SMB3"),
    445:   ("SMB",        "Windows file sharing — used by WannaCry and NotPetya ransomware; firewall externally"),
    512:   ("rexec",      "remote execution with no authentication required"),
    513:   ("rlogin",     "remote login with no encryption — predates SSH"),
    514:   ("rsh",        "remote shell with no encryption or authentication"),
    1433:  ("MSSQL",      "SQL Server exposed to network — common target for ransomware and data theft"),
    1521:  ("Oracle DB",  "Oracle database exposed to network — should not be publicly accessible"),
    3306:  ("MySQL",      "MySQL database exposed — thousands of breaches from default no-auth configs"),
    3389:  ("RDP",        "Windows Remote Desktop — brute-forced continuously by ransomware groups; use VPN instead"),
    4444:  ("Metasploit", "Metasploit default listener port — indicates an attack framework running on this machine"),
    5900:  ("VNC",        "remote desktop (VNC) — often unencrypted and regularly brute-forced"),
    6667:  ("IRC",        "Internet Relay Chat — rarely legitimate; commonly used by malware for command-and-control"),
    27017: ("MongoDB",    "MongoDB exposed — many breaches from databases left open with no authentication"),
}


def execute(emit, os_name):
    emit("  Scanning listening ports (NIST CM-7, RA-5)...\n", "info")
    # Fix #54: proper admin detection per platform
    if os_name == "Windows":
        import ctypes
        try: is_admin = bool(ctypes.windll.shell32.IsUserAnAdmin())
        except Exception: is_admin = False
    else:
        is_admin = os.geteuid() == 0
    if not is_admin:
        emit("  WARN  Not admin/root — process names may show as 'unknown'", "warn")
    try:
        conns = psutil.net_connections(kind="inet")
    except psutil.AccessDenied:
        emit({
            "title": "Cannot scan open ports — permission denied",
            "why": (
                "Scanning which programs are listening on which ports requires administrator "
                "access. Without it, the scan cannot identify unauthorized services or detect "
                "malware that may be listening for remote connections."
            ),
            "fix": (
                "On Windows: right-click ForceStack → Run as Administrator\n"
                "On Linux/macOS: run with sudo python3 main.py"
            ),
            "raw": "psutil.AccessDenied when calling net_connections(kind='inet')",
        }, "err")
        return False, "Access denied"

    seen = {}
    for c in conns:
        if c.status == "LISTEN" and c.laddr:
            port = c.laddr.port
            if port not in seen:
                try: proc = psutil.Process(c.pid).name() if c.pid else "unknown"
                except Exception: proc = "unknown"
                seen[port] = proc

    flagged = []
    emit(f"  {'PORT':<8} {'PROCESS':<26} STATUS", "info")
    emit(f"  {'─' * 58}", "info")
    for port in sorted(seen):
        proc = seen[port]
        info = RISKY.get(port)
        if info:
            label, reason = info
            # Fix #52: include plain-English reason so non-technical users understand the risk
            emit(f"  :{port:<7} {proc:<26} ⚠  {label}", "warn")
            emit(f"           {reason}", "warn")
            flagged.append(port)
        else:
            emit(f"  :{port:<7} {proc:<26} OK", "ok")

    emit(f"\n  Total: {len(seen)}  Flagged: {len(flagged)}", "info")
    if flagged:
        emit("  Flagged ports should be closed with a firewall rule if not actively needed.", "warn")
        emit("  On Linux: sudo ufw deny <port>   On Windows: Windows Firewall → Inbound Rules", "info")
    emit("\n  NIST CM-7 scan complete.", "info")
    return len(flagged) == 0, f"{len(seen)} ports, {len(flagged)} flagged"
