"""scripts/rdp_hardening.py — NIST AC-17, IA-2, SC-8.
Fix #56: single open() with fcntl lock for sshd_config. Fix #57: detect sshd vs ssh service name.
"""
TOOL_NAME = "Harden RDP and SSH"
TOOL_ID   = "rdp_hardening"
from scripts._base import run_cmd, sudo_prefix, assert_tool_registered
from pathlib import Path
assert_tool_registered(TOOL_ID)

FORCESTACK_SSH_TAG = "# ForceStack NIST AC-17 SSH"
SSHD_CONF        = Path("/etc/ssh/sshd_config")

SSH_HARDENING = (
    "\n{tag}\n"
    "Protocol 2\n"
    "PermitRootLogin no\n"
    "PasswordAuthentication no\n"
    "MaxAuthTries 3\n"
    "ClientAliveInterval 300\n"
    "ClientAliveCountMax 2\n"
    "X11Forwarding no\n"
    "AllowTcpForwarding no\n"
    "KexAlgorithms curve25519-sha256,ecdh-sha2-nistp521\n"
    "Ciphers chacha20-poly1305@openssh.com,aes256-gcm@openssh.com\n"
    "MACs hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com\n"
)


def _detect_ssh_service() -> str:
    """Fix #57: detect 'sshd' vs 'ssh' (Ubuntu 22.04+ uses 'ssh').
    Fix #40: fetch systemctl output once before loop, not once per iteration."""
    out, _ = run_cmd(["systemctl", "list-units", "--type=service",
                      "--all", "--no-pager", "--plain"])
    for name in ("sshd", "ssh"):
        if f"{name}.service" in out:
            return name
    return "sshd"  # fallback


def execute(emit, os_name):
    emit("  Hardening RDP and SSH access (NIST AC-17, SC-8)...\n", "info")
    ok = True

    if os_name == "Windows":
        # Each change is applied, READ BACK to verify it took, and journalled so
        # it can be reverted precisely (core/hardening.py). ok reflects reality.
        from core.hardening import apply_registry
        rdp = r"HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"
        ts = r"HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server"
        ok &= apply_registry(emit, TOOL_ID, rdp, "UserAuthentication", "REG_DWORD", 1,
                             "NLA (Network Level Authentication) required")
        ok &= apply_registry(emit, TOOL_ID, rdp, "SecurityLayer", "REG_DWORD", 2,
                             "Security layer: TLS required (not RDP legacy)")
        ok &= apply_registry(emit, TOOL_ID, rdp, "MinEncryptionLevel", "REG_DWORD", 3,
                             "Encryption level: High (128-bit)")
        ok &= apply_registry(emit, TOOL_ID, ts, "fDenyTSConnections", "REG_DWORD", 1,
                             "RDP disabled by default (enable only when needed)")
        detail = "RDP: NLA + TLS + disabled by default (verified, reversible)"

    elif os_name == "Darwin":
        pfx = sudo_prefix()  # fix #39: use sudo_prefix() not hardcoded "sudo"
        out, _ = run_cmd(pfx + ["systemsetup", "-getremotelogin"])
        if "On" in out:
            emit("  INFO  Remote Login (SSH) is ON — consider disabling when not needed", "warn")
        else:
            emit("  OK  Remote Login (SSH) is OFF", "ok")
        run_cmd(pfx + ["systemsetup", "-setremotelogin", "off"])
        emit("  OK  Remote Login disabled (NIST AC-17)", "ok")
        run_cmd(pfx + ["defaults", "write", "/Library/Preferences/com.apple.ScreenSharing",
                 "keepAlive", "-bool", "false"])
        emit("  OK  Screen Sharing disabled", "ok")
        detail = "macOS: Remote Login + Screen Sharing disabled"

    else:
        if not SSHD_CONF.exists():
            emit("  INFO  sshd_config not found — SSH may not be installed", "info")
            return True, "sshd not installed"

        # Fix #56: single open() call with exclusive lock to avoid TOCTOU
        try:
            import fcntl
            from core.hardening import backup_file
            with open(SSHD_CONF, "r+") as fh:
                fcntl.flock(fh, fcntl.LOCK_EX)
                content = fh.read()
                if FORCESTACK_SSH_TAG in content:
                    emit("  OK  SSH hardening already applied (idempotent)", "ok")
                else:
                    # Snapshot the original config first so this is reversible.
                    backup_file(TOOL_ID, SSHD_CONF, "sshd_config before SSH hardening")
                    fh.seek(0, 2)  # seek to end
                    fh.write(SSH_HARDENING.format(tag=FORCESTACK_SSH_TAG))
                    emit("  OK  SSH hardening block appended (original backed up)", "ok")
                fcntl.flock(fh, fcntl.LOCK_UN)
        except ImportError:
            # Windows fallback (no fcntl) — won't reach here but be safe
            with open(SSHD_CONF, "a") as fh:
                if FORCESTACK_SSH_TAG not in Path(SSHD_CONF).read_text():
                    fh.write(SSH_HARDENING.format(tag=FORCESTACK_SSH_TAG))
        except PermissionError:
            emit("  ERR  Permission denied on sshd_config — run as root", "err")
            return False, "Permission denied"

        # Fix #57: detect correct service name
        svc = _detect_ssh_service()
        pfx = sudo_prefix()
        run_cmd(pfx + ["systemctl", "restart", svc])
        emit(f"  OK  {svc} restarted with hardened config", "ok")
        emit({
            "title": "Verify SSH still works before closing this session",
            "why": (
                "SSH hardening has been applied and the SSH daemon restarted. If the new "
                "config contains an error, or your key-based login isn't set up, you could "
                "be locked out of this machine permanently — especially on a remote server."
            ),
            "fix": (
                "Right now, from a DIFFERENT terminal window or machine, test:\n"
                f"  ssh <your-username>@<this-host>\n"
                "If login succeeds: you're good. Keep this session open until confirmed.\n"
                "If login FAILS:\n"
                f"  1. In this session: sudo systemctl stop {svc}\n"
                f"  2. Remove the ForceStack hardening block from /etc/ssh/sshd_config\n"
                f"     (lines between '# ForceStack NIST AC-17 SSH' and end of file)\n"
                f"  3. sudo systemctl start {svc}\n"
                "For key-based login: sudo nano ~/.ssh/authorized_keys and paste your public key"
            ),
            "raw": f"sshd_config updated and {svc} restarted",
        }, "warn")
        detail = "SSH hardened: NLA + crypto + restart"

    emit("\n  NIST AC-17 complete.", "info")
    return ok, detail
