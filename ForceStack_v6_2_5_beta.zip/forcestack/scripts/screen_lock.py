"""scripts/screen_lock.py — NIST AC-11, AC-12.
Fix #58: gsettings runs as actual user not root.
Fix #4: TIMEOUT_SECS read inside execute() so re-runs in the same process see updated env.
"""
TOOL_NAME = "Screen Lock Timeout"
TOOL_ID   = "screen_lock"
from scripts._base import run_cmd, sudo_prefix, assert_tool_registered
import os
import re  # fix #42: stdlib import belongs at top, not inside execute()
from pathlib import Path
assert_tool_registered(TOOL_ID)

_TIMEOUT_SECS_DEFAULT = 600


def execute(emit, os_name):
    # Fix #4: read env var here, not at module level, so the value is never stale
    # across re-runs in the same process (e.g. after a user changes settings in the GUI).
    TIMEOUT_SECS = int(os.environ.get("FORCESTACK_TIMEOUT_SECS", _TIMEOUT_SECS_DEFAULT))
    emit(f"  Screen lock: {TIMEOUT_SECS//60}min timeout (NIST AC-11)...\n", "info")
    ok = True

    if os_name == "Windows":
        from core.hardening import apply_registry
        sys_pol = r"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"
        desk = r"HKCU\Control Panel\Desktop"
        ok &= apply_registry(emit, TOOL_ID, sys_pol, "InactivityTimeoutSecs",
                             "REG_DWORD", TIMEOUT_SECS, "Machine inactivity lock timeout")
        run_cmd(["powershell", "-Command",
                 f"secedit /export /cfg C:\\Windows\\Temp\\sec.cfg /quiet; "
                 f"(Get-Content C:\\Windows\\Temp\\sec.cfg) -replace 'ScreenSaveTimeOut = .*',"
                 f"'ScreenSaveTimeOut = {TIMEOUT_SECS}' | Set-Content C:\\Windows\\Temp\\sec.cfg; "
                 f"secedit /configure /db C:\\Windows\\Temp\\sec.sdb /cfg C:\\Windows\\Temp\\sec.cfg /quiet"])
        ok &= apply_registry(emit, TOOL_ID, desk, "ScreenSaveActive", "REG_SZ", "1",
                             "Screen saver enabled")
        ok &= apply_registry(emit, TOOL_ID, desk, "ScreenSaverIsSecure", "REG_SZ", "1",
                             "Password required on resume")
        ok &= apply_registry(emit, TOOL_ID, desk, "ScreenSaveTimeOut", "REG_SZ", str(TIMEOUT_SECS),
                             f"Screen saver timeout {TIMEOUT_SECS//60}min")
        detail = f"Windows screen lock: {TIMEOUT_SECS//60}min (verified, reversible)"

    elif os_name == "Darwin":
        secs = TIMEOUT_SECS // 60
        run_cmd(sudo_prefix() + ["defaults", "write",
                 "com.apple.screensaver", "idleTime", str(TIMEOUT_SECS)])
        run_cmd(sudo_prefix() + ["defaults", "write",
                 "/Library/Preferences/com.apple.screensaver",
                 "idleTime", "-int", str(TIMEOUT_SECS)])
        run_cmd(sudo_prefix() + ["defaults", "write",
                 "com.apple.loginwindow", "SHOWFULLNAME", "-bool", "true"])
        emit(f"  OK  macOS screen saver: {secs}min + lock on wake", "ok")
        detail = f"macOS screen lock: {secs}min"

    else:
        # Fix #58: gsettings must run as the actual logged-in user, not root
        # Determine the real user: SUDO_USER if we escalated, else current user
        real_user = os.environ.get("SUDO_USER") or os.environ.get("USER", "")

        if not real_user or real_user == "root":
            emit("  WARN  Cannot determine actual user session — gsettings not applied", "warn")
            emit("  INFO  Run manually as your user:", "info")
            emit(f"  gsettings set org.gnome.desktop.session idle-delay {TIMEOUT_SECS}", "info")
            emit("  gsettings set org.gnome.desktop.screensaver lock-enabled true", "info")
        else:
            # Run gsettings as the real user via sudo -u
            prefix = ["sudo", "-u", real_user]
            run_cmd(prefix + ["gsettings", "set",
                               "org.gnome.desktop.session", "idle-delay",
                               str(TIMEOUT_SECS)])
            run_cmd(prefix + ["gsettings", "set",
                               "org.gnome.desktop.screensaver", "lock-enabled", "true"])
            run_cmd(prefix + ["gsettings", "set",
                               "org.gnome.desktop.screensaver", "lock-delay", "0"])
            emit(f"  OK  gsettings applied for user: {real_user}", "ok")

        # Also configure logind.conf for all users
        conf = Path("/etc/systemd/logind.conf")
        if conf.exists():
            from core.hardening import backup_file
            backup_file(TOOL_ID, conf, "logind.conf before screen-lock policy")
            content = conf.read_text()
            for k, v in [("IdleAction", "lock"), ("IdleActionSec", f"{TIMEOUT_SECS}s")]:
                if re.search(rf"^#?{k}=", content, re.M):
                    content = re.sub(rf"^#?{k}=.*", f"{k}={v}", content, flags=re.M)
                else:
                    content += f"\n{k}={v}\n"
            try:
                conf.write_text(content)
                pfx = sudo_prefix()
                run_cmd(pfx + ["systemctl", "restart", "systemd-logind"])
                emit(f"  OK  logind.conf: IdleActionSec={TIMEOUT_SECS}s (merge-write)", "ok")
            except PermissionError:
                emit("  WARN  Cannot write logind.conf — run as root", "warn")
        detail = f"Linux screen lock: {TIMEOUT_SECS//60}min ({real_user or 'root warning'})"

    emit("\n  NIST AC-11 complete.", "info")
    return ok, detail
