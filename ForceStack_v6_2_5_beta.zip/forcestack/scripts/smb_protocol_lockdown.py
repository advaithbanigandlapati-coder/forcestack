"""scripts/smb_protocol_lockdown.py — Legacy protocol lockdown. NIST CM-7, SC-8, AC-17.
Disables SMBv1, requires SMB signing, disables LLMNR. Reversible via apply_registry."""
TOOL_NAME = "Legacy Protocol Lockdown"
TOOL_ID   = "smb_protocol_lockdown"
from scripts._base import assert_tool_registered
assert_tool_registered(TOOL_ID)


def execute(emit, os_name):
    from core.hardening import apply_registry
    emit("  Locking down legacy protocols: SMBv1, LLMNR, SMB signing (NIST CM-7)...\n", "info")
    if os_name != "Windows":
        emit("  INFO  SMBv1/LLMNR are Windows features and are not enabled here.", "info")
        return True, f"not applicable on {os_name}"

    srv = r"HKLM\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters"
    wks = r"HKLM\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters"
    dns = r"HKLM\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient"
    ok = True
    ok &= apply_registry(emit, TOOL_ID, srv, "SMB1", "REG_DWORD", 0,
                         "Disable SMBv1 (EternalBlue/WannaCry vector)")
    ok &= apply_registry(emit, TOOL_ID, srv, "RequireSecuritySignature", "REG_DWORD", 1,
                         "Require SMB signing (server) — blocks relay")
    ok &= apply_registry(emit, TOOL_ID, wks, "RequireSecuritySignature", "REG_DWORD", 1,
                         "Require SMB signing (client)")
    ok &= apply_registry(emit, TOOL_ID, dns, "EnableMulticast", "REG_DWORD", 0,
                         "Disable LLMNR (credential-poisoning path)")
    emit("\n  Legacy protocol lockdown complete.", "info")
    return ok, "SMBv1 off, SMB signing required, LLMNR off (verified, reversible)"
