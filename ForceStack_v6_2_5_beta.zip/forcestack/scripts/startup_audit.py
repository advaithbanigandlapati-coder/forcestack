"""scripts/startup_audit.py — NIST CM-7, SI-3, CM-8.
Fix #59: full-name match not substring for systemd services. Fix #60: crontab in detail.
Fix #27: removesuffix(".service") replaces rstrip(".service") which stripped characters.
Fix #53: actionable guidance for flagged non-system services; failure paths no longer silent.
"""
TOOL_NAME = "Startup Items Auditor"
TOOL_ID   = "startup_audit"
from scripts._base import run_cmd, assert_tool_registered
from pathlib import Path
assert_tool_registered(TOOL_ID)

WIN_SAFE_PREFIXES = [
    "c:\\windows\\", "c:\\program files\\windows",
    "microsoft corporation", "windows security",
    "windows defender", "onedrive", "microsoft teams",
]

# Fix #59: exact service-name prefixes, not substrings
LINUX_SYSTEM_PREFIXES = (
    "systemd-", "dbus", "cron", "udev", "NetworkManager",
    "network", "sshd", "auditd", "rsyslog", "snapd",
    "apt-", "cups", "avahi-", "bluetooth", "polkit",
    "accounts-daemon", "ModemManager", "udisks2",
    "wpa_supplicant", "chronyd", "timesyncd",
)

_HOW_TO_INVESTIGATE = (
    "For each flagged item:\n"
    "  1. Search the service name online to confirm it is legitimate software you installed\n"
    "  2. Check when it was added: systemctl show <name> | grep -i fragment\n"
    "  3. If unknown: sudo systemctl disable <name> && sudo systemctl stop <name>\n"
    "  4. If it reappears after reboot, run a malware scanner (see AV/EDR check)"
)


def _is_system_service(name: str) -> bool:
    """Fix #59: check full service name prefix, not arbitrary substring."""
    n = name.lower().removesuffix(".service")  # fix #27
    return any(n.startswith(p.lower()) for p in LINUX_SYSTEM_PREFIXES)


def execute(emit, os_name):
    emit("  Auditing startup and persistence locations (NIST CM-7)...\n", "info")
    ok = True
    suspect = []

    if os_name == "Windows":
        keys = [
            r"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run",
            r"HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run",
            r"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce",
            r"HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce",
        ]
        any_key_read = False
        for key in keys:
            out, rc = run_cmd(["reg", "query", key])
            # Fix #53: detect reg query failure explicitly
            if out and "ERROR" not in out:
                any_key_read = True
                emit(f"\n  [{key}]", "info")
                for line in out.strip().splitlines():
                    line = line.strip()
                    if not line or line.startswith("HKEY"):
                        continue
                    emit(f"    {line}", "info")
                    if not any(p in line.lower() for p in WIN_SAFE_PREFIXES):
                        suspect.append(line[:60])
            elif "ERROR" in out:
                emit(f"  INFO  {key} — not found or access denied", "info")

        if not any_key_read:
            emit({
                "title": "Could not read Windows startup registry keys",
                "why": (
                    "Startup registry keys control which programs launch automatically when "
                    "Windows starts. Malware commonly hides here to survive reboots. If these "
                    "keys cannot be read, unauthorized persistence may go undetected."
                ),
                "fix": (
                    "Run ForceStack as Administrator:\n"
                    "  Right-click ForceStack → Run as Administrator\n"
                    "Or check manually: Win+R → regedit → navigate to\n"
                    r"  HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
                ),
                "raw": "reg query returned ERROR for all startup keys",
            }, "warn")

        emit("\n  Scheduled Tasks (non-\\Microsoft\\ path):", "info")
        out2, _ = run_cmd(["schtasks", "/query", "/fo", "LIST"])
        if not out2.strip():
            emit("  WARN  schtasks returned no output — run as Administrator for full results", "warn")
        else:
            cur_task = ""
            for line in out2.splitlines():
                if line.startswith("TaskName:"):
                    cur_task = line.split(":", 1)[-1].strip()
                elif line.startswith("Status:") and cur_task:
                    if not cur_task.lower().startswith("\\microsoft\\"):
                        emit(f"    {cur_task}", "warn")
                        suspect.append(cur_task[:50])
                    cur_task = ""
        detail = f"Registry+tasks; {len(suspect)} suspect"

    elif os_name == "Darwin":
        dirs = [
            Path.home() / "Library/LaunchAgents",
            Path("/Library/LaunchAgents"),
            Path("/Library/LaunchDaemons"),
        ]
        total = 0
        for d in dirs:
            if not d.exists():
                continue
            items = sorted(d.glob("*.plist"))
            emit(f"\n  {d}  ({len(items)} items)", "info")
            for p in items:
                is_apple = p.name.lower().startswith("com.apple")
                tag = " (Apple)" if is_apple else " ← review"
                emit(f"    {'OK' if is_apple else 'WARN'}  {p.name}{tag}",
                     "ok" if is_apple else "warn")
                if not is_apple:
                    suspect.append(p.name)
                total += 1
        detail = f"{total} launch items; {len(suspect)} non-Apple"

    else:
        out, _ = run_cmd(["systemctl", "list-units", "--type=service",
                          "--state=enabled", "--no-pager", "--plain"])
        # Fix #53: detect systemctl failure (no output = command unavailable or permission issue)
        if not out.strip():
            emit({
                "title": "Cannot list enabled systemd services",
                "why": (
                    "Enabled services run automatically at boot. Without being able to list "
                    "them, this audit cannot detect unauthorized persistence mechanisms — "
                    "such as malware configured to restart after reboot."
                ),
                "fix": (
                    "Run ForceStack with elevated privileges: sudo python3 main.py\n"
                    "Or check manually: systemctl list-units --type=service --state=enabled"
                ),
                "raw": "systemctl list-units returned no output",
            }, "warn")
            # Do not set ok=False — the service may just not be init-based; continue to crontab
        else:
            emit(
                "  Services marked WARN are enabled at boot but not recognized as standard\n"
                "  system services. This does NOT mean they are malware — most will be\n"
                "  legitimate software you have installed. Review each one.\n",
                "info",
            )
            for line in out.splitlines()[1:]:
                parts = line.split()
                if not parts:
                    continue
                name = parts[0]
                if not _is_system_service(name):
                    emit(f"  WARN  {name}  ← not a recognized system service", "warn")
                    suspect.append(name)
                else:
                    emit(f"  OK    {name}", "ok")

        # Fix #60: capture crontab output and include in detail
        cron_out, _ = run_cmd(["crontab", "-l"])
        cron_lines = [l for l in (cron_out or "").splitlines()
                      if l.strip() and not l.startswith("#")]
        emit(f"\n  Crontab entries: {len(cron_lines)}", "info")
        for l in cron_lines:
            emit(f"    {l}", "warn")
        detail = f"systemd: {len(suspect)} non-std; crontab: {len(cron_lines)} entries"

    # Fix #53: actionable guidance for everything flagged, not just "verify expected"
    if suspect:
        emit(f"\n  {len(suspect)} {'item' if len(suspect) == 1 else 'items'} need review:", "warn")
        for s in suspect[:10]:
            emit(f"    - {s}", "warn")
        emit("\n  How to investigate:", "info")
        for step in _HOW_TO_INVESTIGATE.split("\n"):
            emit(f"  {step}", "info")

    emit("\n  NIST CM-7/CM-8 startup audit complete.", "info")
    return ok, detail
