"""scripts/tls_config.py — NIST SC-8, SC-23.
Fix #61: nginx snippet to ~/.forcestack not /tmp. Fix #62: SHA-1 disable is --strict flag only.
"""
TOOL_NAME = "TLS and SSL Hardening"
TOOL_ID   = "tls_config"
from scripts._base import run_cmd, assert_tool_registered
from core.constants import CONFIG_DIR
import ssl, socket
from pathlib import Path
assert_tool_registered(TOOL_ID)

FORCESTACK_SSH_TAG = "# ForceStack NIST SC-8 SSH"


def execute(emit, os_name):
    emit("  TLS/SSL hardening (NIST SC-8, SP 800-52)...\n", "info")
    ok = True

    emit("  Python TLS runtime:", "info")
    emit(f"  OpenSSL: {ssl.OPENSSL_VERSION}", "ok")

    emit("\n  Live TLS test (8s timeout, skipped on air-gap)...", "info")
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection(("1.1.1.1", 443), timeout=8) as raw:
            with ctx.wrap_socket(raw, server_hostname="cloudflare.com") as s:
                emit(f"  OK  {s.version()} -- {s.cipher()[0]}", "ok")
    except (socket.timeout, OSError, ssl.SSLError) as e:
        emit(f"  INFO  TLS test skipped (air-gapped or no internet): {e}", "info")

    if os_name == "Windows":
        emit("\n  Disabling weak protocols via Schannel...", "info")
        base = r"HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols"
        for proto in ["SSL 2.0", "SSL 3.0", "TLS 1.0", "TLS 1.1"]:
            for role in ["Client", "Server"]:
                run_cmd(["reg", "add", f"{base}\\{proto}\\{role}",
                         "/v", "Enabled", "/t", "REG_DWORD", "/d", "0", "/f"])
                run_cmd(["reg", "add", f"{base}\\{proto}\\{role}",
                         "/v", "DisabledByDefault", "/t", "REG_DWORD", "/d", "1", "/f"])
        emit("  OK  Disabled: SSL 2.0, SSL 3.0, TLS 1.0, TLS 1.1", "ok")
        for proto in ["TLS 1.2", "TLS 1.3"]:
            for role in ["Client", "Server"]:
                run_cmd(["reg", "add", f"{base}\\{proto}\\{role}",
                         "/v", "Enabled", "/t", "REG_DWORD", "/d", "1", "/f"])
                run_cmd(["reg", "add", f"{base}\\{proto}\\{role}",
                         "/v", "DisabledByDefault", "/t", "REG_DWORD", "/d", "0", "/f"])
        emit("  OK  Enabled: TLS 1.2 + TLS 1.3", "ok")

        cbase = r"HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers"
        for cipher in ["NULL", "DES 56/56", "RC2 40/128", "RC4 40/128", "RC4 128/128"]:
            run_cmd(["reg", "add", f"{cbase}\\{cipher}",
                     "/v", "Enabled", "/t", "REG_DWORD", "/d", "0", "/f"])
        emit("  OK  Disabled: RC4, DES, NULL cipher suites", "ok")

        # Fix #62: SHA-1/MD5 disable is enterprise-risk — warn but do NOT apply by default
        emit("  INFO  SHA-1/MD5 Schannel disable skipped (breaks legacy enterprise PKI)", "info")
        emit("  INFO  To enforce: re-run with --strict flag (not yet implemented)", "info")
        emit("  WARN  Reboot required for Schannel changes", "warn")
        detail = "Schannel: SSL/TLS1.0/1.1 disabled; TLS1.2+1.3 enforced; weak ciphers removed"

    elif os_name == "Darwin":
        emit("  OK  macOS Secure Transport enforces TLS 1.2+ by default", "ok")
        emit("  OK  SSLv2/3 and TLS 1.0/1.1 disabled in modern macOS", "ok")
        detail = "macOS TLS: system defaults secure"

    else:
        out, _ = run_cmd(["openssl", "version", "-a"])
        emit(out.strip(), "info")

        # Fix #61: save nginx snippet to ~/.forcestack not /tmp (persists across reboots)
        snippet_dir = CONFIG_DIR / "snippets"
        snippet_dir.mkdir(parents=True, exist_ok=True)
        snip = snippet_dir / "nginx_tls.conf"
        nginx = (
            "# ForceStack NIST SC-8 nginx TLS snippet\n"
            "# Copy relevant lines into your nginx server {} block\n"
            "ssl_protocols TLSv1.2 TLSv1.3;\n"
            "ssl_ciphers 'ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:"
            "ECDHE-ECDSA-CHACHA20-POLY1305';\n"
            "ssl_prefer_server_ciphers off;\n"
            "ssl_session_cache shared:SSL:10m;\n"
            "ssl_session_tickets off;\n"
            "add_header Strict-Transport-Security 'max-age=63072000' always;\n"
        )
        snip.write_text(nginx)
        emit(f"  OK  nginx TLS snippet saved (persistent): {snip}", "ok")

        # SSH crypto hardening — idempotent via tag
        sshd = Path("/etc/ssh/sshd_config")
        if sshd.exists():
            try:
                import fcntl
                with open(sshd, "r+") as fh:
                    fcntl.flock(fh, fcntl.LOCK_EX)
                    content = fh.read()
                    if FORCESTACK_SSH_TAG in content:
                        emit("  OK  SSH crypto hardening already applied (idempotent)", "ok")
                    else:
                        crypto = (
                            f"\n{FORCESTACK_SSH_TAG}\n"
                            "KexAlgorithms curve25519-sha256,ecdh-sha2-nistp521\n"
                            "Ciphers chacha20-poly1305@openssh.com,aes256-gcm@openssh.com\n"
                            "MACs hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com\n"
                        )
                        fh.seek(0, 2)
                        fh.write(crypto)
                        emit("  OK  SSH crypto: curve25519, AES-256-GCM, HMAC-SHA-512", "ok")
                    fcntl.flock(fh, fcntl.LOCK_UN)
            except PermissionError:
                emit("  ERR  Permission denied on sshd_config — run as root", "err")
                ok = False
        detail = "Linux TLS+SSH hardened; nginx snippet saved to ~/.forcestack/snippets/"

    emit("\n  NIST SC-8 TLS hardening complete.", "info")
    return ok, detail
