"""scripts/usb_lockdown.py — NIST MP-7.
Fix #62: admin warning for USBSTOR.
Fix #19: reformatted to match project code style (no semicolon one-liners).

NOTE (Issue #17): macOS support is limited — the Darwin branch disables
Finder auto-open for removable disks only. USB drives still mount and are
accessible. Full USB blocking on macOS requires MDM (Jamf/Mosyle). This
limitation is honestly communicated in both the tool output and in tools.py.
"""

TOOL_NAME = "USB Lockdown"
TOOL_ID   = "usb_lockdown"

from scripts._base import run_cmd, reg_add, sudo_prefix, assert_tool_registered
from pathlib import Path

assert_tool_registered(TOOL_ID)


def execute(emit, os_name):
    emit("  USB lockdown (NIST MP-7)...\n", "info")
    ok = True

    if os_name == "Windows":
        # Idempotency: check current AutoRun value
        out, _ = run_cmd([
            "reg", "query",
            r"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer",
            "/v", "NoDriveTypeAutoRun",
        ])
        if "0xff" in out.lower() or "255" in out:
            emit("  OK  AutoRun already disabled", "ok")
        else:
            reg_add(
                r"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer",
                "NoDriveTypeAutoRun", "REG_DWORD", 255,
            )
            reg_add(
                r"HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer",
                "NoDriveTypeAutoRun", "REG_DWORD", 255,
            )
            emit("  OK  AutoRun disabled for all drive types", "ok")

        reg_add(
            r"HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\AutoplayHandlers",
            "DisableAutoplay", "REG_DWORD", 1,
        )
        emit("  OK  AutoPlay dialog disabled", "ok")

        # Fix #62: warn clearly before disabling USBSTOR for ALL users
        emit("  WARN  USBSTOR: disabling USB storage for ALL users including administrators.", "warn")
        emit("        Ensure you have alternative recovery media before proceeding.", "warn")
        reg_add(r"HKLM\SYSTEM\CurrentControlSet\Services\UsbStor", "Start", "REG_DWORD", 4)
        emit("  OK  USB storage class driver disabled (Start=4)", "ok")
        detail = "AutoRun+AutoPlay disabled; USBSTOR disabled (all users)"

    elif os_name == "Darwin":
        # Issue #17: this only disables Finder auto-open — full block requires MDM.
        run_cmd(["defaults", "write", "com.apple.frameworks.diskimages",
                 "auto-open-ro-root", "-bool", "false"])
        run_cmd(["defaults", "write", "com.apple.frameworks.diskimages",
                 "auto-open-rw-root", "-bool", "false"])
        run_cmd(["defaults", "write", "com.apple.finder",
                 "OpenWindowForNewRemovableDisk", "-bool", "false"])
        emit("  OK  Auto-open for removable disks disabled", "ok")
        emit("  WARN  Limitation: USB drives still mount and are accessible on macOS.", "warn")
        emit("        Full USB block requires MDM (Jamf/Mosyle). See tools.py description.", "warn")
        detail = "macOS Finder auto-open disabled (MDM required for full block)"

    else:
        rule = (
            'ACTION=="add",KERNEL=="sd[b-z]",SUBSYSTEM=="block",'
            'ATTR{removable}=="1",'
            'RUN+="/bin/sh -c \'echo 0 > /sys%p/device/../../../authorized\'"\n'
        )
        path = "/etc/udev/rules.d/99-forcestack-usb.rules"

        if Path(path).exists():
            emit("  OK  udev rule already installed", "ok")
            detail = "Already applied"
        else:
            try:
                with open(path, "w") as f:
                    f.write(rule)
                run_cmd(sudo_prefix() + ["udevadm", "control", "--reload"])
                emit(f"  OK  udev rule installed: {path}", "ok")
                detail = "udev USB block rule installed"
            except PermissionError:
                emit("  ERR  Permission denied — run as root", "err")
                ok = False
                detail = "Permission denied"
            except FileNotFoundError:
                # /etc/udev/rules.d absent (non-standard/minimal system or container)
                emit("  ERR  udev rules directory not found — install udev, then re-run", "err")
                ok = False
                detail = "udev not available"
            except OSError as e:
                emit(f"  ERR  Could not write udev rule: {e}", "err")
                ok = False
                detail = f"udev write failed: {e}"

    emit("\n  NIST MP-7 complete.", "info")
    return ok, detail
