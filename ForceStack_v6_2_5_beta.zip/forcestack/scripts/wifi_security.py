"""scripts/wifi_security.py — NIST SC-8, AC-18. Fix #35: assert_tool_registered added.
Fix #54: complete fix guidance for weak/WEP profiles including router and OS steps.
"""
TOOL_NAME = "Wi-Fi Security Audit"
TOOL_ID   = "wifi_security"
from scripts._base import run_cmd, assert_tool_registered
assert_tool_registered(TOOL_ID)
import re

WEAK = ["WEP", "WPA ", "Open", "None", "TKIP"]

_WEP_WHY = (
    "WEP (Wired Equivalent Privacy) was broken in 2001 and can be cracked in under "
    "60 seconds with freely available tools. Any attacker within Wi-Fi range can "
    "decrypt your traffic and join your network."
)
_WEAK_WHY = (
    "WPA (TKIP) and open networks do not provide adequate encryption. Traffic can be "
    "intercepted and decrypted. NIST requires WPA2-AES or WPA3 at minimum."
)
_FIX_ROUTER = (
    "Log in to your router admin page (usually http://192.168.1.1 or http://192.168.0.1)\n"
    "  → Wireless settings → Security mode\n"
    "  → Change to WPA2 (AES/CCMP) or WPA3\n"
    "  → Save and reconnect all devices with the new settings"
)
_FIX_WINDOWS_PROFILE = (
    "For saved Windows profiles using weak security:\n"
    "  → Open Settings → Network & Internet → Wi-Fi → Manage known networks\n"
    "  → Forget the weak network, then reconnect after fixing the router"
)
_FIX_LINUX_PROFILE = (
    "Remove the weak saved connection:\n"
    "  nmcli connection delete '<network name>'\n"
    "Then reconnect after fixing the router security settings."
)


def execute(emit, os_name):
    emit("  Wi-Fi security audit (NIST SC-8, AC-18)...\n", "info")
    ok = True
    issues = []

    if os_name == "Windows":
        out, _ = run_cmd(["netsh", "wlan", "show", "profiles"])
        profiles = re.findall(r"All User Profile\s*:\s*(.+)", out)
        emit(f"  {len(profiles)} saved profiles", "info")
        for prof in profiles:
            prof = prof.strip()
            out2, _ = run_cmd(["netsh", "wlan", "show", "profile",
                               f"name={prof}", "key=clear"])
            auth_m   = re.search(r"Authentication\s*:\s*(.+)", out2)
            cipher_m = re.search(r"Cipher\s*:\s*(.+)", out2)
            auth   = auth_m.group(1).strip()   if auth_m   else "Unknown"
            cipher = cipher_m.group(1).strip() if cipher_m else "Unknown"
            is_wep  = "WEP" in auth or "WEP" in cipher
            is_weak = any(w in auth or w in cipher for w in WEAK)
            if is_weak:
                emit({
                    "title": f"Weak Wi-Fi security on saved profile: {prof}",
                    "why": _WEP_WHY if is_wep else _WEAK_WHY,
                    "fix": _FIX_ROUTER + "\n" + _FIX_WINDOWS_PROFILE,
                    "raw": f"Profile '{prof}': Authentication={auth}, Cipher={cipher}",
                }, "warn")
                issues.append(f"{prof}: {auth}/{cipher}")
                ok = False
            else:
                emit(f"  OK  {prof:<35} {auth}/{cipher}", "ok")
        detail = f"{len(profiles)} profiles, {len(issues)} weak"

    elif os_name == "Darwin":
        airport = (
            "/System/Library/PrivateFrameworks/Apple80211.framework"
            "/Versions/Current/Resources/airport"
        )
        out, _ = run_cmd([airport, "-s"])
        emit(out or "  (no results)", "info")
        out2, _ = run_cmd([airport, "-I"])
        emit(out2, "info")
        if "WEP" in out or "WEP" in out2:
            emit({
                "title": "WEP network detected",
                "why": _WEP_WHY,
                "fix": _FIX_ROUTER,
                "raw": f"airport -s output:\n{out[:300]}",
            }, "warn")
            issues.append("WEP network detected")
            ok = False
        detail = "macOS airport scan"

    else:
        out, _ = run_cmd(["nmcli", "-f", "SSID,BSSID,SECURITY", "dev", "wifi", "list"])
        emit(out or "  (nmcli not available)", "info")
        for line in (out or "").splitlines()[1:]:
            if "--" in line or not line.strip():
                continue
            is_wep  = "WEP" in line
            is_weak = is_wep or any(w in line for w in ["none", "  --  "])
            if is_weak:
                emit({
                    "title": "Weak Wi-Fi security detected",
                    "why": _WEP_WHY if is_wep else _WEAK_WHY,
                    "fix": _FIX_ROUTER + "\n" + _FIX_LINUX_PROFILE,
                    "raw": f"nmcli line: {line.strip()[:120]}",
                }, "warn")
                issues.append(line.strip()[:50])
                ok = False
        detail = f"nmcli scan; {len(issues)} concerns"

    if not issues:
        emit("  OK  No weak wireless configurations detected", "ok")
    emit("\n  NIST SC-8 Wi-Fi audit complete.", "info")
    return ok, detail
