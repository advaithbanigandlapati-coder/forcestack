"""
tests/conftest.py — shared fixtures (fix #78: no more copy-pasted monkeypatch blocks)
"""
import pytest


@pytest.fixture
def audit_log(tmp_path, monkeypatch):
    """
    Provide a fresh AuditLog instance pointing at a temp directory.
    Fix #78: single canonical fixture used by all audit tests.
    """
    audit_file = tmp_path / "audit.json"
    monkeypatch.setattr("core.constants.AUDIT_FILE",     audit_file)
    monkeypatch.setattr("core.constants.AUDIT_KEY_FILE", tmp_path / "audit.key")
    monkeypatch.setattr("core.constants.CONFIG_DIR",     tmp_path)
    from importlib import reload
    import core.audit as a
    reload(a)
    log = a.AuditLog()
    yield log


@pytest.fixture
def patched_audit_module(tmp_path, monkeypatch):
    """
    Yield the reloaded core.audit module for tests that need module-level access.
    Fix: also patches CONFIG_DIR and AUDIT_KEY_FILE so no test can write to
    ~/.forcestack/ (matches the audit_log fixture pattern).
    """
    audit_file = tmp_path / "audit.json"
    monkeypatch.setattr("core.constants.AUDIT_FILE",     audit_file)
    monkeypatch.setattr("core.constants.AUDIT_KEY_FILE", tmp_path / "audit.key")
    monkeypatch.setattr("core.constants.CONFIG_DIR",     tmp_path)
    from importlib import reload
    import core.audit as a
    reload(a)
    yield a
