"""Accessibility plumbing: user scale multiplier and high-contrast config."""
import importlib
from core.constants import save_config, load_config_dict


def test_ui_scale_multiplies_scaled(monkeypatch):
    import ui.utils as uu
    monkeypatch.setattr(uu, "_DPI_SCALE", 1.0)
    monkeypatch.setattr(uu, "_USER_SCALE", 1.5)
    assert uu.scaled(20) == 30
    monkeypatch.setattr(uu, "_USER_SCALE", 1.0)
    assert uu.scaled(20) == 20


def test_accessibility_settings_round_trip():
    save_config({"high_contrast": True, "ui_scale": 1.25})
    cfg = load_config_dict()
    assert cfg["high_contrast"] is True and abs(cfg["ui_scale"] - 1.25) < 1e-9
    save_config({"high_contrast": False, "ui_scale": 1.0})   # reset


def test_high_contrast_overrides_text_palette(monkeypatch):
    save_config({"high_contrast": True})
    import core.constants as cc
    importlib.reload(cc)
    try:
        assert cc.C["t1"] == "#FFFFFF"        # brightened for readability
    finally:
        save_config({"high_contrast": False})
        importlib.reload(cc)
