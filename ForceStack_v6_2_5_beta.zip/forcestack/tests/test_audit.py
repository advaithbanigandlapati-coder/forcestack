"""Tests for core/audit.py — uses shared fixtures from conftest.py (fix #78)."""
import json
import threading


def test_record_and_stats(audit_log):
    audit_log.record("firewall_config", "Configure Firewall", "success", "OK", 1.5)
    audit_log.record("open_ports",      "Open Ports",          "error",   "flagged", 0.8)
    st = audit_log.stats()
    assert st["total"]   == 2
    assert st["success"] == 1
    assert st["errors"]  == 1


def test_last_run_o1(audit_log):
    audit_log.record("screen_lock", "Screen Lock", "success", "done", 0.5)
    e = audit_log.last_run("screen_lock")
    assert e is not None
    assert e["status"] == "success"
    assert audit_log.last_run("nonexistent") is None


def test_schema_migration(tmp_path, monkeypatch):
    """v1 bare-list format loads correctly."""
    af = tmp_path / "audit.json"
    af.write_text(json.dumps([
        {"tool_id": "x", "tool_name": "X", "status": "success",
         "timestamp": "2024-01-01T00:00:00", "nist": []}
    ]))
    monkeypatch.setattr("core.constants.AUDIT_FILE", af)
    from importlib import reload
    import core.audit as a; reload(a)
    log = a.AuditLog()
    assert len(log.entries) == 1


def test_max_entries_cap(patched_audit_module):
    """Fix #72: use monkeypatch.setattr, not direct assignment."""
    a   = patched_audit_module
    log = a.AuditLog()
    # monkeypatch is used in the fixture; here we directly patch via setattr on the module
    original = a.MAX_ENTRIES
    a.MAX_ENTRIES = 5
    try:
        for i in range(10):
            log.record(f"tool_{i}", f"Tool {i}", "success", "", 0.01)
        # Fix #16: tightened from <= 6 to == 5 so a broken cap that allows 6 entries fails.
        assert len(log.entries) == 5
    finally:
        a.MAX_ENTRIES = original


def test_thread_safety(audit_log):
    errors = []
    def worker(i):
        try:
            audit_log.record(f"tool_{i}", f"T{i}", "success", "", 0.01)
        except Exception as e:
            errors.append(e)
    threads = [threading.Thread(target=worker, args=(i,)) for i in range(20)]
    for t in threads: t.start()
    for t in threads: t.join()
    assert not errors


def test_compliance_score(audit_log):
    audit_log.record("firewall_config", "Firewall", "success", "", 0.1)
    audit_log.record("screen_lock",     "Lock",     "error",   "", 0.1)
    score = audit_log.compliance_score(total_tools=2)
    assert score == 50


def test_export_csv_nist_guard(audit_log, tmp_path):
    """Fix #12: nist field as string should not explode csv export."""
    # Inject a v1-migrated entry with nist as string
    audit_log.entries.insert(0, {
        "timestamp": "2024-01-01T00:00:00", "tool_id": "x",
        "tool_name": "X", "status": "success", "detail": "",
        "duration_s": 0.0, "nist": "AC-7",  # string, not list
        "os": "Linux", "hostname": "host", "user": "u", "app_ver": "3",
    })
    out = tmp_path / "export.csv"
    audit_log.export_csv(str(out))
    content = out.read_text()
    assert "AC-7" in content   # preserved, not exploded as "A, C, -, 7"
    assert "A, C" not in content


def test_get_entries_filter(audit_log):
    """Fix #16: filtering API."""
    audit_log.record("firewall_config", "Firewall", "success", "", 0.1)
    audit_log.record("screen_lock",     "Lock",     "error",   "", 0.1)
    audit_log.record("screen_lock",     "Lock",     "success", "", 0.1)
    succ = audit_log.get_entries(tool_id="screen_lock", status="success")
    assert len(succ) == 1
    all_sl = audit_log.get_entries(tool_id="screen_lock")
    assert len(all_sl) == 2


def test_snapshot_entries_is_copy(audit_log):
    """Fix #15: snapshot returns independent copy."""
    audit_log.record("firewall_config", "Firewall", "success", "", 0.1)
    snap = audit_log.snapshot_entries()
    snap.clear()  # mutating the copy
    assert len(audit_log.entries) == 1   # original unaffected


def test_schema_missing_field_graceful(tmp_path, monkeypatch):
    """Fix #77: v2 entry missing 'hostname' field doesn't crash on load."""
    af = tmp_path / "audit.json"
    af.write_text(json.dumps({
        "schema": 2,
        "entries": [{"tool_id": "x", "tool_name": "X", "status": "success",
                     "timestamp": "2024-01-01T00:00:00", "nist": []}]
    }))
    monkeypatch.setattr("core.constants.AUDIT_FILE", af)
    monkeypatch.setattr("core.constants.AUDIT_KEY_FILE", tmp_path / "audit.key")
    from importlib import reload
    import core.audit as a; reload(a)
    log = a.AuditLog()
    assert len(log.entries) == 1
    e = log.entries[0]
    # Missing fields default gracefully via .get()
    assert e.get("hostname", "<missing>") == "<missing>"  # not KeyError


# ── HMAC tests ────────────────────────────────────────────────────────────────

def test_record_adds_hmac(audit_log):
    """Every recorded entry must carry a non-empty 'hmac' field."""
    entry = audit_log.record("firewall_config", "Firewall", "success", "ok", 0.5)
    assert "hmac" in entry
    assert len(entry["hmac"]) == 64  # SHA-256 hex digest


def test_hmac_is_valid_on_reload(tmp_path, monkeypatch):
    """Entries saved to disk must pass HMAC verification when reloaded."""
    af  = tmp_path / "audit.json"
    kf  = tmp_path / "audit.key"
    monkeypatch.setattr("core.constants.AUDIT_FILE",     af)
    monkeypatch.setattr("core.constants.AUDIT_KEY_FILE", kf)
    monkeypatch.setattr("core.constants.CONFIG_DIR",     tmp_path)
    from importlib import reload
    import core.audit as a; reload(a)

    log1 = a.AuditLog()
    log1.record("screen_lock", "Screen Lock", "success", "done", 0.3)

    # Reload a second instance from the same file — should verify cleanly.
    log2 = a.AuditLog()
    assert len(log2.entries) == 1
    assert log2.entries[0].get("_tampered") is None


def test_tampered_entry_flagged_on_load(tmp_path, monkeypatch):
    """An entry whose field is edited after saving must be flagged as tampered."""
    af  = tmp_path / "audit.json"
    kf  = tmp_path / "audit.key"
    monkeypatch.setattr("core.constants.AUDIT_FILE",     af)
    monkeypatch.setattr("core.constants.AUDIT_KEY_FILE", kf)
    monkeypatch.setattr("core.constants.CONFIG_DIR",     tmp_path)
    from importlib import reload
    import core.audit as a; reload(a)

    log = a.AuditLog()
    log.record("open_ports", "Open Ports", "success", "clean", 0.1)

    # Directly corrupt the saved file — flip status from "success" to "error".
    raw = json.loads(af.read_text())
    raw["entries"][0]["status"] = "error"          # tamper
    af.write_text(json.dumps(raw))

    log2 = a.AuditLog()
    assert log2.entries[0].get("_tampered") is True


def test_injected_entry_flagged_on_load(tmp_path, monkeypatch):
    """An entry added to the file without a valid HMAC must be flagged."""
    af  = tmp_path / "audit.json"
    kf  = tmp_path / "audit.key"
    monkeypatch.setattr("core.constants.AUDIT_FILE",     af)
    monkeypatch.setattr("core.constants.AUDIT_KEY_FILE", kf)
    monkeypatch.setattr("core.constants.CONFIG_DIR",     tmp_path)
    from importlib import reload
    import core.audit as a; reload(a)

    log = a.AuditLog()
    log.record("screen_lock", "Screen Lock", "success", "ok", 0.1)

    # Inject a fake entry (no valid HMAC) directly into the persisted file.
    raw = json.loads(af.read_text())
    fake_entry = {
        "schema_ver": 3, "timestamp": "2020-01-01T00:00:00",
        "tool_id": "malicious", "tool_name": "Evil", "status": "success",
        "detail": "backdoor", "duration_s": 0.0, "nist": [],
        "os": "Linux", "hostname": "attacker", "user": "root", "app_ver": "3.4.0",
        "hmac": "0" * 64,   # wrong digest
    }
    raw["entries"].insert(0, fake_entry)
    af.write_text(json.dumps(raw))

    log2 = a.AuditLog()
    tampered = [e for e in log2.entries if e.get("_tampered")]
    assert len(tampered) >= 1


def test_verify_integrity_clean(audit_log):
    """verify_integrity() reports all-ok when nothing has been tampered."""
    audit_log.record("firewall_config", "Firewall", "success", "ok", 0.2)
    audit_log.record("screen_lock",     "Lock",     "success", "ok", 0.1)
    result = audit_log.verify_integrity()
    assert result["total"]        == 2
    assert result["ok"]           == 2
    assert result["tampered"]     == 0
    assert result["unsigned"]     == 0
    assert result["file_hmac_ok"] is True


def test_verify_integrity_detects_tamper(tmp_path, monkeypatch):
    """verify_integrity() must report tampered > 0 after a field is edited."""
    af  = tmp_path / "audit.json"
    kf  = tmp_path / "audit.key"
    monkeypatch.setattr("core.constants.AUDIT_FILE",     af)
    monkeypatch.setattr("core.constants.AUDIT_KEY_FILE", kf)
    monkeypatch.setattr("core.constants.CONFIG_DIR",     tmp_path)
    from importlib import reload
    import core.audit as a; reload(a)

    log = a.AuditLog()
    log.record("cve_scan", "CVE Scan", "success", "clean", 1.0)

    # Corrupt a field in the persisted file.
    raw = json.loads(af.read_text())
    raw["entries"][0]["detail"] = "pwned"
    af.write_text(json.dumps(raw))

    log2 = a.AuditLog()
    result = log2.verify_integrity()
    assert result["tampered"] >= 1


def test_schema_v1_migration_signs_entries(tmp_path, monkeypatch):
    """v1 (bare-list) entries are back-signed and re-saved as schema v3."""
    af  = tmp_path / "audit.json"
    kf  = tmp_path / "audit.key"
    monkeypatch.setattr("core.constants.AUDIT_FILE",     af)
    monkeypatch.setattr("core.constants.AUDIT_KEY_FILE", kf)
    monkeypatch.setattr("core.constants.CONFIG_DIR",     tmp_path)
    af.write_text(json.dumps([
        {"tool_id": "x", "tool_name": "X", "status": "success",
         "timestamp": "2024-01-01T00:00:00", "nist": []}
    ]))
    from importlib import reload
    import core.audit as a; reload(a)

    log = a.AuditLog()
    assert len(log.entries) == 1
    # Back-signed entry must pass clean verification.
    assert log.entries[0].get("_tampered") is None
    result = log.verify_integrity()
    assert result["ok"] == 1
    assert result["file_hmac_ok"] is True


def test_schema_v2_migration_signs_entries(tmp_path, monkeypatch):
    """v2 entries are back-signed and re-saved as schema v3."""
    af  = tmp_path / "audit.json"
    kf  = tmp_path / "audit.key"
    monkeypatch.setattr("core.constants.AUDIT_FILE",     af)
    monkeypatch.setattr("core.constants.AUDIT_KEY_FILE", kf)
    monkeypatch.setattr("core.constants.CONFIG_DIR",     tmp_path)
    af.write_text(json.dumps({
        "schema": 2,
        "entries": [
            {"tool_id": "firewall_config", "tool_name": "Firewall", "status": "success",
             "timestamp": "2024-06-01T12:00:00", "nist": ["SC-7"]},
        ]
    }))
    from importlib import reload
    import core.audit as a; reload(a)

    log = a.AuditLog()
    assert len(log.entries) == 1
    assert log.entries[0].get("_tampered") is None
    result = log.verify_integrity()
    assert result["ok"] == 1
    assert result["file_hmac_ok"] is True


def test_key_persisted_and_reused(tmp_path, monkeypatch):
    """The HMAC key is written to disk on first run and reused on subsequent loads."""
    af  = tmp_path / "audit.json"
    kf  = tmp_path / "audit.key"
    monkeypatch.setattr("core.constants.AUDIT_FILE",     af)
    monkeypatch.setattr("core.constants.AUDIT_KEY_FILE", kf)
    monkeypatch.setattr("core.constants.CONFIG_DIR",     tmp_path)
    from importlib import reload
    import core.audit as a; reload(a)

    log1 = a.AuditLog()
    key1 = log1._key
    assert kf.exists()

    log2 = a.AuditLog()
    assert log2._key == key1   # same key on second instantiation


def test_key_file_permissions(tmp_path, monkeypatch):
    """The key file must be created with 0o600 permissions."""
    import stat
    af  = tmp_path / "audit.json"
    kf  = tmp_path / "audit.key"
    monkeypatch.setattr("core.constants.AUDIT_FILE",     af)
    monkeypatch.setattr("core.constants.AUDIT_KEY_FILE", kf)
    monkeypatch.setattr("core.constants.CONFIG_DIR",     tmp_path)
    from importlib import reload
    import core.audit as a; reload(a)

    a.AuditLog()
    mode = stat.S_IMODE(kf.stat().st_mode)
    assert mode == 0o600, f"expected 0o600, got {oct(mode)}"

