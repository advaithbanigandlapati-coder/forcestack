"""Event-driven telemetry: eBPF collector integration + fail-safe fallback.

The real kernel eBPF program needs clang/libbpf/BTF/CAP_BPF on a real host and
can't run in CI, so we verify the full userland integration (spawn, JSON parse,
delivery, self-verification, fallback) with a simulated collector that emits the
same JSON contract the C loader does."""
import stat
import time
import textwrap
from core.eventsource import ProcessEventSource, capabilities


def _make_collector(tmp_path, body):
    p = tmp_path / "collector.py"
    p.write_text("#!/usr/bin/env python3\n" + textwrap.dedent(body))
    p.chmod(p.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
    return str(p)


def test_capabilities_shape():
    c = capabilities()
    for k in ("os", "ebpf_collector", "is_privileged", "note"):
        assert k in c


def test_ebpf_collector_integration(tmp_path, monkeypatch):
    col = _make_collector(tmp_path, """
        import sys, time, json
        for i in range(200):
            print(json.dumps({"type":"exec","pid":1000+i,"ppid":1,"comm":"t"}), flush=True)
            time.sleep(0.02)
    """)
    monkeypatch.setenv("FORCESTACK_EBPF_COLLECTOR", col)
    assert capabilities()["ebpf_collector"] is True
    src = ProcessEventSource()
    got = []
    assert src.start(got.append) is True
    time.sleep(0.6)
    src.stop()
    assert src.kind == "ebpf"
    assert src.active and src.events_received > 0        # self-verified by real events
    assert got[0]["type"] == "exec" and got[0]["pid"] == 1000


def test_ebpf_dead_collector_falls_back(tmp_path, monkeypatch):
    col = _make_collector(tmp_path, """
        import sys
        sys.stderr.write("failed to load BPF object (need root/CAP_BPF, BTF)\\n")
        sys.exit(1)
    """)
    monkeypatch.setenv("FORCESTACK_EBPF_COLLECTOR", col)
    src = ProcessEventSource()
    src.start(lambda e: None)
    src.stop()
    assert src.kind != "ebpf"        # dead collector → fail-safe fallback


def test_no_collector_configured_falls_back(monkeypatch):
    monkeypatch.delenv("FORCESTACK_EBPF_COLLECTOR", raising=False)
    src = ProcessEventSource()
    # _find_ebpf_collector may still find one on PATH; only assert it doesn't crash
    src.start(lambda e: None)
    src.stop()
    assert isinstance(src.kind, str)
