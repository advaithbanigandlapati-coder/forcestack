"""Tests for the enterprise apply/verify/rollback layer (file + journal paths)."""
from pathlib import Path
import pytest
from core import hardening as h


@pytest.fixture
def store(tmp_path, monkeypatch):
    """Redirect the rollback journal and snapshot dir into a temp area."""
    monkeypatch.setattr(h, "ROLLBACK_FILE", tmp_path / "rollback.json")
    monkeypatch.setattr(h, "SNAPSHOT_DIR", tmp_path / "snapshots")
    monkeypatch.setattr(h, "CONFIG_DIR", tmp_path)
    return tmp_path


def test_backup_and_revert_existing_file(store):
    target = store / "conf.txt"
    target.write_text("ORIGINAL")
    backup = h.backup_file("demo_tool", target, "before edit")
    assert backup and Path(backup).exists()
    target.write_text("MODIFIED")                       # simulate a hardening edit
    recs = h.list_rollbacks(tool_id="demo_tool")
    assert len(recs) == 1
    ok, _ = h.revert(recs[0]["id"])
    assert ok
    assert target.read_text() == "ORIGINAL"             # restored precisely


def test_revert_of_absent_file_deletes_it(store):
    target = store / "created.txt"
    h.backup_file("demo_tool", target, "file did not exist")
    target.write_text("new content created by hardening")
    ok, _ = h.revert_last("demo_tool")
    assert ok
    assert not target.exists()                          # rolled back to 'absent'


def test_list_excludes_reverted_and_filters_by_tool(store):
    a = store / "a.txt"; a.write_text("A")
    b = store / "b.txt"; b.write_text("B")
    h.backup_file("tool_a", a)
    h.backup_file("tool_b", b)
    assert len(h.list_rollbacks()) == 2
    assert len(h.list_rollbacks(tool_id="tool_a")) == 1
    h.revert_last("tool_a")
    assert h.list_rollbacks(tool_id="tool_a") == []      # reverted hidden by default
    assert len(h.list_rollbacks(tool_id="tool_a", include_reverted=True)) == 1


def test_journal_is_newest_first(store):
    f = store / "x.txt"; f.write_text("x")
    h.backup_file("t", f, "first")
    f.write_text("y")
    h.backup_file("t", f, "second")
    recs = h.list_rollbacks(tool_id="t")
    assert recs[0]["detail"] == "second"


def test_dword_normalization():
    assert h._normalize_dword("0x1") == h._normalize_dword("1")
    assert h._normalize_dword("0xff") == "255"


def test_revert_missing_record():
    ok, msg = h.revert("does-not-exist")
    assert not ok and "not found" in msg


def test_command_undo_revert(store, monkeypatch):
    """A command-reversible change runs its stored undo argv on revert."""
    calls = []
    monkeypatch.setattr(h, "run_cmd", lambda argv, **k: (calls.append(argv) or ("ok", True)))
    rec = h.record_undo("firewall_config", ["ufw", "disable"], "Disable UFW (was inactive)")
    assert rec["kind"] == h.KIND_COMMAND
    ok, _ = h.revert(rec["id"])
    assert ok and calls and calls[0] == ["ufw", "disable"]
    # reverting again is a no-op (already reverted)
    ok2, msg2 = h.revert(rec["id"])
    assert ok2 and "already" in msg2
