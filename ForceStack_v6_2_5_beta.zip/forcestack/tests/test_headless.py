"""
tests/test_headless.py — Fix #76: integration test for headless --dry-run mode.
"""
import subprocess
import sys
from pathlib import Path

MAIN = Path(__file__).parent.parent / "main.py"


def test_headless_list_tools():
    """--list-tools prints tool IDs and exits 0."""
    result = subprocess.run(
        [sys.executable, str(MAIN), "--list-tools"],
        capture_output=True, text=True, timeout=30,
    )
    assert result.returncode == 0, f"stderr: {result.stderr[:500]}"
    assert "firewall_config" in result.stdout
    assert "ID" in result.stdout


def test_headless_single_tool_dry_run():
    """--headless --dry-run --tool <id> exits 0 without system changes."""
    result = subprocess.run(
        [sys.executable, str(MAIN), "--headless", "--dry-run", "--tool", "screen_lock"],
        capture_output=True, text=True, timeout=60,
    )
    assert result.returncode == 0, \
        f"stdout: {result.stdout[:500]}\nstderr: {result.stderr[:500]}"
    assert "PASS" in result.stdout or "dry" in result.stdout.lower()


def test_headless_all_dry_run():
    """--headless --dry-run runs all tools and exits 0."""
    result = subprocess.run(
        [sys.executable, str(MAIN), "--headless", "--dry-run"],
        capture_output=True, text=True, timeout=120,
    )
    assert result.returncode == 0, \
        f"stdout: {result.stdout[:1000]}\nstderr: {result.stderr[:500]}"
    assert "COMPLETE" in result.stdout


def test_headless_unknown_tool_exits_1():
    """--headless --tool nonexistent exits 1 with error message."""
    result = subprocess.run(
        [sys.executable, str(MAIN), "--headless", "--tool", "does_not_exist_xyz"],
        capture_output=True, text=True, timeout=30,
    )
    assert result.returncode == 1
    assert "Unknown tool" in result.stdout or "Unknown tool" in result.stderr
