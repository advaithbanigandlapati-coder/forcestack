"""Tests for the enterprise hybrid post-quantum encryption engine (v2)."""
import os
import tempfile
import pytest
from core import pqcrypto as p

caps = p.crypto_capabilities()
pytestmark = pytest.mark.filterwarnings("ignore")


def _tmp(data=b""):
    path = tempfile.mktemp()
    with open(path, "wb") as f:
        f.write(data)
    return path


def test_sha256_and_fingerprint():
    assert p.sha256_hex(b"") == "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    assert len(p.fingerprint(b"abc").replace(" ", "")) == 32


def test_capabilities_shape():
    for k in ("aes_gcm", "ml_kem_768", "sha256", "quantum_safe",
              "pqc_backend", "pqc_production_grade", "password_kdf"):
        assert k in caps


@pytest.mark.skipif(not caps["aes_gcm"], reason="cryptography not installed")
def test_password_roundtrip_and_kdf_recorded():
    blob = p.encrypt_with_password(b"secret data", "pw123")
    assert p.decrypt_with_password(blob, "pw123") == b"secret data"
    _, header, _, _ = p._unpack(blob)
    assert header["params"]["kdf"] in ("argon2id", "scrypt")


@pytest.mark.skipif(not caps["aes_gcm"], reason="cryptography not installed")
def test_wrong_password_rejected():
    blob = p.encrypt_with_password(b"secret", "right")
    with pytest.raises(ValueError):
        p.decrypt_with_password(blob, "wrong")


@pytest.mark.skipif(not caps["aes_gcm"], reason="cryptography not installed")
def test_ciphertext_tamper_detected():
    blob = bytearray(p.encrypt_with_password(b"secret", "pw"))
    blob[-1] ^= 0xFF
    with pytest.raises(ValueError):
        p.decrypt_with_password(bytes(blob), "pw")


@pytest.mark.skipif(not caps["aes_gcm"], reason="cryptography not installed")
def test_header_tamper_detected():
    """The whole header is bound as AAD, so editing any param must fail."""
    blob = bytearray(p.encrypt_with_password(b"secret", "pw"))
    blob[12] ^= 0x01  # flip a byte inside the header region
    with pytest.raises(Exception):
        p.decrypt_with_password(bytes(blob), "pw")


@pytest.mark.skipif(not caps["aes_gcm"], reason="cryptography not installed")
def test_no_plaintext_hash_in_container():
    """Regression: the plaintext SHA-256 must never be stored in the header."""
    blob = p.encrypt_with_password(b"unique-marker-plaintext", "pw")
    _, header, _, _ = p._unpack(blob)
    assert "sha256" not in header


@pytest.mark.skipif(not caps["quantum_safe"], reason="no PQC backend")
def test_hybrid_roundtrip():
    kp = p.generate_keypair()
    enc = p.encrypt_to_public(b"quantum safe", kp.public_bundle())
    assert p.decrypt_with_private(enc, kp.private_bundle()) == b"quantum safe"


@pytest.mark.skipif(not caps["quantum_safe"], reason="no PQC backend")
def test_hybrid_wrong_key_rejected():
    kp1, kp2 = p.generate_keypair(), p.generate_keypair()
    enc = p.encrypt_to_public(b"data", kp1.public_bundle())
    with pytest.raises(ValueError):
        p.decrypt_with_private(enc, kp2.private_bundle())


@pytest.mark.skipif(not caps["aes_gcm"], reason="cryptography not installed")
@pytest.mark.parametrize("size", [0, 100, (1 << 20) + 7, (1 << 20) * 3])
def test_streaming_password_roundtrip(size):
    src, enc, dec = _tmp(os.urandom(size)), tempfile.mktemp(), tempfile.mktemp()
    data = open(src, "rb").read()
    p.encrypt_file_with_password(src, enc, "filepw")
    p.decrypt_file_with_password(enc, dec, "filepw")
    assert open(dec, "rb").read() == data


@pytest.mark.skipif(not caps["quantum_safe"], reason="no PQC backend")
@pytest.mark.parametrize("size", [0, 100, (1 << 20) * 2])
def test_streaming_hybrid_roundtrip(size):
    kp = p.generate_keypair()
    src, enc, dec = _tmp(os.urandom(size)), tempfile.mktemp(), tempfile.mktemp()
    data = open(src, "rb").read()
    p.encrypt_file_to_public(src, enc, kp.public_bundle())
    p.decrypt_file_with_private(enc, dec, kp.private_bundle())
    assert open(dec, "rb").read() == data


@pytest.mark.skipif(not caps["aes_gcm"], reason="cryptography not installed")
def test_streaming_truncation_detected():
    src, enc, dec = _tmp(os.urandom((1 << 20) * 2)), tempfile.mktemp(), tempfile.mktemp()
    p.encrypt_file_with_password(src, enc, "pw")
    raw = open(enc, "rb").read()
    with open(enc, "wb") as f:
        f.write(raw[: len(raw) // 2])  # chop off the end-of-stream marker
    with pytest.raises(ValueError):
        p.decrypt_file_with_password(enc, dec, "pw")


@pytest.mark.skipif(not caps["aes_gcm"], reason="cryptography not installed")
def test_armor_roundtrip():
    blob = p.encrypt_with_password(b"x", "y")
    assert p.dearmor(p.armor(blob)) == blob


def test_bad_container_rejected():
    with pytest.raises(ValueError):
        p._unpack(b"not a real container long enough")


def test_version_byte_is_v2():
    if not caps["aes_gcm"]:
        pytest.skip("cryptography not installed")
    blob = p.encrypt_with_password(b"x", "y")
    assert blob[4] == p.FORMAT_VERSION == 2


@pytest.mark.skipif(not caps["quantum_safe"], reason="no PQC backend")
def test_private_key_wrap_unwrap():
    kp = p.generate_keypair()
    priv = kp.private_bundle()
    wrapped = p.wrap_private_bundle(priv, "passphrase123")
    assert p.is_wrapped_private(wrapped) and not p.is_wrapped_private(priv)
    assert p.unwrap_private_bundle(wrapped, "passphrase123") == priv
    with pytest.raises(ValueError):
        p.unwrap_private_bundle(wrapped, "wrong")


@pytest.mark.skipif(not caps["quantum_safe"], reason="no PQC backend")
def test_decrypt_with_wrapped_key_requires_passphrase():
    kp = p.generate_keypair()
    wrapped = p.wrap_private_bundle(kp.private_bundle(), "pw")
    enc = p.encrypt_to_public(b"secret", kp.public_bundle())
    assert p.decrypt_with_private(enc, wrapped, passphrase="pw") == b"secret"
    with pytest.raises(ValueError):
        p.decrypt_with_private(enc, wrapped)          # no passphrase → refused
