"""Tests for the Sentinel Probe: ML anomaly model, beaconing fix, rollback."""
import time
import random
import pytest
import psutil
from core import probe as P
from core.probe import (
    ProbeEngine, AnomalyModel, Detection, severity_band,
    SEV_LOW, SEV_MED, SEV_HIGH, FEATURES,
)


# ── severity + plumbing ─────────────────────────────────────────────────────
def test_severity_bands():
    assert severity_band(10) == "info"
    assert severity_band(50) == "low"
    assert severity_band(65) == "medium"
    assert severity_band(97) == "critical"


def test_noise_floor_suppresses_low():
    eng = ProbeEngine()
    got = []
    eng.subscribe(got.append)
    eng._emit(Detection(ts=time.time(), module="m", score=SEV_LOW - 5, title="quiet", why="w"))
    assert got == []


def test_ai_triage_off_by_default_then_pluggable():
    eng = ProbeEngine()
    assert eng.ai_enabled is False
    eng.set_ai_analyzer(lambda s: {"malicious": True, "confidence": 0.9, "reason": "x"})
    assert eng.ai_enabled is True
    got = []
    eng.subscribe(got.append)
    eng._emit(Detection(ts=time.time(), module="m", score=SEV_MED, title="t", why="w"))
    assert got and got[0].verdict_source == "ai" and got[0].score >= SEV_HIGH


def test_autonomous_off_by_default():
    assert ProbeEngine().autonomous is False


# ── the AI: anomaly model ────────────────────────────────────────────────────
@pytest.fixture
def isolated_model(tmp_path, monkeypatch):
    monkeypatch.setattr(P, "_MODEL_FILE", tmp_path / "baseline.json")
    return None


def _normal_vec():
    # a plausible "quiet desktop" vector with small noise
    base = [180, 1, 8, 4, 0, 0, 0.5, 0, 0.25, 3.0, 0]
    return [b + random.uniform(-0.5, 0.5) for b in base]


@pytest.mark.parametrize("force_stat", [False, True])
def test_anomaly_model_learns_normal_and_flags_outlier(tmp_path, monkeypatch, force_stat):
    monkeypatch.setattr(P, "_MODEL_FILE", tmp_path / f"b{force_stat}.json")
    if force_stat:
        monkeypatch.setattr(P, "_HAS_SKLEARN", False)
    random.seed(1)
    m = AnomalyModel(warmup=8, refit_every=10)
    for _ in range(30):
        v = _normal_vec()
        a, _ = m.score(v)
        m.observe(v, a)
    assert m.ready
    normal_anom, _ = m.score(_normal_vec())
    # a clear behavioural spike: many new procs, C2 ports, fileless tells, beacons
    spike = [180, 40, 120, 60, 8, 5, 400, 6, 10, 6.5, 4]
    spike_anom, top = m.score(spike)
    assert spike_anom > normal_anom
    assert spike_anom >= 0.7            # crosses the real alert threshold
    assert normal_anom <= 0.5
    assert top and top[0]["feature"] in FEATURES     # explainable


def test_anomaly_model_persists_baseline(tmp_path, monkeypatch):
    path = tmp_path / "persist.json"
    monkeypatch.setattr(P, "_MODEL_FILE", path)
    random.seed(2)
    m = AnomalyModel(warmup=8, refit_every=5)
    for _ in range(20):
        v = _normal_vec(); m.observe(v, 0.0)
    assert path.exists()
    m2 = AnomalyModel(warmup=8)          # reloads from disk in __init__
    assert m2.ready


def test_model_does_not_learn_flagged_anomalies():
    m = AnomalyModel(warmup=4)
    for _ in range(6):
        m.observe([1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0], 0.0)
    before = len(m._baseline)
    m.observe([9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9], 0.95)   # looks malicious
    assert len(m._baseline) == before                     # not folded into normal


# ── beaconing false-positive fix ─────────────────────────────────────────────
def test_beacon_regular_reconnects_flagged():
    eng = ProbeEngine()
    eng._pid_names[42] = "sneaky"
    t0 = time.time()
    eng._conn_events[(42, "9.9.9.9")].extend([t0 + i * 10 for i in range(6)])  # every 10s
    dets = P.AgenticThreatModule().scan(P.Snapshot(t0, [], set(), []), eng)
    assert any(d.module == "AgenticThreat" and d.pid == 42 for d in dets)


def test_beacon_single_longlived_connection_not_flagged():
    eng = ProbeEngine()
    eng._pid_names[42] = "ssh"
    eng._conn_events[(42, "9.9.9.9")].append(time.time())   # one establishment only
    dets = P.AgenticThreatModule().scan(P.Snapshot(time.time(), [], set(), []), eng)
    assert not any(d.pid == 42 for d in dets)


def test_persistent_connection_produces_one_event_not_many(monkeypatch):
    """Regression for the FP bug: a persistent connection must not accumulate a
    timestamp every sample (which used to look like perfect beaconing)."""
    class Addr:
        def __init__(s, ip, port): s.ip, s.port = ip, port
    class Conn:
        def __init__(s, pid, ip, port):
            s.raddr, s.pid, s.status = Addr(ip, port), pid, "ESTABLISHED"
    class Proc:
        info = {"pid": 1, "name": "x", "exe": "", "memory_info": None,
                "ppid": 0, "create_time": time.time()}
    monkeypatch.setattr(psutil, "process_iter", lambda *a, **k: [Proc()])
    monkeypatch.setattr(psutil, "net_connections", lambda *a, **k: [Conn(1, "2.2.2.2", 443)])
    eng = ProbeEngine()
    for _ in range(5):           # 5 samples, same persistent connection
        eng._sample()
    assert len(eng._conn_events[(1, "2.2.2.2")]) == 1


# ── honest self-footprint ─────────────────────────────────────────────────────
def test_self_footprint_reflects_retained_data():
    eng = ProbeEngine()
    small = eng.self_footprint_mb()
    for i in range(500):
        eng._detections.appendleft(Detection(ts=time.time(), module="m", score=50,
                                              title=f"d{i}", why="w" * 50))
    bigger = eng.self_footprint_mb()
    assert isinstance(small, float) and small >= 0
    assert bigger > small                     # grows with the probe's OWN data


# ── durable, reversible rollback ─────────────────────────────────────────────
@pytest.fixture
def store(tmp_path, monkeypatch):
    from core import hardening as h
    monkeypatch.setattr(h, "ROLLBACK_FILE", tmp_path / "rollback.json")
    monkeypatch.setattr(h, "CONFIG_DIR", tmp_path)
    monkeypatch.setattr(P, "_QUARANTINE_DIR", tmp_path / "quarantine")
    return tmp_path


def test_change_recorded_to_durable_journal(store):
    from core import hardening as h
    eng = ProbeEngine()
    seen = []
    eng.subscribe_changes(seen.append)
    rec = eng.record_change("process_suspend", "1234", "suspended evil", reversible=True)
    assert rec["id"]
    assert len(eng.change_journal()) == 1
    assert any(r["id"] == rec["id"] for r in h._load())   # durable
    assert seen and seen[0]["reversible"] is True


def test_quarantine_and_revert_roundtrip(store):
    eng = ProbeEngine()
    target = store / "evil.sh"
    target.write_text("#!/bin/sh\n:(){ :|:& };:\n")
    ok, _ = eng.quarantine_file(str(target))
    assert ok and not target.exists()                     # moved, not deleted
    rec = eng.change_journal()[0]
    ok2, _ = eng.revert_change(rec["id"])
    assert ok2 and target.exists()                        # restored


def test_revert_unknown_record(store):
    ok, msg = ProbeEngine().revert_change("nope")
    assert not ok and "not found" in msg


# ── false-positive reductions ────────────────────────────────────────────────
def _proc(pid, name, exe, rss=50 * 1024 * 1024, age_s=100000):
    return {"pid": pid, "name": name, "exe": exe, "rss": rss,
            "ppid": 1, "create_time": time.time() - age_s}


def test_memorydefense_bare_deleted_exe_not_flagged():
    """A daemon whose binary was replaced by a package update (deleted on disk)
    with no other corroboration must NOT alert."""
    eng = ProbeEngine()
    snap = P.Snapshot(time.time(), [_proc(500, "postgres", "/usr/lib/postgres (deleted)")],
                      set(), [])
    assert P.MemoryDefenseModule().scan(snap, eng) == []


def test_memorydefense_corroborated_flagged():
    eng = ProbeEngine()
    # a LOLBin running from a deleted file → corroborated → alert
    snap = P.Snapshot(time.time(), [_proc(501, "python", "/tmp/x (deleted)")], set(), [])
    dets = P.MemoryDefenseModule().scan(snap, eng)
    assert dets and dets[0].evidence["no_disk_image"] and dets[0].pid == 501


def test_identity_common_tool_ordinary_port_not_flagged():
    eng = ProbeEngine()
    eng._last_conns = [{"pid": 600, "raddr_ip": "1.2.3.4", "raddr_port": 443, "status": "E"}]
    snap = P.Snapshot(time.time(), [_proc(600, "python", "/usr/bin/python3")], set(),
                      eng._last_conns)
    assert P.IdentityTelemetryModule().scan(snap, eng) == []


def test_identity_high_signal_tool_flagged():
    eng = ProbeEngine()
    eng._last_conns = [{"pid": 601, "raddr_ip": "1.2.3.4", "raddr_port": 443, "status": "E"}]
    snap = P.Snapshot(time.time(), [_proc(601, "powershell.exe", "C:/ps.exe")], set(),
                      eng._last_conns)
    dets = P.IdentityTelemetryModule().scan(snap, eng)
    assert dets and dets[0].pid == 601


def test_identity_suspect_port_always_flagged():
    eng = ProbeEngine()
    eng._last_conns = [{"pid": 602, "raddr_ip": "1.2.3.4", "raddr_port": 4444, "status": "E"}]
    snap = P.Snapshot(time.time(), [_proc(602, "python", "/usr/bin/python3")], set(),
                      eng._last_conns)
    dets = P.IdentityTelemetryModule().scan(snap, eng)
    assert dets and dets[0].score >= SEV_HIGH


# ── event-driven telemetry + feedback (limitation mitigations) ────────────────
def test_event_source_is_failsafe_and_honest():
    """The event source must never crash the probe, and telemetry_mode must not
    claim kernel events unless they are actually arriving."""
    eng = ProbeEngine()
    eng.start()
    time.sleep(0.5)
    mode = eng.telemetry_mode()
    eng.stop()
    assert isinstance(mode, str)
    # events aren't flowing in CI → must report polling, not kernel events
    if not eng._event_src.active:
        assert "kernel events" not in mode


def test_mark_benign_suppresses_repeat_and_feeds_baseline():
    eng = ProbeEngine()
    got = []
    eng.subscribe(got.append)
    eng._last_vector = [180, 1, 8, 4, 0, 0, 0.5, 0, 0.25, 3.0, 0]
    d1 = Detection(ts=time.time(), module="AIAnomaly", score=SEV_MED, title="Unusual X", why="w")
    eng._emit(d1)
    base = len(eng.model._baseline)
    eng.mark_benign(d1)
    assert len(eng.model._baseline) == base + 1          # folded into baseline
    d2 = Detection(ts=time.time(), module="AIAnomaly", score=SEV_MED, title="Unusual X", why="w")
    eng._emit(d2)
    assert len(got) == 1                                  # repeat suppressed
    # a critical still surfaces despite suppression
    eng._emit(Detection(ts=time.time(), module="AIAnomaly", score=96, title="Unusual X", why="w"))
    assert len(got) == 2


def test_burst_detection_uses_event_spawns():
    eng = ProbeEngine()
    now = time.time()
    eng._event_spawns.extend([now] * 8)                   # 8 kernel-sourced spawns, none sampled
    dets = P.AgenticThreatModule().scan(P.Snapshot(now, [], set(), []), eng)
    assert any("new processes" in d.title for d in dets)  # gap closed via events


def test_adaptive_interval_speeds_up_under_bursts():
    eng = ProbeEngine(sample_interval=4.0)
    eng._prev_pids = {1, 2, 3}
    assert eng._next_interval() == 4.0                    # quiet → normal cadence
    eng._event_spawns.extend([time.time()] * 6)           # busy
    assert eng._next_interval() < 4.0                     # speeds up
