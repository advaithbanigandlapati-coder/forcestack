"""
tests/test_reporter.py — Fix #74: tests for core/reporter.py (previously zero coverage).
"""
import pytest
from pathlib import Path


def test_generate_txt_creates_file(tmp_path, monkeypatch):
    """generate_txt() produces a non-empty .txt file."""
    monkeypatch.setattr("core.constants.AUDIT_FILE", tmp_path / "audit.json")
    monkeypatch.setattr("core.constants.REPORTS_DIR", tmp_path)
    from importlib import reload
    import core.audit as a; reload(a)
    monkeypatch.setattr("core.reporter.audit", a.audit)

    from core.reporter import generate_txt
    a.audit.record("firewall_config", "Firewall", "success", "OK", 1.0)
    out_path = str(tmp_path / "test_report.txt")
    result = generate_txt(out_path)
    assert Path(result).exists()
    content = Path(result).read_text()
    assert "ForceStack" in content
    assert "Firewall" in content
    assert len(content) > 200


def test_generate_txt_timestamped_no_overwrite(tmp_path, monkeypatch):
    """Fix #26: two calls on same day produce different filenames."""
    monkeypatch.setattr("core.constants.AUDIT_FILE", tmp_path / "audit.json")
    monkeypatch.setattr("core.constants.REPORTS_DIR", tmp_path)
    from importlib import reload
    import core.audit as a; reload(a)
    monkeypatch.setattr("core.reporter.audit", a.audit)

    from core.reporter import generate_txt
    import time
    p1 = generate_txt()
    time.sleep(1.1)          # ensure seconds differ
    p2 = generate_txt()
    assert p1 != p2          # fix #26: unique filenames


def test_generate_txt_atomic_no_zero_byte_on_error(tmp_path, monkeypatch):
    """Fix #29: if write fails, original file is not left as 0 bytes."""
    monkeypatch.setattr("core.constants.AUDIT_FILE", tmp_path / "audit.json")
    monkeypatch.setattr("core.constants.REPORTS_DIR", tmp_path)
    from importlib import reload
    import core.audit as a; reload(a)
    monkeypatch.setattr("core.reporter.audit", a.audit)

    original = tmp_path / "report.txt"
    original.write_text("original content")


    def _bad_replace(self, target):
        raise OSError("simulated disk full")

    monkeypatch.setattr(Path, "replace", _bad_replace)

    from core.reporter import generate_txt
    with pytest.raises(OSError):
        generate_txt(str(original))

    # Original must still have content (not wiped by failed write)
    assert original.read_text() == "original content"


def test_generate_txt_nist_matrix(tmp_path, monkeypatch):
    """Report includes NIST control coverage matrix."""
    monkeypatch.setattr("core.constants.AUDIT_FILE", tmp_path / "audit.json")
    monkeypatch.setattr("core.constants.REPORTS_DIR", tmp_path)
    from importlib import reload
    import core.audit as a; reload(a)
    monkeypatch.setattr("core.reporter.audit", a.audit)

    from core.reporter import generate_txt
    path = generate_txt()
    content = Path(path).read_text()
    assert "NIST SP 800-53" in content
    assert "SC-7" in content


def test_generate_pdf_fallback_raises(tmp_path, monkeypatch):
    """Fix #27: PDFUnavailable raised when reportlab absent — not silent fallback."""
    monkeypatch.setattr("core.constants.AUDIT_FILE", tmp_path / "audit.json")
    monkeypatch.setattr("core.constants.REPORTS_DIR", tmp_path)
    from importlib import reload
    import core.audit as a; reload(a)
    monkeypatch.setattr("core.reporter.audit", a.audit)

    import builtins
    real_import = builtins.__import__

    def _block_reportlab(name, *args, **kwargs):
        if name == "reportlab" or name.startswith("reportlab."):
            raise ImportError("reportlab blocked for test")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", _block_reportlab)

    from core.reporter import generate_pdf, PDFUnavailable
    with pytest.raises(PDFUnavailable) as exc_info:
        generate_pdf(str(tmp_path / "test.pdf"))

    # The txt_path attribute must point at a real file
    assert Path(exc_info.value.txt_path).exists()


def test_compliance_score_passes_total_tools(tmp_path, monkeypatch):
    """Fix #13: compliance_score now takes total_tools parameter, not circular import."""
    monkeypatch.setattr("core.constants.AUDIT_FILE", tmp_path / "audit.json")
    from importlib import reload
    import core.audit as a; reload(a)
    log = a.AuditLog()
    log.record("firewall_config", "Firewall", "success", "", 0.1)
    score = log.compliance_score(total_tools=10)
    assert 0 <= score <= 100
    assert score == 10   # 1 success / 10 total = 10%
