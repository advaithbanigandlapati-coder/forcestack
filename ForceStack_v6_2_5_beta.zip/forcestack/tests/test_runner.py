"""
tests/test_runner.py — Fix #73: tests for core/runner.py (previously zero coverage).
"""
import threading


def test_run_script_success(tmp_path, monkeypatch):
    """run_script executes a dry-run and calls done_cb with (True, 'dry-run', dur)."""
    monkeypatch.setattr("core.constants.AUDIT_FILE", tmp_path / "audit.json")
    from importlib import reload
    import core.audit as a; reload(a)
    monkeypatch.setattr("core.runner.audit", a.audit)

    from core.runner import run_script
    results = []
    done_evt = threading.Event()

    def _done(ok, detail, dur):
        results.append((ok, detail))
        done_evt.set()

    run_script("firewall_config", lambda l, lv: None, _done, dry_run=True)
    done_evt.wait(timeout=10)
    assert results, "done_cb never called"
    assert results[0][0] is True
    assert results[0][1] == "dry-run"


def test_run_script_missing_module(tmp_path, monkeypatch):
    """Missing module → done_cb called with (False, 'module not found', dur)."""
    monkeypatch.setattr("core.constants.AUDIT_FILE", tmp_path / "audit.json")
    from importlib import reload
    import core.audit as a; reload(a)
    monkeypatch.setattr("core.runner.audit", a.audit)

    from core.runner import run_script
    results = []
    evt = threading.Event()

    def _done(ok, detail, dur):
        results.append((ok, detail))
        evt.set()

    run_script("__nonexistent_tool__", lambda l, lv: None, _done)
    evt.wait(timeout=10)
    assert results[0][0] is False
    assert "module not found" in results[0][1]


def test_run_script_bad_return_type(tmp_path, monkeypatch):
    """Fix #31: execute() returning wrong type raises TypeError caught as error."""
    import sys
    import types

    monkeypatch.setattr("core.constants.AUDIT_FILE", tmp_path / "audit.json")
    from importlib import reload
    import core.audit as a; reload(a)
    monkeypatch.setattr("core.runner.audit", a.audit)

    # Inject a fake module with bad return type
    bad_mod = types.ModuleType("scripts.__bad_return__")
    bad_mod.TOOL_NAME = "Bad Return"
    bad_mod.TOOL_ID   = "__bad_return__"
    bad_mod.execute   = lambda emit, os: ("oops", True)   # (str, bool) not (bool, str)
    sys.modules["scripts.__bad_return__"] = bad_mod

    from core.runner import run_script
    results = []
    evt = threading.Event()

    def _done(ok, detail, dur):
        results.append((ok, detail))
        evt.set()

    run_script("__bad_return__", lambda l, lv: None, _done)
    evt.wait(timeout=10)
    assert results[0][0] is False
    assert "return-type error" in results[0][1] or "must return" in results[0][1]

    del sys.modules["scripts.__bad_return__"]


def test_run_all_dry_run(tmp_path, monkeypatch):
    """run_all dry-run completes all tools and calls all_done_cb."""
    monkeypatch.setattr("core.constants.AUDIT_FILE", tmp_path / "audit.json")
    from importlib import reload
    import core.audit as a; reload(a)
    monkeypatch.setattr("core.runner.audit", a.audit)

    from core.runner import run_all
    from core.tools import ALL_TOOLS

    results = []
    evt = threading.Event()

    def _all_done(passed, failed):
        results.append((passed, failed))
        evt.set()

    tool_ids = [t.id for t in ALL_TOOLS[:3]]   # just first 3 for speed
    run_all(tool_ids, lambda l, lv: None,
            lambda tid, ok, d: None, _all_done, dry_run=True)
    evt.wait(timeout=30)
    assert results, "all_done_cb never called"
    p, f = results[0]
    assert p + f == len(tool_ids)


def test_run_all_stop_event(tmp_path, monkeypatch):
    """Fix #69: stop_event halts run_all after current script."""
    monkeypatch.setattr("core.constants.AUDIT_FILE", tmp_path / "audit.json")
    from importlib import reload
    import core.audit as a; reload(a)
    monkeypatch.setattr("core.runner.audit", a.audit)

    from core.runner import run_all
    from core.tools import ALL_TOOLS

    stop = threading.Event()
    stop.set()   # pre-set stop before run begins

    results = []
    evt = threading.Event()

    def _all_done(passed, failed):
        results.append((passed, failed))
        evt.set()

    tool_ids = [t.id for t in ALL_TOOLS]
    run_all(tool_ids, lambda l, lv: None,
            lambda tid, ok, d: None, _all_done,
            stop_event=stop, dry_run=True)
    evt.wait(timeout=15)
    assert results, "all_done_cb never called"
    # Stop was pre-set → should have run 0 tools
    p, f = results[0]
    assert p + f == 0
