"""
tests/test_scripts_dryrun.py — Fix #75: dry-run test for every script.
Verifies each execute() returns (bool, str) without crashing.
"""
import pytest
import importlib
from core.tools import ALL_TOOLS


@pytest.mark.parametrize("tool", ALL_TOOLS, ids=[t.id for t in ALL_TOOLS])
def test_script_dry_run_return_type(tool, monkeypatch):
    """
    Fix #75: each script's execute() must return (bool, str).
    We mock run_cmd to be a no-op so no real system changes occur.

    Fix #15: patch BOTH core.utils.run_cmd (definition site) AND
    scripts._base.run_cmd (binding site actually used by all script modules).
    If a script module was already cached in sys.modules from a previous test,
    its run_cmd name is already bound to the definition-site function object;
    patching only core.utils.run_cmd would leave the cached binding untouched.
    """
    def _noop(*a, **kw):
        return ("mocked output", True)
    monkeypatch.setattr("core.utils.run_cmd",    _noop)
    monkeypatch.setattr("scripts._base.run_cmd", _noop)

    # Also patch subprocess.run in case any script calls it directly
    import subprocess
    class _FakeResult:
        returncode = 0; stdout = "mocked"; stderr = ""
    monkeypatch.setattr(subprocess, "run", lambda *a, **kw: _FakeResult())

    lines = []
    def _emit(text: str, level: str = "info"):
        lines.append((text, level))

    mod = importlib.import_module(f"scripts.{tool.id}")
    result = mod.execute(_emit, "Linux")

    assert isinstance(result, tuple), \
        f"{tool.id}: execute() must return a tuple, got {type(result)}"
    assert len(result) == 2, \
        f"{tool.id}: execute() must return 2-tuple, got {len(result)}"
    ok, detail = result
    assert isinstance(ok, bool), \
        f"{tool.id}: first element must be bool, got {type(ok)}"
    assert isinstance(detail, str), \
        f"{tool.id}: second element must be str, got {type(detail)}"
