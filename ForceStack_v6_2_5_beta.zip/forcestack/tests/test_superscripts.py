"""Integration tests for the 5 revertable hardening superscripts and the
UI-reachable revert path."""
import importlib
import pytest
from core.tools import TOOL_MAP, tools_by_section
from core.constants import NIST_MAP, NIST_CONTROL_NAMES

SUPERSCRIPTS = ["kernel_hardening", "smb_protocol_lockdown", "credential_protection",
                "exec_logging", "filesystem_hardening"]


@pytest.mark.parametrize("tid", SUPERSCRIPTS)
def test_registered_everywhere(tid):
    assert tid in TOOL_MAP                       # in ALL_TOOLS
    assert tid in NIST_MAP                        # NIST mapping present
    for ctrl in NIST_MAP[tid]:
        assert ctrl in NIST_CONTROL_NAMES, f"{ctrl} missing a friendly name"
    mod = importlib.import_module(f"scripts.{tid}")
    assert hasattr(mod, "execute") and mod.TOOL_ID == tid


def test_all_in_hardening_section():
    ids = {t.id for t in tools_by_section("hardening")}
    for tid in SUPERSCRIPTS:
        assert tid in ids


@pytest.mark.parametrize("tid", SUPERSCRIPTS)
def test_darwin_is_graceful(tid):
    """On macOS these report status and must not crash or falsely fail."""
    mod = importlib.import_module(f"scripts.{tid}")
    ok, detail = mod.execute(lambda *a, **k: None, "Darwin")
    assert isinstance(ok, bool) and isinstance(detail, str)


def test_probe_revert_delegates_file_record_to_hardening(tmp_path, monkeypatch):
    """A hardening file-backup change must be revertable through the probe's
    revert_change() (the path the UI Revert button calls)."""
    from core import hardening as h
    from core import probe as P
    monkeypatch.setattr(h, "ROLLBACK_FILE", tmp_path / "rollback.json")
    monkeypatch.setattr(h, "CONFIG_DIR", tmp_path)
    monkeypatch.setattr(h, "SNAPSHOT_DIR", tmp_path / "snap")
    target = tmp_path / "conf"; target.write_text("ORIGINAL")
    h.backup_file("kernel_hardening", target, "before edit")
    target.write_text("MODIFIED")
    rec = h.list_rollbacks(tool_id="kernel_hardening")[0]
    eng = P.ProbeEngine()
    ok, _ = eng.revert_change(rec["id"])          # UI button → this call
    assert ok and target.read_text() == "ORIGINAL"
