"""Tests for core/utils.py"""


def test_run_cmd_success():
    import sys
    from core.utils import run_cmd
    out, ok = run_cmd([sys.executable, "-c", "print('hello')"])
    assert ok
    assert "hello" in out


def test_run_cmd_timeout():
    import sys
    from core.utils import run_cmd
    out, ok = run_cmd([sys.executable, "-c", "import time; time.sleep(10)"], timeout=1)
    assert not ok
    assert "TIMEOUT" in out


def test_run_cmd_not_found():
    from core.utils import run_cmd
    out, ok = run_cmd(["definitely_not_a_real_binary_xyz_abc"])
    assert not ok
    assert "NOT FOUND" in out


def test_already_applied_streams(tmp_path):
    """Fix #19: already_applied streams instead of loading all into memory."""
    from core.utils import already_applied
    f = tmp_path / "config.conf"
    f.write_text("line1\nForceStack marker\nline3\n")
    assert already_applied(f, "ForceStack marker") is True
    assert already_applied(f, "not present")      is False
    assert already_applied(f)                      is True      # file exists check
    assert already_applied(tmp_path / "nope.conf") is False     # missing file


def test_sudo_prefix_logic(monkeypatch):
    """Fix #30: returns [] as root, ['sudo'] otherwise."""
    from core.utils import sudo_prefix
    monkeypatch.setattr("os.geteuid", lambda: 0)
    assert sudo_prefix() == []
    monkeypatch.setattr("os.geteuid", lambda: 1000)
    assert sudo_prefix() == ["sudo"]


def test_os_name_reexported():
    """Fix #18: OS_NAME is re-exported from constants, not redefined."""
    from core import utils, constants
    assert utils.OS_NAME is constants.OS_NAME
