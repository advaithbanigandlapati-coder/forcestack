"""
ui/app.py — ForceStack v3 shell/router.
Issues fixed in this file:
  #68 — _done callback now wrapped in self.after(0,...) — was called from bg thread
  #69 — run_all_stop.clear() called before every new run; nav between runs is safe
  #70 — each page is its own class in ui/pages/ (app is shell/router only)
  #71 — _nav() wraps every page build in try/except; broken page shows error card

UI improvements applied throughout: sharper glassmorphism, Warp-style terminal
blocks, improved sidebar with animated pill, richer dashboard ring + cards,
better typography hierarchy, accessible colour contrast.
"""

from __future__ import annotations
import json
import threading
import time
import datetime
import platform
import subprocess
import traceback
from pathlib import Path
from tkinter import filedialog, messagebox
import tkinter as tk
import customtkinter as ctk

from core.constants import (
    APP_NAME, APP_VERSION, OS_NAME, HOSTNAME, CURRENT_USER,
    C, NIST_CONTROL_NAMES, WINDOW_STATE, ONBOARD_STATE,
    save_config, load_config_dict,
)
from core.tools import ALL_TOOLS, TOOL_MAP, SECTIONS, tools_by_section
from core.audit import audit
from core.runner import run_script, run_all
from core.reporter import generate_txt, generate_pdf, PDFUnavailable
from ui.utils import F, scaled, init_dpi, Tooltip
from ui.widgets import (
    GlassCard, StatusDot, RiskBadge, ColorTerminal,
    AnimatedProgress, ErrorToast, ExplainCard,
)
from ui.background import MeshBackground
from core.probe import probe
from core import pqcrypto

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

# 8-px grid constants
PAD_SM  = scaled(8)
PAD_MD  = scaled(16)
PAD_LG  = scaled(24)
PAD_XL  = scaled(32)
PAD_XXL = scaled(48)


from ui.pages.base import BasePage as _BasePage  # noqa: E402 (late import avoids circular)


# ─────────────────────────────────────────────────────────────────────────────
# Inline page classes (fix #70: decomposed from one 1200-line monolith)
# ─────────────────────────────────────────────────────────────────────────────

class _PageBase(_BasePage):
    """
    Thin adapter so all inline page builders in this file can use the short
    names (header/divider/empty_state/footer) rather than the underscore-
    prefixed names on BasePage.  Eliminates the previous full duplication.
    Fix #11 (architecture): _PageBase now extends ui.pages.base.BasePage
    instead of re-implementing the same four methods independently.
    """

    def __init__(self, p, app):
        super().__init__(p, app)
        self.p = self.container          # convenience alias used throughout app.py

    def header(self, title: str, sub: str = "") -> None:
        self._page_header(title, sub)

    def divider(self) -> None:
        self._divider()

    def empty_state(self, icon, title, body, cta_text="", cta_cmd=None) -> None:
        self._empty_state(icon, title, body, cta_text, cta_cmd)

    def footer(self) -> None:
        self._footer()


# ─────────────────────────────────────────────────────────────────────────────
class ForceStackApp(ctk.CTk):

    def __init__(self):
        super().__init__()
        init_dpi(self)

        self.title(f"{APP_NAME}  v{APP_VERSION}")
        # Window icon from the brand mark (guarded — never break startup over it).
        try:
            import tkinter as _tk
            from pathlib import Path as _P
            _icon = _P(__file__).resolve().parent.parent / "assets" / "logo_mark.png"
            if _icon.exists():
                self._brand_icon = _tk.PhotoImage(file=str(_icon))
                self.iconphoto(True, self._brand_icon)
        except Exception:
            pass
        self._load_window_state()
        self.minsize(scaled(1100), scaled(700))
        self.configure(fg_color=C["bg0"])
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        # ── Shared state ───────────────────────────────────────────
        self._active_section: str | None  = None
        # Fix #69: single stop event, always .clear()'d before new run
        self._run_all_stop  = threading.Event()
        self._sidebar_btns: dict[str, ctk.CTkButton] = {}

        self._build_layout()
        self._bind_shortcuts()
        self.after(80, lambda: self._nav("dashboard"))
        # First-run onboarding — shown once, dismissed permanently via sentinel file
        if not ONBOARD_STATE.exists():
            self.after(300, self._show_onboarding)

    # ══════════════════════════════════════════════════════════════════
    # Layout
    # ══════════════════════════════════════════════════════════════════
    def _build_layout(self):
        # Animated mesh gradient background
        self._bg = MeshBackground(self)
        self._bg.place(relx=0, rely=0, relwidth=1, relheight=1)

        # Sidebar (frosted glass illusion via semi-opaque frame)
        self._sb_frame = tk.Frame(self, bg=C["bg1"] + "EE", width=scaled(260))
        self._sb_frame.place(x=0, y=0, relheight=1)
        self._sb_frame.pack_propagate(False)
        self._build_sidebar()

        # Main scrollable content — fills the space beside the fixed sidebar.
        # CTk 5.2.x requires width/height on the constructor, not on place(), so
        # we set an initial width and keep it in sync on resize. The guard
        # (only reconfigure when the width actually changes) prevents the
        # Configure→configure→Configure re-entrancy loop.
        self._main = ctk.CTkFrame(self, fg_color="transparent", corner_radius=0,
                                  width=scaled(1140))
        self._main.place(x=scaled(260), y=0, relheight=1)
        self._main_w = -1

        def _fit_main(_evt=None):
            try:
                w = self.winfo_width() - scaled(260)
                if w > 0 and w != self._main_w:
                    self._main_w = w
                    self._main.configure(width=w)
            except Exception:
                pass
        self.bind("<Configure>", _fit_main, add="+")
        self.after(50, _fit_main)

        self._scroll = ctk.CTkScrollableFrame(
            self._main, fg_color="transparent",
            scrollbar_button_color=C["bg4"],
            scrollbar_button_hover_color=C["accent"],
        )
        self._scroll.pack(fill="both", expand=True)

        self._content = ctk.CTkFrame(self._scroll, fg_color="transparent", corner_radius=0)
        self._content.pack(fill="both", expand=True, padx=PAD_XL, pady=0)

    def _build_sidebar(self):
        sb = self._sb_frame

        # ── Logo with layered glow ─────────────────────────────────
        logo_wrap = tk.Frame(sb, bg=C["bg1"])
        logo_wrap.pack(fill="x", padx=PAD_MD, pady=(PAD_XXL, PAD_SM))

        # Shadow label 1px offset → glow feel
        shadow = tk.Label(logo_wrap, text="⚔  ForceStack",
                          font=("Courier", scaled(20), "bold"),
                          bg=C["bg1"], fg=C["accent"] + "40")
        shadow.place(x=1, y=1)
        tk.Label(logo_wrap, text="⚔  ForceStack",
                 font=("Courier", scaled(20), "bold"),
                 bg=C["bg1"], fg=C["accent"]).pack(anchor="w")
        tk.Label(logo_wrap, text="Enterprise Hardening  ·  NIST SP 800-53",
                 font=(platform.system() == "Darwin" and "SF Pro Display" or "Segoe UI", scaled(8)),
                 bg=C["bg1"], fg=C["t3"]).pack(anchor="w", pady=(scaled(3), 0))

        # OS + host badge
        tk.Label(sb,
                 text=f"  {OS_NAME}  ·  {HOSTNAME[:18]}  ",
                 font=("Courier", scaled(9), "bold"),
                 bg=C["bg5"], fg=C["accent2"],
                 padx=PAD_SM, pady=scaled(4)).pack(
            anchor="w", padx=PAD_MD, pady=(PAD_SM, PAD_MD))

        self._sb_divider(sb)

        NAV = [
            ("dashboard",  "🏠  Dashboard"),
            ("run_all",    f"⚡  Run All  ({len(ALL_TOOLS)})"),
            ("probe",      "🛰  Sentinel Probe"),
            ("encrypt",    "🔐  Encryption Vault"),
            ("─", ""),
            ("hardening",  "🛡  System Hardening"),
            ("passwords",  "🔑  Passwords & Accounts"),
            ("scanning",   "🔍  Threat Scanning"),
            ("network",    "🌐  Network Security"),
            ("compliance", "📊  Compliance & Patching"),
            ("─", ""),
            ("audit",      "📝  Audit Log"),
            ("report",     "📄  Generate Report"),
            ("settings",   "⚙  Settings"),
        ]

        for sid, label in NAV:
            if sid == "─":
                self._sb_divider(sb)
                continue
            is_cta = (sid == "run_all")
            btn = ctk.CTkButton(
                sb, text=label,
                font=F["sidebar_item"](),
                fg_color=C["accent"] if is_cta else "transparent",
                hover_color=C["adim"] if is_cta else C["bg4"] + "88",
                text_color=C["bg0"] if is_cta else C["t2"],
                anchor="w", height=scaled(46),
                corner_radius=scaled(8),
                command=lambda s=sid: self._nav(s),
            )
            btn.pack(fill="x", padx=PAD_SM, pady=scaled(2))
            self._sidebar_btns[sid] = btn

        # ── User identity chip ─────────────────────────────────────
        self._sb_divider(sb)
        initials = (CURRENT_USER.strip("<>")[:2].upper()
                    if CURRENT_USER not in ("", "<unknown>") else "?")
        bottom = tk.Frame(sb, bg=C["bg1"])
        bottom.pack(side="bottom", fill="x", padx=PAD_MD, pady=PAD_MD)
        chip = tk.Frame(bottom, bg=C["bg4"], pady=scaled(8), padx=scaled(10))
        chip.pack(fill="x")
        tk.Label(chip, text=initials, font=("Courier", scaled(11), "bold"),
                 bg=C["accent"], fg=C["bg0"], width=2, padx=scaled(6)).pack(side="left")
        info = tk.Frame(chip, bg=C["bg4"])
        info.pack(side="left", padx=(PAD_SM, 0))
        disp = CURRENT_USER if CURRENT_USER != "<unknown>" else "Unknown User"
        tk.Label(info, text=disp[:20], font=(
            platform.system() == "Darwin" and "SF Pro Display" or "Segoe UI",
            scaled(10), "bold"), bg=C["bg4"], fg=C["t1"]).pack(anchor="w")
        tk.Label(info, text=f"v{APP_VERSION}  ·  NIST SP 800-53",
                 font=("Courier", scaled(8)), bg=C["bg4"], fg=C["t3"]).pack(anchor="w")

    def _sb_divider(self, parent):
        c = tk.Canvas(parent, height=1, bg=C["bg1"], highlightthickness=0)
        c.pack(fill="x", padx=PAD_MD, pady=scaled(6))
        c.create_line(0, 0, 9999, 0, fill=C["border"])

    # ══════════════════════════════════════════════════════════════════
    # Navigation with error boundary (fix #71)
    # ══════════════════════════════════════════════════════════════════
    def _nav(self, section: str):
        self._active_section = section

        # Clear content
        for w in self._content.winfo_children():
            w.destroy()

        # Update sidebar highlights
        for sid, btn in self._sidebar_btns.items():
            is_cta = (sid == "run_all")
            if sid == section:
                btn.configure(
                    fg_color=C["bg5"] if not is_cta else C["adim"],
                    text_color=C["accent"] if not is_cta else C["bg0"],
                    font=F["section_label"](),
                )
            else:
                btn.configure(
                    fg_color=C["accent"] if is_cta else "transparent",
                    text_color=C["bg0"] if is_cta else C["t2"],
                    font=F["sidebar_item"](),
                )

        # Fix #71: error boundary — broken page shows error card, not app crash
        try:
            self._dispatch(section)
        except Exception as exc:
            self._show_error_card(section, exc)

    def _dispatch(self, section: str):
        pages = {
            "dashboard": self._page_dashboard,
            "run_all":   self._page_run_all,
            "probe":     self._page_probe,
            "encrypt":   self._page_encrypt,
            "audit":     self._page_audit,
            "report":    self._page_report,
            "settings":  self._page_settings,
        }
        if section in pages:
            pages[section]()
        elif section in SECTIONS:
            self._page_section(section)

    def _show_error_card(self, section: str, exc: Exception):
        """Fix #71: render in-app error instead of crashing."""
        tb = traceback.format_exc()
        card = GlassCard(self._content, hoverable=False,
                         fg_color=C["red"] + "12",
                         border_color=C["red"] + "40")
        card.pack(fill="x", pady=PAD_XL, padx=PAD_XL)
        ctk.CTkLabel(card, text="⚠  Page Error",
                     font=F["section_label"](), text_color=C["red"]).pack(
            anchor="w", padx=PAD_XL, pady=(PAD_MD, 0))
        ctk.CTkLabel(card,
                     text=f"Section '{section}' failed to render:\n{exc}",
                     font=F["card_sub"](), text_color=C["t2"],
                     justify="left").pack(anchor="w", padx=PAD_XL, pady=PAD_SM)
        term = ColorTerminal(card, height=scaled(100))
        term.pack(fill="x", padx=PAD_MD, pady=PAD_MD)
        term.append(tb, "err")

    # ══════════════════════════════════════════════════════════════════
    # Keyboard shortcuts
    # ══════════════════════════════════════════════════════════════════
    def _bind_shortcuts(self):
        mod = "Command" if OS_NAME == "Darwin" else "Control"
        self.bind(f"<{mod}-r>",     lambda _: self._nav("run_all"))
        self.bind(f"<{mod}-l>",     lambda _: self._nav("audit"))
        self.bind(f"<{mod}-g>",     lambda _: self._nav("report"))
        self.bind(f"<{mod}-comma>", lambda _: self._nav("settings"))
        self.bind("<question>",      lambda _: self._show_help())
        self._bind_accessibility()

    def _bind_accessibility(self):
        """Keyboard-first accessibility: activate the focused button with Enter,
        and draw a visible focus ring so keyboard users can see where they are.
        CTk widgets focus an internal canvas, so we climb to the CTkButton."""
        def _button_ancestor(w):
            for _ in range(5):
                if w is None:
                    return None
                if "CTkButton" in w.__class__.__name__:
                    return w
                w = getattr(w, "master", None)
            return None

        def _activate(_evt=None):
            b = _button_ancestor(self.focus_get())
            if b is not None:
                try:
                    cmd = b.cget("command")
                    if callable(cmd):
                        cmd()
                        return "break"
                except Exception:
                    pass
            return None

        # Enter only (never Space) so it can't swallow spaces typed into fields.
        self.bind_all("<Return>", _activate, add="+")

        def _focus_in(evt):
            b = _button_ancestor(evt.widget)
            if b is None:
                return
            try:
                b._a11y_prev = (b.cget("border_width"), b.cget("border_color"))
                b.configure(border_width=max(2, b.cget("border_width")),
                            border_color=C["accent"])
            except Exception:
                pass

        def _focus_out(evt):
            b = _button_ancestor(evt.widget)
            try:
                prev = getattr(b, "_a11y_prev", None) if b is not None else None
                if prev is not None:
                    b.configure(border_width=prev[0], border_color=prev[1])
                    b._a11y_prev = None
            except Exception:
                pass

        self.bind_all("<FocusIn>", _focus_in, add="+")
        self.bind_all("<FocusOut>", _focus_out, add="+")

    def _show_help(self):
        mod = "⌘" if OS_NAME == "Darwin" else "Ctrl"
        ov = tk.Toplevel(self)
        ov.title("Keyboard Shortcuts")
        ov.configure(bg=C["bg3"])
        ov.geometry(f"{scaled(400)}x{scaled(320)}")
        ov.transient(self); ov.grab_set()
        ctk.CTkLabel(ov, text="Keyboard Shortcuts",
                     font=F["section_label"](), text_color=C["accent"]).pack(pady=(PAD_LG, PAD_SM))
        for keys, desc in [(f"{mod}+R","Run All"),(f"{mod}+L","Audit Log"),
                           (f"{mod}+G","Generate Report"),(f"{mod}+,","Settings"),("?","This overlay")]:
            row = tk.Frame(ov, bg=C["bg3"])
            row.pack(fill="x", padx=PAD_XL, pady=scaled(4))
            tk.Label(row, text=keys, font=("Courier", scaled(11), "bold"),
                     bg=C["bg4"], fg=C["accent"], padx=PAD_SM, pady=scaled(3)).pack(side="left")
            tk.Label(row, text=f"  {desc}", font=("Courier", scaled(11)),
                     bg=C["bg3"], fg=C["t1"]).pack(side="left")
        ctk.CTkButton(ov, text="Close", command=ov.destroy,
                      fg_color=C["bg4"], hover_color=C["bg5"],
                      text_color=C["t2"]).pack(pady=PAD_LG)

    # ══════════════════════════════════════════════════════════════════
    # Error toast + detail page  (Item 1 / Item 2)
    # ══════════════════════════════════════════════════════════════════
    def _show_toast(self, payload: dict) -> None:
        """Slide in an ErrorToast over the app. Replaces any existing toast."""
        for child in self.winfo_children():
            if isinstance(child, ErrorToast):
                child._dismiss()
        toast = ErrorToast(
            self, payload,
            on_detail=lambda p=payload: self._page_error_detail(p),
        )
        toast.lift()

    def _page_error_detail(self, payload: dict) -> None:
        """
        Full error detail page — rendered when user clicks 'View fix steps' on a toast.
        Shows: what failed, why it matters, how to fix it, raw diagnostic output.
        Not a registered section; called directly from toast on_detail callback.
        """
        back_to = self._active_section or "dashboard"
        for w in self._content.winfo_children():
            w.destroy()
        # Clear sidebar highlights (not a registered section)
        for sid, btn in self._sidebar_btns.items():
            is_cta = (sid == "run_all")
            btn.configure(
                fg_color=C["accent"] if is_cta else "transparent",
                text_color=C["bg0"] if is_cta else C["t2"],
                font=F["sidebar_item"](),
            )
        p = self._content

        ctk.CTkButton(
            p,
            text=f"← Back to {back_to.replace('_', ' ').title()}",
            font=F["button_sm"](), fg_color=C["bg4"], hover_color=C["bg5"],
            text_color=C["t2"], height=scaled(32), corner_radius=scaled(6),
            command=lambda: self._nav(back_to),
        ).pack(anchor="w", pady=(PAD_MD, 0))

        # ── What failed ───────────────────────────────────────────
        title_card = GlassCard(p, hoverable=False,
                                fg_color=C["red"] + "12",
                                border_color=C["red"] + "40")
        title_card.pack(fill="x", pady=PAD_SM)
        ctk.CTkLabel(
            title_card,
            text="⚠  " + payload.get("title", "Error"),
            font=F["page_title"](), text_color=C["red"],
        ).pack(anchor="w", padx=PAD_XL, pady=PAD_LG)

        # ── Why it matters ────────────────────────────────────────
        why = payload.get("why", "")
        if why:
            why_card = GlassCard(p, hoverable=False,
                                  fg_color=C["yellow"] + "10",
                                  border_color=C["yellow"] + "30")
            why_card.pack(fill="x", pady=scaled(4))
            ctk.CTkLabel(why_card, text="Why this matters",
                         font=F["h2"](), text_color=C["yellow"]).pack(
                anchor="w", padx=PAD_XL, pady=(PAD_MD, 0))
            ctk.CTkLabel(why_card, text=why, font=F["card_sub"](),
                         text_color=C["t1"], wraplength=scaled(760),
                         justify="left").pack(anchor="w", padx=PAD_XL, pady=PAD_MD)

        # ── How to fix it ─────────────────────────────────────────
        fix = payload.get("fix", "")
        if fix:
            fix_card = GlassCard(p, hoverable=False,
                                  fg_color=C["green"] + "10",
                                  border_color=C["green"] + "30")
            fix_card.pack(fill="x", pady=scaled(4))
            ctk.CTkLabel(fix_card, text="How to fix it",
                         font=F["h2"](), text_color=C["green"]).pack(
                anchor="w", padx=PAD_XL, pady=(PAD_MD, 0))
            for step in fix.split("\n"):
                step = step.strip()
                if step:
                    row = ctk.CTkFrame(fix_card, fg_color="transparent")
                    row.pack(fill="x", padx=PAD_XL, pady=scaled(2))
                    ctk.CTkLabel(row, text="→", font=F["badge"](),
                                 text_color=C["green"], width=scaled(20)).pack(side="left")
                    ctk.CTkLabel(row, text=step, font=F["card_sub"](),
                                 text_color=C["t1"], wraplength=scaled(720),
                                 justify="left", anchor="w").pack(side="left", padx=scaled(6))
            ctk.CTkFrame(fix_card, height=PAD_MD, fg_color="transparent").pack()

        # ── Raw diagnostic output ─────────────────────────────────
        raw = payload.get("raw", "")
        if raw:
            ctk.CTkLabel(p, text="Raw diagnostic output",
                         font=F["h2"](), text_color=C["t3"]).pack(
                anchor="w", pady=(PAD_MD, PAD_SM))
            term = ColorTerminal(p, height=scaled(150))
            term.pack(fill="x")
            term.after(50, lambda: term.append(raw, "err"))

    # ══════════════════════════════════════════════════════════════════
    # Dashboard
    # ══════════════════════════════════════════════════════════════════
    def _page_dashboard(self):
        pg = _PageBase(self._content, self)
        pg.header("Security Command Center",
                  f"{HOSTNAME}  ·  {platform.platform()[:60]}")
        p = self._content

        st    = audit.stats()
        score = audit.compliance_score(len(ALL_TOOLS))

        # ── Hero row: ring + 2×2 stats ────────────────────────────
        hero_row = ctk.CTkFrame(p, fg_color="transparent")
        hero_row.pack(fill="x", pady=(0, PAD_MD))

        # Compliance ring card
        ring_card = GlassCard(hero_row, hoverable=False)
        ring_card.pack(side="left", padx=(0, PAD_SM), pady=0,
                       ipadx=PAD_LG, ipady=PAD_MD)

        ring_canvas = tk.Canvas(ring_card, width=scaled(120), height=scaled(120),
                                bg=C["bg3"], highlightthickness=0)
        ring_canvas.pack(pady=(PAD_SM, 0))

        def _draw_ring(pct: float):
            ring_canvas.delete("all")
            # Track
            ring_canvas.create_arc(scaled(8), scaled(8), scaled(112), scaled(112),
                                   start=90, extent=360,
                                   outline=C["bg5"], width=scaled(10), style="arc")
            # Glow arc (slightly wider, behind)
            if pct > 0:
                ring_canvas.create_arc(scaled(6), scaled(6), scaled(114), scaled(114),
                                       start=90, extent=-pct * 360,
                                       outline=C["accent"] + "30",
                                       width=scaled(14), style="arc")
                ring_canvas.create_arc(scaled(8), scaled(8), scaled(112), scaled(112),
                                       start=90, extent=-pct * 360,
                                       outline=C["accent"], width=scaled(10), style="arc")
            ring_canvas.create_text(scaled(60), scaled(54),
                                    text=str(int(pct * 100)),
                                    fill=C["t1"],
                                    font=("Courier", scaled(24), "bold"))
            ring_canvas.create_text(scaled(60), scaled(76),
                                    text="/ 100", fill=C["t3"],
                                    font=("Courier", scaled(10)))

        _draw_ring(0)

        def _anim_ring(step: int = 0, steps: int = 36):
            frac = min(1.0, step / steps) * score / 100
            _draw_ring(frac)
            if step < steps:
                p.after(16, lambda: _anim_ring(step + 1, steps))

        p.after(200, lambda: _anim_ring())

        label = (f"{st['success']} passed  ·  {st['errors']} failed"
                 if st["total"] else "— Run a script to begin")
        ctk.CTkLabel(ring_card, text="Posture Score",
                     font=F["card_sub"](), text_color=C["t2"]).pack(pady=(0, PAD_SM))
        ctk.CTkLabel(ring_card, text=label,
                     font=F["meta"](), text_color=C["t3"]).pack(pady=(0, PAD_MD))

        # 2×2 stat grid
        grid = ctk.CTkFrame(hero_row, fg_color="transparent")
        grid.pack(side="left", fill="both", expand=True)
        last = audit.entries[0]["timestamp"][:10] if audit.entries else "—"
        stat_vals = [
            (str(len(ALL_TOOLS)),       "Scripts",    C["accent"]),
            (str(st["total"]) or "—",   "Total Runs", C["accent2"]),
            (str(st["success"]) or "—", "Passed",     C["green"]),
            (last,                       "Last Run",   C["yellow"]),
        ]
        for i, (val, lbl, col) in enumerate(stat_vals):
            card = GlassCard(grid)
            card.grid(row=i // 2, column=i % 2,
                      padx=PAD_SM // 2, pady=PAD_SM // 2, sticky="nsew")
            grid.columnconfigure(i % 2, weight=1)
            grid.rowconfigure(i // 2, weight=1)
            ctk.CTkLabel(card, text=val,
                         font=F["page_title"](), text_color=col).pack(pady=(PAD_MD, 0))
            ctk.CTkLabel(card, text=lbl,
                         font=F["meta"](), text_color=C["t3"]).pack(pady=(0, PAD_MD))

        pg.divider()

        # ── NIST chip cloud ───────────────────────────────────────
        ctk.CTkLabel(p, text="NIST SP 800-53 Coverage",
                     font=F["h2"](), text_color=C["t1"]).pack(anchor="w", pady=(0, PAD_SM))
        from core.constants import NIST_MAP
        families: dict[str, list] = {}
        for ctrl in sorted({c for cs in NIST_MAP.values() for c in cs}):
            families.setdefault(ctrl.split("-")[0], []).append(ctrl)
        cloud = tk.Frame(p, bg=C["bg2"])
        cloud.pack(fill="x", pady=(0, PAD_SM))
        for fam, ctrls in sorted(families.items()):
            chip = tk.Label(cloud, text=f"  {fam} ({len(ctrls)})  ",
                            font=("Courier", scaled(9), "bold"),
                            bg=C["bg5"], fg=C["accent2"],
                            padx=scaled(4), pady=scaled(3))
            chip.pack(side="left", padx=scaled(3), pady=scaled(3))
            names = "\n".join(f"{c}: {NIST_CONTROL_NAMES.get(c,'')}" for c in ctrls)
            Tooltip(chip, names)

        pg.divider()

        # ── Workflow steps ────────────────────────────────────────
        ctk.CTkLabel(p, text="Recommended Workflow",
                     font=F["h2"](), text_color=C["t1"]).pack(anchor="w", pady=(0, PAD_SM))
        steps = [
            ("01", "Run as Administrator / root",              C["yellow"]),
            ("02", f"Click ⚡ Run All ({len(ALL_TOOLS)}) Scripts", C["accent"]),
            ("03", "Green = pass  ·  Red = fix required",      C["green"]),
            ("04", "Check Audit Log for full timestamped record", C["accent2"]),
            ("05", "Generate PDF Report for compliance filing", C["purple"]),
            ("06", "Schedule monthly re-run to maintain posture", C["t2"]),
        ]
        sf = tk.Frame(p, bg=C["bg2"]); sf.pack(fill="x")
        for i, (num, txt, col) in enumerate(steps):
            row = tk.Frame(sf, bg=C["bg2"]); row.pack(fill="x", pady=scaled(2))
            dot_col = tk.Frame(row, bg=C["bg2"], width=scaled(44))
            dot_col.pack(side="left", fill="y")
            tk.Label(dot_col, text=num, font=("Courier", scaled(12), "bold"),
                     bg=C["bg4"], fg=col, width=2,
                     padx=scaled(8), pady=scaled(6)).pack(pady=scaled(2))
            if i < len(steps) - 1:
                tk.Frame(dot_col, bg=C["border2"],
                         width=scaled(2), height=scaled(8)).pack()
            step_card = tk.Frame(row, bg=C["bg3"], pady=scaled(10), padx=PAD_MD)
            step_card.pack(side="left", fill="x", expand=True)
            tk.Label(step_card, text=txt,
                     font=(platform.system() == "Darwin" and "SF Pro Display" or "Segoe UI",
                           scaled(12)), bg=C["bg3"], fg=C["t1"],
                     anchor="w").pack(anchor="w")

        pg.divider()

        # ── Recent activity ───────────────────────────────────────
        ctk.CTkLabel(p, text="Recent Activity",
                     font=F["h2"](), text_color=C["t1"]).pack(anchor="w", pady=(0, PAD_SM))
        if not audit.entries:
            pg.empty_state("📝", "No activity yet",
                           "Run your first script to see results here.",
                           cta_text="Go to Run All",
                           cta_cmd=lambda: self._nav("run_all"))
        else:
            for e in audit.get_entries(limit=8):
                row = GlassCard(p, hoverable=False)
                row.pack(fill="x", pady=scaled(2))
                StatusDot(row, e["status"]).pack(
                    side="left", padx=(PAD_MD, PAD_SM), pady=PAD_MD)
                ctk.CTkLabel(row, text=e["tool_name"],
                             font=F["card_title"](), text_color=C["t1"]).pack(side="left")
                nist = ", ".join(e.get("nist", [])[:3])
                ctk.CTkLabel(row, text=nist,
                             font=F["meta"](), text_color=C["t3"]).pack(
                    side="left", padx=PAD_SM)
                ctk.CTkLabel(row, text=e["timestamp"][:16],
                             font=F["meta"](), text_color=C["t3"]).pack(
                    side="right", padx=PAD_MD)
        pg.footer()

    # ══════════════════════════════════════════════════════════════════
    # Run All — Warp-style
    # ══════════════════════════════════════════════════════════════════
    def _page_run_all(self):
        pg = _PageBase(self._content, self)
        pg.header(f"⚡  Run All {len(ALL_TOOLS)} Scripts",
                  "Sequential NIST hardening — changes applied live")
        p = self._content

        # Warning banner
        warn = GlassCard(p, hoverable=False,
                         fg_color=C["yellow"] + "12",
                         border_color=C["yellow"] + "40")
        warn.pack(fill="x", pady=(0, PAD_MD))
        ctk.CTkLabel(warn,
                     text=("⚠  Applies system changes. Run as Administrator/root.\n"
                           "   High-risk scripts require confirmation before executing."),
                     font=F["card_sub"](), text_color=C["yellow"],
                     justify="left").pack(anchor="w", padx=PAD_MD, pady=PAD_MD)

        # Controls
        ctrl = ctk.CTkFrame(p, fg_color="transparent")
        ctrl.pack(fill="x", pady=(0, PAD_SM))

        self._ra_status = ctk.StringVar(value="Ready")
        run_btn = ctk.CTkButton(ctrl,
                                text=f"▶  Run All {len(ALL_TOOLS)}",
                                font=F["button"](),
                                fg_color=C["accent"], hover_color=C["adim"],
                                text_color=C["bg0"], height=scaled(46),
                                width=scaled(210), corner_radius=scaled(10))
        run_btn.pack(side="left", padx=(0, PAD_SM))

        self._elapsed_var = ctk.StringVar(value="")
        ctk.CTkLabel(ctrl, textvariable=self._elapsed_var,
                     font=F["term"](), text_color=C["t3"]).pack(side="left", padx=PAD_SM)
        ctk.CTkLabel(ctrl, textvariable=self._ra_status,
                     font=F["card_sub"](), text_color=C["t2"]).pack(side="left", padx=PAD_SM)

        prog = AnimatedProgress(p)
        prog.pack(fill="x", pady=(0, PAD_MD))

        # Warp-style block log
        log_scroll = ctk.CTkScrollableFrame(p, fg_color="transparent", height=scaled(420))
        log_scroll.pack(fill="x")

        tool_bars:   dict[str, tk.Frame]      = {}
        tool_status: dict[str, ctk.CTkLabel]  = {}
        tool_terms:  dict[str, ColorTerminal] = {}
        tool_blocks: dict[str, ctk.CTkFrame]  = {}
        tool_error_payloads: dict[str, list[dict]] = {}  # Item 3: stash per-tool dict emits

        for tool in ALL_TOOLS:
            block = ctk.CTkFrame(log_scroll, fg_color=C["bg3"],
                                  corner_radius=scaled(8), border_width=1,
                                  border_color=C["border"])
            block.pack(fill="x", pady=scaled(2))

            bar = tk.Frame(block, bg=C["t3"], width=scaled(3))
            bar.pack(side="left", fill="y")
            tool_bars[tool.id] = bar

            inner = ctk.CTkFrame(block, fg_color="transparent")
            inner.pack(side="left", fill="x", expand=True)

            hrow = ctk.CTkFrame(inner, fg_color="transparent")
            hrow.pack(fill="x", padx=PAD_SM, pady=scaled(8))
            ctk.CTkLabel(hrow, text=tool.icon, font=F["card_title"](),
                         width=scaled(28)).pack(side="left")
            ctk.CTkLabel(hrow, text=tool.name, font=F["card_title"](),
                         text_color=C["t1"]).pack(side="left", padx=scaled(6))
            ctk.CTkLabel(hrow, text=", ".join(tool.nist[:2]),
                         font=F["meta"](), text_color=C["t3"]).pack(side="left", padx=PAD_SM)

            st_lbl = ctk.CTkLabel(hrow, text="PENDING",
                                   font=F["badge"](), text_color=C["t3"])
            st_lbl.pack(side="right", padx=PAD_SM)
            tool_status[tool.id] = st_lbl

            term = ColorTerminal(inner, height=scaled(70))
            tool_terms[tool.id]  = term
            tool_blocks[tool.id] = block

        # Floating stop bar
        stop_bar = ctk.CTkFrame(p, fg_color=C["bg4"], corner_radius=0, height=scaled(52))
        stop_bar.pack(fill="x", side="bottom")
        stop_btn = ctk.CTkButton(stop_bar, text="■  Stop",
                                  font=F["button"](),
                                  fg_color=C["red"] + "33",
                                  hover_color=C["red"] + "55",
                                  text_color=C["red"],
                                  height=scaled(38), width=scaled(130),
                                  corner_radius=scaled(8), state="disabled",
                                  command=lambda: self._run_all_stop.set())
        stop_btn.pack(side="left", padx=PAD_MD, pady=scaled(7))
        ctk.CTkLabel(stop_bar, text="Stops after current script completes",
                     font=F["meta"](), text_color=C["t3"]).pack(side="left")

        start_time: list[float] = [0.0]

        def _tick():
            if not self._run_all_stop.is_set() and start_time[0]:
                el = int(time.time() - start_time[0])
                self._elapsed_var.set(f"{el//60:02d}:{el%60:02d}")
                p.after(500, _tick)

        def _per_emit(tid: str, line, level: str):
            # Item 3: intercept structured dict payloads — show title+fix in terminal, stash for toast
            if isinstance(line, dict):
                tool_error_payloads.setdefault(tid, []).append(line)
                term = tool_terms.get(tid)
                if term:
                    term.append(
                        f"  {'ERR' if level == 'err' else 'WARN'}  "
                        f"{line.get('title', 'Error occurred')}",
                        level,
                    )
                    fix = line.get("fix", "")
                    if fix:
                        term.append(f"  →  {fix.splitlines()[0]}", "info")
            else:
                # Fix #63: append() now handles after() internally — just call it directly
                term = tool_terms.get(tid)
                if term:
                    term.append(line, level)

        def _per_done(tid: str, ok: bool, detail: str):
            def _update():
                col  = C["green"] if ok else C["red"]
                icon = "PASS" if ok else "FAIL"
                b = tool_bars.get(tid)
                lbl = tool_status.get(tid)
                if b:  b.configure(bg=col)
                if lbl:  lbl.configure(text=icon, text_color=col)
                term = tool_terms.get(tid)
                if term:
                    term.pack(fill="x", padx=PAD_SM, pady=(0, PAD_SM))
                # Item 3: show toast for any structured error payloads from this tool
                for payload in tool_error_payloads.get(tid, []):
                    self._show_toast(payload)
            self.after(0, _update)

        def _all_done(passed: int, failed: int):
            def _finish():
                self._elapsed_var.set(f"{int(time.time()-start_time[0])}s total")
                self._ra_status.set(
                    f"Complete — {passed}/{passed+failed} passed, {failed} failed")
                run_btn.configure(state="normal")
                stop_btn.configure(state="disabled")
                prog.set_target(1.0)
            self.after(0, _finish)


        def _start():
            # Fix #69: always clear stop event before new run
            self._run_all_stop.clear()
            run_btn.configure(state="disabled")
            stop_btn.configure(state="normal")
            prog.set_target(0.0)
            start_time[0] = time.time()
            self._elapsed_var.set("00:00")
            _tick()

            for tid, bar in tool_bars.items():
                bar.configure(bg=C["t3"])
            for tid, lbl in tool_status.items():
                lbl.configure(text="WAITING", text_color=C["t3"])

            tool_ids = [
                t.id for t in ALL_TOOLS
                # Fix #59: respect disabled_tools from config — set in Settings page
                if t.id not in set(load_config_dict().get("disabled_tools", []))
            ]

            def _mark_running(tid: str) -> None:
                def _ui():
                    b = tool_bars.get(tid); lbl = tool_status.get(tid)
                    if b: b.configure(bg=C["indigo"])
                    if lbl: lbl.configure(text="RUNNING", text_color=C["indigo"])
                self.after(0, _ui)

            def _progress(fraction: float) -> None:
                idx = int(fraction * len(tool_ids))
                self.after(0, lambda c=idx: self._ra_status.set(
                    f"Running {c}/{len(tool_ids)}"))
                prog.set_target(fraction)

            # Fix #57: use runner.run_all — single execution path for UI and headless.
            # Provides per-tool timeout, _validate_result, _make_emit, and toast routing.
            # Previously _page_run_all had its own _worker that bypassed all of these.
            run_all(
                tool_ids,
                output_cb=lambda line, lv: None,   # general fallback; routing via tool_output_cb
                per_tool_done_cb=_per_done,
                all_done_cb=_all_done,
                stop_event=self._run_all_stop,
                toast_cb=self._show_toast,
                per_tool_start_cb=_mark_running,
                tool_output_cb=_per_emit,
                progress_cb=_progress,
            )

        run_btn.configure(command=_start)
        pg.footer()

    # ══════════════════════════════════════════════════════════════════
    # Section page (tool group)
    # ══════════════════════════════════════════════════════════════════
    def _page_section(self, section_id: str):
        pg  = _PageBase(self._content, self)
        title = SECTIONS[section_id]
        tools = tools_by_section(section_id)
        pg.header(title, f"{len(tools)} tools in this section")
        p = self._content

        ctk.CTkButton(p, text=f"▶  Run All {len(tools)} in This Section",
                       font=F["button_sm"](),
                       fg_color=C["bg4"], hover_color=C["bg5"],
                       text_color=C["accent"], height=scaled(38),
                       corner_radius=scaled(8),
                       command=lambda: self._nav("run_all")).pack(
            anchor="w", pady=(0, PAD_MD))

        group = GlassCard(p, hoverable=False, fg_color=C["bg3"],
                          border_color=C["border"])
        group.pack(fill="x")

        for i, tool in enumerate(tools):
            self._tool_row(group, tool)
            if i < len(tools) - 1:
                ctk.CTkFrame(group, fg_color=C["border"], height=1).pack(fill="x", padx=PAD_MD)

        pg.footer()

    def _tool_row(self, parent, tool):
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=PAD_SM, pady=scaled(4))

        ic = ctk.CTkFrame(row, fg_color=C["glass"], corner_radius=scaled(20),
                           width=scaled(40), height=scaled(40),
                           border_width=1, border_color=C["glass_b"])
        ic.pack(side="left", padx=(PAD_SM, PAD_MD))
        ic.pack_propagate(False)
        ctk.CTkLabel(ic, text=tool.icon, font=F["card_title"]()).pack(expand=True)

        info = ctk.CTkFrame(row, fg_color="transparent")
        info.pack(side="left", fill="x", expand=True)
        ctk.CTkLabel(info, text=tool.name, font=F["card_title"](),
                     text_color=C["t1"], anchor="w").pack(anchor="w")
        ctk.CTkLabel(info, text=tool.short, font=F["card_sub"](),
                     text_color=C["t2"], anchor="w").pack(anchor="w")

        right = ctk.CTkFrame(row, fg_color="transparent")
        right.pack(side="right")

        last_run = audit.last_run(tool.id)
        dot = StatusDot(right, last_run["status"] if last_run else "never")
        dot.pack(side="right", padx=(PAD_SM, PAD_MD), pady=scaled(4))
        Tooltip(dot, (f"Last: {last_run['timestamp'][:16]}\n{last_run['status']}"
                      if last_run else "Never run"))

        RiskBadge(right, tool.risk).pack(side="right", padx=PAD_SM)

        for ctrl in tool.nist[:2]:
            lbl = ctk.CTkLabel(right, text=f" {ctrl} ", font=F["badge"](),
                               fg_color=C["accent2"] + "18", text_color=C["accent2"],
                               corner_radius=scaled(4))
            lbl.pack(side="right", padx=scaled(2))
            Tooltip(lbl, f"{ctrl}: {NIST_CONTROL_NAMES.get(ctrl,'')}")

        for w in [row, info, ic]:
            w.bind("<Button-1>", lambda _, t=tool: self._page_tool_detail(t))
        row.configure(cursor="hand2")

    def _page_tool_detail(self, tool):
        """Full-page drill-down for a single tool. Fix #68: _done uses self.after(0)."""
        for w in self._content.winfo_children():
            w.destroy()
        p = self._content

        ctk.CTkButton(p, text="← Back", font=F["button_sm"](),
                       fg_color=C["bg4"], hover_color=C["bg5"],
                       text_color=C["t2"], height=scaled(32), width=scaled(80),
                       corner_radius=scaled(6),
                       command=lambda: self._nav(tool.section)).pack(
            anchor="w", pady=(PAD_MD, 0))

        header_card = GlassCard(p, hoverable=False)
        header_card.pack(fill="x", pady=PAD_SM)
        hrow = ctk.CTkFrame(header_card, fg_color="transparent")
        hrow.pack(fill="x", padx=PAD_XL, pady=PAD_LG)

        big_ic = ctk.CTkFrame(hrow, fg_color=C["glass"], corner_radius=scaled(28),
                               width=scaled(56), height=scaled(56),
                               border_width=1, border_color=C["glass_b"])
        big_ic.pack(side="left", padx=(0, PAD_LG)); big_ic.pack_propagate(False)
        ctk.CTkLabel(big_ic, text=tool.icon,
                     font=ctk.CTkFont(size=scaled(28))).pack(expand=True)

        tc = ctk.CTkFrame(hrow, fg_color="transparent")
        tc.pack(side="left", fill="x", expand=True)
        ctk.CTkLabel(tc, text=tool.name, font=F["page_title"](),
                     text_color=C["t1"], anchor="w").pack(anchor="w")
        ctk.CTkLabel(tc, text=tool.short, font=F["card_sub"](),
                     text_color=C["t2"], anchor="w").pack(anchor="w")

        rc = ctk.CTkFrame(hrow, fg_color="transparent")
        rc.pack(side="right")
        RiskBadge(rc, tool.risk).pack(pady=scaled(2))
        ctk.CTkLabel(rc, text=f"CIS {tool.cis}",
                     font=F["meta"](), text_color=C["t3"]).pack()

        desc_card = GlassCard(p, hoverable=False)
        desc_card.pack(fill="x", pady=scaled(4))
        ctk.CTkLabel(desc_card, text=tool.desc, font=F["card_sub"](),
                     text_color=C["t2"],
                     wraplength=scaled(760), justify="left").pack(
            anchor="w", padx=PAD_XL, pady=PAD_LG)

        # how_to_fix card — always shown (all tools have it), green-tinted
        # Fix #60: filter steps to current OS — non-technical users don't need
        # Windows registry instructions when they're on macOS.
        if tool.how_to_fix:
            _os_prefix = {
                "Windows": "Windows",
                "Darwin":  "macOS",
                "Linux":   "Linux",
            }.get(OS_NAME, "")

            def _step_relevant(step: str) -> bool:
                """Return True if step applies to the current OS or has no OS prefix."""
                for prefix in ("Windows:", "macOS:", "Linux:"):
                    if step.startswith(prefix):
                        return step.startswith(_os_prefix + ":")
                return True  # no platform prefix — always show

            fix_steps = [
                s.strip() for s in tool.how_to_fix.split("\n")
                if s.strip() and _step_relevant(s.strip())
            ]

            if fix_steps:
                fix_card = GlassCard(p, hoverable=False,
                                      fg_color=C["green"] + "0C",
                                      border_color=C["green"] + "28")
                fix_card.pack(fill="x", pady=scaled(4))
                ctk.CTkLabel(fix_card, text="💡  How to fix issues found by this tool",
                             font=F["h2"](), text_color=C["green"]).pack(
                    anchor="w", padx=PAD_XL, pady=(PAD_MD, 0))
                for step in fix_steps:
                    row = ctk.CTkFrame(fix_card, fg_color="transparent")
                    row.pack(fill="x", padx=PAD_XL, pady=scaled(2))
                    # Strip the "macOS: " / "Windows: " prefix before rendering
                    for prefix in ("Windows:", "macOS:", "Linux:"):
                        if step.startswith(prefix):
                            step = step[len(prefix):].strip()
                            break
                    is_numbered = len(step) > 2 and step[0].isdigit() and step[1] == "."
                    bullet = step[:2] if is_numbered else "→ "
                    body   = step[2:].strip() if is_numbered else step
                    ctk.CTkLabel(row, text=bullet, font=F["badge"](),
                                 text_color=C["green"], width=scaled(24)).pack(side="left")
                    ctk.CTkLabel(row, text=body, font=F["card_sub"](),
                                 text_color=C["t1"], wraplength=scaled(720),
                                 justify="left", anchor="w").pack(side="left", padx=scaled(6))
                ctk.CTkFrame(fix_card, height=PAD_MD, fg_color="transparent").pack()

        meta_card = GlassCard(p, hoverable=False, fg_color=C["bg2"])
        meta_card.pack(fill="x", pady=scaled(4))
        mr = ctk.CTkFrame(meta_card, fg_color="transparent")
        mr.pack(fill="x", padx=PAD_XL, pady=PAD_MD)
        for ctrl in tool.nist:
            lbl = ctk.CTkLabel(mr, text=f" {ctrl} ", font=F["badge"](),
                               fg_color=C["accent"] + "18", text_color=C["accent"],
                               corner_radius=scaled(4))
            lbl.pack(side="left", padx=scaled(3))
            Tooltip(lbl, f"{ctrl}: {NIST_CONTROL_NAMES.get(ctrl,'')}")

        run_card = GlassCard(p, hoverable=False)
        run_card.pack(fill="x", pady=scaled(4))
        run_row = ctk.CTkFrame(run_card, fg_color="transparent")
        run_row.pack(fill="x", padx=PAD_XL, pady=PAD_MD)

        run_btn = ctk.CTkButton(run_row, text=f"▶  Run: {tool.name}",
                                 font=F["button"](),
                                 fg_color=C["accent"], hover_color=C["adim"],
                                 text_color=C["bg0"], height=scaled(46),
                                 corner_radius=scaled(10))
        run_btn.pack(side="left")

        last_var = ctk.StringVar(value=self._last_run_str(tool.id))
        ctk.CTkLabel(run_row, textvariable=last_var,
                     font=F["meta"](), text_color=C["t3"]).pack(side="left", padx=PAD_MD)

        term = ColorTerminal(p, height=scaled(240))
        term.pack(fill="x", pady=scaled(4))

        def _run():
            if tool.confirm:
                if not messagebox.askyesno(
                    "Confirm",
                    f"{tool.name} makes significant system changes.\n"
                    "Ensure you have a recovery plan.\n\nContinue?",
                ):
                    return
            term.clear()
            term.append(f"  {tool.name}\n  {'─'*52}", "info")
            run_btn.configure(state="disabled", text="⏳  Running…",
                              fg_color=C["bg4"], text_color=C["t3"])

            # Fix #68: _done is called from background thread; all tk calls via self.after(0)
            def _done(ok: bool, detail: str, dur: float):
                def _finish():
                    term.append(f"\n  {'─'*52}", "info")
                    term.append(
                        f"  {'✓ Completed' if ok else '✗ Finished with issues'}  ({dur:.1f}s)",
                        "ok" if ok else "err"
                    )
                    run_btn.configure(
                        state="normal",
                        text=f"▶  Run: {tool.name}",
                        fg_color=C["green"] if ok else C["red"],
                        text_color=C["bg0"],
                    )
                    last_var.set(self._last_run_str(tool.id))
                    if ok: run_card.flash_success()
                    else:  run_card.flash_error()
                self.after(0, _finish)   # fix #68: schedule on main thread

            run_script(
                tool.id, term.append, _done,
                toast_cb=lambda p: self.after(0, lambda pay=p: self._show_toast(pay)),
            )

        run_btn.configure(command=_run)

    def _last_run_str(self, tool_id: str) -> str:
        e = audit.last_run(tool_id)
        return f"Last: {e['timestamp'][:16]}  ·  {e['status']}" if e else "Never run"

    # ══════════════════════════════════════════════════════════════════
    # Audit log
    # ══════════════════════════════════════════════════════════════════
    def _page_audit(self):
        pg = _PageBase(self._content, self)
        p  = self._content

        h = ctk.CTkFrame(p, fg_color="transparent")
        h.pack(fill="x", pady=(PAD_XL, 0))
        ctk.CTkLabel(h, text="📝  Audit Log",
                     font=F["page_title"](), text_color=C["t1"]).pack(side="left")

        btns = ctk.CTkFrame(h, fg_color="transparent")
        btns.pack(side="right")
        ctk.CTkButton(btns, text="Export CSV", font=F["button_sm"](),
                       fg_color=C["bg4"], hover_color=C["border"],
                       text_color=C["accent2"], height=scaled(32),
                       corner_radius=scaled(6),
                       command=lambda: self._export_csv()).pack(side="left", padx=scaled(4))
        ctk.CTkButton(btns, text="Clear Log", font=F["button_sm"](),
                       fg_color=C["bg4"], hover_color=C["border"],
                       text_color=C["red"], height=scaled(32),
                       corner_radius=scaled(6),
                       command=self._clear_log).pack(side="left", padx=scaled(4))

        pg.divider()

        if not audit.entries:
            pg.empty_state("📝", "No audit entries",
                           "Run a script to begin your audit trail.",
                           cta_text="Run All Scripts",
                           cta_cmd=lambda: self._nav("run_all"))
            return

        # Table header
        th = ctk.CTkFrame(p, fg_color=C["bg4"], corner_radius=scaled(6))
        th.pack(fill="x", pady=(0, scaled(4)))
        for col_txt in ["Timestamp", "Tool", "Status", "NIST", "Detail"]:
            ctk.CTkLabel(th, text=col_txt, font=F["badge"](), text_color=C["t3"],
                         anchor="w").pack(side="left", padx=PAD_MD, pady=PAD_SM,
                                          expand=True, fill="x")

        for i, e in enumerate(audit.entries):
            sc = (C["green"] if e["status"] == "success" else
                  C["yellow"] if e["status"] == "warning" else C["red"])
            row_bg = C["bg3"] if i % 2 == 0 else C["bg2"]
            row = ctk.CTkFrame(p, fg_color=row_bg, corner_radius=scaled(4))
            row.pack(fill="x", pady=scaled(1))

            for text, font_key, color, expand in [
                (e["timestamp"][:19], "meta",       C["t2"],  True),
                (e["tool_name"][:28], "card_title", C["t1"],  True),
            ]:
                ctk.CTkLabel(row, text=text, font=F[font_key](),
                             text_color=color, anchor="w").pack(
                    side="left", padx=PAD_MD, pady=PAD_SM, expand=expand, fill="x")

            ctk.CTkLabel(row, text=f" {e['status'].upper()} ", font=F["badge"](),
                         text_color=sc, fg_color=sc + "22",
                         corner_radius=scaled(3)).pack(
                side="left", padx=PAD_SM, pady=PAD_SM)

            nist_val = e.get("nist", [])
            nist_str = ", ".join(nist_val[:2]) if isinstance(nist_val, list) else str(nist_val)[:20]
            ctk.CTkLabel(row, text=nist_str, font=F["meta"](),
                         text_color=C["accent2"], anchor="w").pack(
                side="left", padx=PAD_SM, expand=True, fill="x")
            ctk.CTkLabel(row, text=e.get("detail","")[:48], font=F["meta"](),
                         text_color=C["t3"], anchor="w").pack(
                side="left", padx=PAD_MD, fill="x", expand=True)

        pg.footer()

    def _export_csv(self):
        path = filedialog.asksaveasfilename(
            parent=self,   # fix #44: parent explicitly set
            defaultextension=".csv",
            filetypes=[("CSV", "*.csv")],
            initialfile=f"ForceStack_Audit_{datetime.date.today()}.csv",
        )
        if path:
            try:
                audit.export_csv(path)
                messagebox.showinfo("Exported", f"Audit log saved:\n{path}", parent=self)
            except Exception as e:
                messagebox.showerror("Export Failed", str(e), parent=self)

    def _clear_log(self):
        if messagebox.askyesno("Clear Log",
                               "Delete all audit entries?\nThis cannot be undone.",
                               parent=self):
            audit.clear()
            self._nav("audit")

    # ══════════════════════════════════════════════════════════════════
    # Report page
    # ══════════════════════════════════════════════════════════════════
    def _page_report(self):
        pg = _PageBase(self._content, self)
        pg.header("📄  Generate Report", "Export compliance documentation")
        p  = self._content

        st    = audit.stats()
        score = audit.compliance_score(len(ALL_TOOLS))

        for val, lbl, col in [
            (f"{score}/100", "Posture Score", C["accent"]),
            (str(st["total"]),   "Total Runs",   C["accent2"]),
            (str(st["success"]), "Passed",        C["green"]),
            (str(st["errors"]),  "Errors",        C["red"]),
        ]:
            row = GlassCard(p, hoverable=False)
            row.pack(fill="x", pady=scaled(3))
            ctk.CTkLabel(row, text=val, font=F["page_title"](), text_color=col,
                         width=scaled(80)).pack(side="left", padx=PAD_XL, pady=PAD_MD)
            ctk.CTkLabel(row, text=lbl, font=F["card_title"](),
                         text_color=C["t1"]).pack(side="left")

        pg.divider()

        status_var = ctk.StringVar(value="")
        status_lbl = ctk.CTkLabel(p, textvariable=status_var,
                                   font=F["card_sub"](), text_color=C["t2"])

        btn_row = ctk.CTkFrame(p, fg_color="transparent")
        btn_row.pack(anchor="w", pady=scaled(4))

        for lbl, func, col, hover in [
            ("📄  Export TXT", generate_txt, C["accent2"], C["a2dim"]),
            ("📋  Export PDF", generate_pdf, C["accent"],  C["adim"]),
        ]:
            def _gen(f=func, name=lbl):
                status_lbl.pack(anchor="w", pady=scaled(4))
                status_var.set(f"  Generating {name}…")
                try:
                    path = f()
                    status_var.set(f"  ✓  Saved: {path}")
                    if messagebox.askyesno("Open?", "Report saved.\nOpen file location?",
                                           parent=self):
                        if OS_NAME == "Windows":
                            subprocess.Popen(["explorer", "/select,", path])
                        elif OS_NAME == "Darwin":
                            subprocess.Popen(["open", "-R", path])
                        else:
                            subprocess.Popen(["xdg-open", str(Path(path).parent)])
                except PDFUnavailable as e:
                    # Fix #27: inform user format degraded
                    status_var.set(f"  ⚠  reportlab not installed — saved as TXT: {e.txt_path}")
                    messagebox.showwarning(
                        "PDF Unavailable",
                        f"reportlab is not installed.\n"
                        f"Report saved as TXT instead:\n{e.txt_path}\n\n"
                        f"Install with: pip install reportlab",
                        parent=self,
                    )
                except Exception as e:
                    status_var.set(f"  ✗  Error: {e}")
            ctk.CTkButton(btn_row, text=lbl, font=F["button"](),
                           fg_color=col, hover_color=hover,
                           text_color=C["bg0"], height=scaled(44),
                           corner_radius=scaled(10), command=_gen).pack(
                side="left", padx=(0, PAD_SM))

        ctk.CTkLabel(p, text="  ℹ  PDF requires: pip install reportlab",
                     font=F["meta"](), text_color=C["t3"]).pack(anchor="w", pady=scaled(8))
        pg.footer()

    # ══════════════════════════════════════════════════════════════════
    # Settings
    # ══════════════════════════════════════════════════════════════════
    def _page_settings(self):
        pg = _PageBase(self._content, self)
        pg.header("⚙  Settings", "Changes are saved to ~/.forcestack/config.json")
        p  = self._content

        # Fix #59: load current saved values so fields show what's actually persisted
        cfg = load_config_dict()
        disabled = set(cfg.get("disabled_tools", []))

        from core.constants import REPORTS_DIR
        # ── Numeric / string settings ──────────────────────────────
        field_vars: dict[str, ctk.StringVar] = {}
        fields = [
            ("timeout_secs",  "Idle Timeout (seconds)",         str(cfg.get("timeout_secs", "600"))),
            ("min_pw_len",    "Minimum Password Length",        str(cfg.get("min_pw_len",   "15"))),
            ("max_pw_age",    "Maximum Password Age (days)",    str(cfg.get("max_pw_age",   "365"))),
            ("reports_dir",   "Report Output Directory",        str(cfg.get("reports_dir",  str(REPORTS_DIR)))),
        ]
        for key, label, default in fields:
            row = GlassCard(p, hoverable=False)
            row.pack(fill="x", pady=scaled(4))
            ctk.CTkLabel(row, text=label, font=F["card_title"](),
                         text_color=C["t1"], anchor="w").pack(
                side="left", padx=PAD_XL, pady=PAD_LG)
            var = ctk.StringVar(value=default)
            field_vars[key] = var
            ctk.CTkEntry(row, textvariable=var, font=F["card_sub"](),
                          fg_color=C["bg4"], border_color=C["border"],
                          text_color=C["t1"], width=scaled(260)).pack(
                side="right", padx=PAD_XL)

        # ── Script selection for Run All ───────────────────────────
        ctk.CTkLabel(p, text="Script Selection for Run All",
                     font=F["h2"](), text_color=C["t1"]).pack(
            anchor="w", pady=(PAD_LG, scaled(4)))
        ctk.CTkLabel(p,
                     text="Unchecked tools are skipped during Run All. They can still be run individually.",
                     font=F["meta"](), text_color=C["t3"]).pack(
            anchor="w", pady=(0, PAD_SM))

        tool_vars: dict[str, ctk.BooleanVar] = {}
        for tool in ALL_TOOLS:
            row = GlassCard(p, hoverable=False)
            row.pack(fill="x", pady=scaled(2))
            var = ctk.BooleanVar(value=(tool.id not in disabled))
            tool_vars[tool.id] = var
            ctk.CTkCheckBox(row, text=tool.name, variable=var,
                             font=F["card_sub"](), text_color=C["t1"],
                             fg_color=C["accent"], hover_color=C["adim"]).pack(
                side="left", padx=PAD_XL, pady=PAD_SM)
            RiskBadge(row, tool.risk).pack(side="right", padx=PAD_XL)

        # ── Onboarding replay ──────────────────────────────────────
        replay_card = GlassCard(p, hoverable=False,
                                 fg_color=C["accent"] + "0A",
                                 border_color=C["accent"] + "25")
        replay_card.pack(fill="x", pady=(PAD_LG, scaled(4)))
        replay_row = ctk.CTkFrame(replay_card, fg_color="transparent")
        replay_row.pack(fill="x", padx=PAD_XL, pady=PAD_MD)
        ctk.CTkLabel(replay_row, text="Setup Wizard",
                     font=F["card_title"](), text_color=C["t1"]).pack(side="left")
        ctk.CTkLabel(replay_row,
                     text="  Revisit the guided onboarding to see recommended scan order",
                     font=F["meta"](), text_color=C["t3"]).pack(side="left")

        def _replay_onboarding():
            # Remove sentinel so wizard treats this as first run, then show it
            try:
                ONBOARD_STATE.unlink(missing_ok=True)
            except Exception:
                pass
            self.after(100, self._show_onboarding)

        ctk.CTkButton(
            replay_row, text="Re-run wizard →",
            font=F["button_sm"](),
            fg_color=C["accent"] + "22", hover_color=C["accent"] + "40",
            text_color=C["accent"], height=scaled(32),
            corner_radius=scaled(6),
            command=_replay_onboarding,
        ).pack(side="right")

        # ── Accessibility ──────────────────────────────────────────
        ctk.CTkLabel(p, text="Accessibility", font=F["h2"](), text_color=C["t1"]).pack(
            anchor="w", pady=(PAD_LG, scaled(4)))
        ctk.CTkLabel(p, text="Make the interface easier to read. Changes take effect after restarting the app.",
                     font=F["meta"](), text_color=C["t3"]).pack(anchor="w", pady=(0, PAD_SM))

        hc_row = GlassCard(p, hoverable=False)
        hc_row.pack(fill="x", pady=scaled(4))
        hc_var = ctk.BooleanVar(value=bool(cfg.get("high_contrast", False)))
        ctk.CTkCheckBox(hc_row, text="High-contrast text", variable=hc_var,
                        font=F["card_sub"](), text_color=C["t1"],
                        fg_color=C["accent"], hover_color=C["adim"]).pack(
            side="left", padx=PAD_XL, pady=PAD_MD)
        ctk.CTkLabel(hc_row, text="Brighter text and borders for low-vision readability",
                     font=F["meta"](), text_color=C["t3"]).pack(side="left")

        sc_row = GlassCard(p, hoverable=False)
        sc_row.pack(fill="x", pady=scaled(4))
        ctk.CTkLabel(sc_row, text="Text and interface size", font=F["card_title"](),
                     text_color=C["t1"], anchor="w").pack(side="left", padx=PAD_XL, pady=PAD_LG)
        scale_pct = int(round(float(cfg.get("ui_scale", 1.0)) * 100))
        scale_var = ctk.StringVar(value=f"{scale_pct}%")
        ctk.CTkSegmentedButton(sc_row, values=["100%", "125%", "150%", "175%"],
                               variable=scale_var, font=F["card_sub"]()).pack(
            side="right", padx=PAD_XL)

        # ── Apply button ───────────────────────────────────────────
        status_var = ctk.StringVar(value="")

        def _apply():
            updates: dict = {}
            # Numeric fields — validate before saving
            for key, _, _ in fields:
                raw = field_vars[key].get().strip()
                if key in ("timeout_secs", "min_pw_len", "max_pw_age"):
                    try:
                        updates[key] = int(raw)
                    except ValueError:
                        status_var.set(f"  ⚠  {key}: must be a whole number")
                        return
                else:
                    updates[key] = raw
            # Disabled tools list
            updates["disabled_tools"] = [
                tid for tid, var in tool_vars.items() if not var.get()
            ]
            # Accessibility
            updates["high_contrast"] = bool(hc_var.get())
            try:
                updates["ui_scale"] = max(1.0, min(1.75, int(scale_var.get().rstrip("%")) / 100.0))
            except ValueError:
                updates["ui_scale"] = 1.0
            save_config(updates)
            status_var.set(
                f"  ✓  Saved — {len(updates['disabled_tools'])} tools disabled. "
                "Restart to apply timeout, password, and accessibility changes."
            )

        apply_row = ctk.CTkFrame(p, fg_color="transparent")
        apply_row.pack(fill="x", pady=PAD_LG)
        ctk.CTkButton(
            apply_row, text="Apply and Save",
            font=F["button"](),
            fg_color=C["accent"], hover_color=C["adim"],
            text_color=C["bg0"], height=scaled(46),
            width=scaled(180), corner_radius=scaled(10),
            command=_apply,
        ).pack(side="left")
        ctk.CTkLabel(apply_row, textvariable=status_var,
                     font=F["meta"](), text_color=C["green"]).pack(
            side="left", padx=PAD_MD)

        pg.footer()

    # ══════════════════════════════════════════════════════════════════
    # Sentinel Probe — low-RAM AI-assisted NGAV sensor
    # ══════════════════════════════════════════════════════════════════
    def _page_probe(self):
        pg = _PageBase(self._content, self)
        pg.header("🛰  Sentinel Probe",
                  "Behaviour-based threat detection — catches the unknown, not just the known")
        p = self._content

        ExplainCard(
            p,
            title="What is the Sentinel Probe?",
            plain=(
                "Regular antivirus looks for viruses it already recognises. The Sentinel "
                "Probe is different: it watches how programs *behave* and flags anything "
                "that acts like an attack — even brand-new (\"zero-day\") or shape-shifting "
                "(\"polymorphic\") malware that has no known fingerprint. It's deliberately "
                "lightweight, so it barely uses any memory while it runs in the background."
            ),
            deeper=(
                "The probe samples running processes, live network connections, and your "
                "audit log on a timer, turning each snapshot into a numeric feature vector "
                "of behavioural signals. An unsupervised machine-learning model "
                "(scikit-learn IsolationForest, with a pure-Python robust-statistics "
                "fallback) learns what is normal for THIS machine, then flags deviations — "
                "and explains which signals were unusual and by how many standard "
                "deviations. On top of the model sit four explainable modules targeting "
                "modern frontiers: Agentic-Threat (machine-speed bursts and regular C2 "
                "beaconing), Memory-Defence (processes running from a deleted file — a "
                "fileless tell), Identity-Telemetry (trusted tools like PowerShell reaching "
                "out to the network — 'living off the land'), and Smart-Rollback (records "
                "exact changes in a durable journal so a malicious one can be reversed, and "
                "lets you quarantine a file by moving it aside rather than deleting it). "
                "An optional large-language-model layer can be plugged in to triage "
                "ambiguous cases; it is off by default and makes no network calls unless "
                "you install it."
            ),
        ).pack(fill="x", pady=(0, PAD_MD))

        # ── Status + controls row ──────────────────────────────────
        ctrl = GlassCard(p, hoverable=False)
        ctrl.pack(fill="x", pady=(0, PAD_MD))
        inner = ctk.CTkFrame(ctrl, fg_color="transparent")
        inner.pack(fill="x", padx=PAD_XL, pady=PAD_MD)

        state_var = ctk.StringVar()
        ram_var = ctk.StringVar()
        detail_var = ctk.StringVar()

        def _refresh_status():
            running = probe.running
            state_var.set("● MONITORING" if running else "○ STOPPED")
            ram_var.set(f"Probe data footprint: {probe.self_footprint_mb()} MB")
            detail_var.set(
                f"{probe.samples_taken} samples  ·  "
                f"AI model: {probe.ml_state} ({probe.ml_backend})  ·  "
                f"Telemetry: {probe.telemetry_mode()}  ·  "
                f"Auto-contain: {'ON' if probe.autonomous else 'off'}"
            )
            state_lbl.configure(text_color=C["green"] if running else C["t3"])

        state_lbl = ctk.CTkLabel(inner, textvariable=state_var,
                                 font=F["section_label"](), text_color=C["t3"])
        state_lbl.pack(side="left")
        meta_col = ctk.CTkFrame(inner, fg_color="transparent")
        meta_col.pack(side="left", padx=PAD_LG)
        ctk.CTkLabel(meta_col, textvariable=ram_var, font=F["meta"](),
                     text_color=C["accent2"]).pack(anchor="w")
        ctk.CTkLabel(meta_col, textvariable=detail_var, font=F["meta"](),
                     text_color=C["t3"]).pack(anchor="w")

        # live feed terminal + change journal
        feed = ColorTerminal(p, height=scaled(200))

        def _on_detection(det):
            def _ui():
                d = det.to_dict()
                lvl = {"critical": "err", "high": "err", "medium": "warn"}.get(d["band"], "info")
                feed.append(f"[{d['time']}] {d['band'].upper():8} {d['title']}", lvl)
                feed.append(f"           why: {det.why}", "info")
                if det.recommendation:
                    feed.append(f"           → {det.recommendation}", "info")
                if det.auto_action:
                    feed.append(f"           ⚙ {det.auto_action}", "warn")
                _refresh_status()
            self.after(0, _ui)

        def _start():
            try:
                probe.start()
                feed.append("Sentinel Probe started — watching processes, network, and audit log.", "ok")
            except Exception as e:
                feed.append(f"Could not start probe: {e}", "err")
            _refresh_status()

        def _stop():
            probe.stop()
            feed.append("Sentinel Probe stopped.", "warn")
            _refresh_status()

        def _toggle_auto():
            probe.set_autonomous(auto_var.get())
            feed.append(
                "Autonomous containment ENABLED — high-severity threats will be "
                "auto-suspended (reversible)." if auto_var.get()
                else "Autonomous containment disabled — the probe will only alert.",
                "warn" if auto_var.get() else "info")
            _refresh_status()

        btns = ctk.CTkFrame(inner, fg_color="transparent")
        btns.pack(side="right")
        ctk.CTkButton(btns, text="▶  Start", font=F["button_sm"](),
                      fg_color=C["green"], hover_color=C["adim"], text_color=C["bg0"],
                      height=scaled(36), width=scaled(90), corner_radius=scaled(8),
                      command=_start).pack(side="left", padx=scaled(4))
        ctk.CTkButton(btns, text="■  Stop", font=F["button_sm"](),
                      fg_color=C["bg5"], hover_color=C["red"], text_color=C["t1"],
                      height=scaled(36), width=scaled(90), corner_radius=scaled(8),
                      command=_stop).pack(side="left", padx=scaled(4))

        def _quarantine():
            path = filedialog.askopenfilename(parent=self, title="Choose a file to quarantine")
            if not path:
                return
            ok, msg = probe.quarantine_file(path)
            feed.append(("Quarantined (reversible): " if ok else "Quarantine failed: ") + msg,
                        "ok" if ok else "err")
            if ok:
                self.after(50, lambda: self._nav("probe"))   # refresh journal
            _refresh_status()

        ctk.CTkButton(btns, text="⊘  Quarantine…", font=F["button_sm"](),
                      fg_color=C["bg5"], hover_color=C["orange"], text_color=C["t1"],
                      height=scaled(36), width=scaled(120), corner_radius=scaled(8),
                      command=_quarantine).pack(side="left", padx=scaled(4))

        # opt-in autonomous toggle with a clear consent note
        auto_row = GlassCard(p, hoverable=False,
                             fg_color=C["orange"] + "0C", border_color=C["orange"] + "33")
        auto_row.pack(fill="x", pady=(0, PAD_MD))
        auto_var = ctk.BooleanVar(value=probe.autonomous)
        ctk.CTkCheckBox(auto_row, text="Let the probe automatically contain high-severity threats",
                        variable=auto_var, font=F["card_sub"](), text_color=C["t1"],
                        fg_color=C["orange"], hover_color=C["orange"] + "CC",
                        command=_toggle_auto).pack(side="left", padx=PAD_XL, pady=PAD_MD)
        ctk.CTkLabel(auto_row,
                     text="Containment = pause the process (reversible). Never deletes files. Needs admin/root.",
                     font=F["meta"](), text_color=C["t3"]).pack(side="left", padx=(0, PAD_XL))

        # ── Detection modules explainer grid ───────────────────────
        ctk.CTkLabel(p, text="Detection Modules", font=F["h2"](),
                     text_color=C["t1"]).pack(anchor="w", pady=(PAD_SM, PAD_SM))
        mods = [
            ("🤖", "Agentic-Threat", "Spots AI-driven, machine-speed attacks and command-and-control beaconing.", C["purple"]),
            ("🧠", "Memory-Defence", "Finds fileless malware that runs in RAM with no file on disk.", C["accent"]),
            ("🪪", "Identity-Telemetry", "Catches trusted tools (PowerShell, certutil) being abused to reach the network.", C["accent2"]),
            ("↩", "Smart-Rollback", "Journals exact system changes so a bad one can be undone without losing your work.", C["green"]),
        ]
        mgrid = ctk.CTkFrame(p, fg_color="transparent")
        mgrid.pack(fill="x", pady=(0, PAD_MD))
        for i, (ic, nm, ds, col) in enumerate(mods):
            card = GlassCard(mgrid)
            card.grid(row=i // 2, column=i % 2, padx=PAD_SM // 2, pady=PAD_SM // 2, sticky="nsew")
            mgrid.columnconfigure(i % 2, weight=1)
            ctk.CTkLabel(card, text=f"{ic}  {nm}", font=F["card_title"](),
                         text_color=col, anchor="w").pack(anchor="w", padx=PAD_MD, pady=(PAD_MD, 0))
            ctk.CTkLabel(card, text=ds, font=F["meta"](), text_color=C["t2"],
                         justify="left", anchor="w", wraplength=scaled(340)).pack(
                anchor="w", padx=PAD_MD, pady=(scaled(2), PAD_MD))

        # ── Live threat feed ───────────────────────────────────────
        ctk.CTkLabel(p, text="Live Threat Feed", font=F["h2"](),
                     text_color=C["t1"]).pack(anchor="w", pady=(PAD_SM, PAD_SM))
        feed.pack(fill="x", pady=(0, PAD_MD))
        if not probe.running:
            feed.append("Press ▶ Start to begin monitoring. Detections will appear here in plain English.", "info")
        # replay recent detections into the feed on page open
        for det in reversed(probe.recent(12)):
            _on_detection(det)
        # Page-scoped subscription: drop any prior page's (now-destroyed) feed
        # callback before wiring this one, so subscribers never accumulate.
        probe._subs.clear()
        probe.subscribe(_on_detection)

        # ── Change journal (for smart rollback) ────────────────────
        ctk.CTkLabel(p, text="Change Journal  ·  reversible system changes",
                     font=F["h2"](), text_color=C["t1"]).pack(anchor="w", pady=(PAD_SM, PAD_SM))
        # Pull from the durable, shared journal so this shows BOTH probe actions
        # and hardening-tool changes, and reverted items drop off automatically.
        from core import hardening as _hard
        jrn = _hard.list_rollbacks()[:20]
        if not jrn:
            pg.empty_state("↩", "No recorded changes yet",
                           "When the probe or a hardening tool changes the system, it's logged here so it can be undone.")
        else:
            for ch in jrn:
                row = GlassCard(p, hoverable=False)
                row.pack(fill="x", pady=scaled(2))
                ctk.CTkLabel(row, text=(ch.get("tool_id") or "")[:16], font=F["meta"](),
                             text_color=C["t3"], width=scaled(120)).pack(side="left", padx=(PAD_MD, PAD_SM), pady=PAD_SM)
                ctk.CTkLabel(row, text=ch.get("detail", ""), font=F["card_sub"](),
                             text_color=C["t1"], anchor="w").pack(side="left")
                tag = "reversible" if ch.get("reversible") else "permanent"

                def _revert(rec_id=ch.get("id")):
                    if not rec_id:
                        return
                    ok, msg = probe.revert_change(rec_id)
                    feed.append(("Reverted: " if ok else "Revert failed: ") + msg,
                                "ok" if ok else "err")
                    self.after(50, lambda: self._nav("probe"))

                if ch.get("reversible") and ch.get("id"):
                    ctk.CTkButton(row, text="↩ Revert", font=F["badge"](),
                                  fg_color=C["bg5"], hover_color=C["accent"],
                                  text_color=C["t1"], height=scaled(26), width=scaled(78),
                                  corner_radius=scaled(6), command=_revert).pack(
                        side="right", padx=PAD_MD)
                ctk.CTkLabel(row, text=tag, font=F["badge"](),
                             text_color=C["green"] if ch.get("reversible") else C["orange"]).pack(
                    side="right", padx=PAD_SM)

        _refresh_status()
        pg.footer()

    # ══════════════════════════════════════════════════════════════════
    # Encryption Vault — hybrid post-quantum + SHA-256
    # ══════════════════════════════════════════════════════════════════
    def _page_encrypt(self):
        pg = _PageBase(self._content, self)
        pg.header("🔐  Encryption Vault",
                  "Post-quantum hybrid encryption · SHA-256 integrity")
        p = self._content

        caps = pqcrypto.crypto_capabilities()

        ExplainCard(
            p,
            title="Why post-quantum encryption?",
            plain=(
                "Anything encrypted with today's ordinary methods could one day be unlocked "
                "by a powerful quantum computer — and attackers can copy your encrypted files "
                "now to crack them later. This vault protects against that by using a "
                "quantum-resistant method (ML-KEM, chosen by NIST) *together with* a classic "
                "one, so your data stays safe even if either is ever broken. It also stamps a "
                "SHA-256 fingerprint on everything so you can prove a file hasn't been altered."
            ),
            deeper=(
                "Two modes. PASSWORD mode derives a key from your passphrase with scrypt and "
                "encrypts with AES-256-GCM — great for a file only you (or someone with the "
                "password) should open. KEYPAIR mode is the quantum-safe hybrid: it "
                "encapsulates a secret to the recipient's ML-KEM-768 public key and to an "
                "ephemeral X25519 key, mixes both shared secrets through HKDF-SHA256, and "
                "encrypts with AES-256-GCM. Only the matching private key can decrypt. All "
                "primitives are standard and audited; nothing home-rolled."
            ),
        ).pack(fill="x", pady=(0, PAD_MD))

        # ── capability badges ──────────────────────────────────────
        badge_row = ctk.CTkFrame(p, fg_color="transparent")
        badge_row.pack(fill="x", pady=(0, PAD_MD))
        def _cap_badge(label, ok):
            col = C["green"] if ok else C["red"]
            tk.Label(badge_row, text=f"  {'✓' if ok else '✗'} {label}  ",
                     font=("Courier", scaled(9), "bold"),
                     bg=C["bg5"], fg=col, padx=scaled(4), pady=scaled(3)).pack(
                side="left", padx=scaled(3))
        _cap_badge("AES-256-GCM", caps["aes_gcm"])
        _cap_badge("X25519", caps["x25519"])
        _cap_badge("ML-KEM-768 (PQC)", caps["ml_kem_768"])
        _cap_badge("SHA-256", caps["sha256"])
        _cap_badge(f"KDF: {caps['password_kdf']}", caps["password_kdf"] == "argon2id")
        _cap_badge("Quantum-safe" if caps["quantum_safe"] else "Quantum-safe (needs libs)",
                   caps["quantum_safe"])
        # Honesty badge: is the PQC backend a constant-time production build?
        _cap_badge(
            "PQC: constant-time" if caps["pqc_production_grade"]
            else ("PQC: reference (eval only)" if caps["quantum_safe"] else "PQC: none"),
            caps["pqc_production_grade"])

        if caps["install_hint"]:
            ctk.CTkLabel(p, text=f"  ℹ  For full quantum-safe mode:  {caps['install_hint']}",
                         font=F["meta"](), text_color=C["yellow"]).pack(anchor="w", pady=(0, PAD_SM))

        # ── Tabbed interface: Text / File / Keys / Hash ─────────────
        tabs = ctk.CTkTabview(p, fg_color=C["bg2"], segmented_button_fg_color=C["bg4"],
                              segmented_button_selected_color=C["accent"],
                              segmented_button_selected_hover_color=C["adim"],
                              text_color=C["t1"], height=scaled(430))
        tabs.pack(fill="both", expand=True, pady=(0, PAD_MD))
        for name in ("Encrypt Text", "Encrypt File", "My Keys", "Verify (SHA-256)"):
            tabs.add(name)

        self._build_encrypt_text_tab(tabs.tab("Encrypt Text"), caps)
        self._build_encrypt_file_tab(tabs.tab("Encrypt File"), caps)
        self._build_keys_tab(tabs.tab("My Keys"), caps)
        self._build_hash_tab(tabs.tab("Verify (SHA-256)"))

        pg.footer()

    # ── Encryption tab builders ─────────────────────────────────────────
    def _build_encrypt_text_tab(self, parent, caps):
        mode_var = ctk.StringVar(value="password")
        ctk.CTkLabel(parent, text="Type or paste text, choose how to lock it, and Encrypt.",
                     font=F["card_sub"](), text_color=C["t2"]).pack(anchor="w", pady=(scaled(4), scaled(6)))

        seg = ctk.CTkSegmentedButton(parent, values=["password", "recipient key"],
                                     variable=mode_var, fg_color=C["bg4"],
                                     selected_color=C["accent"], text_color=C["t1"])
        seg.pack(anchor="w", pady=(0, scaled(6)))

        in_box = ctk.CTkTextbox(parent, height=scaled(90), fg_color=C["term_bg"],
                                text_color=C["t1"], font=F["term"]())
        in_box.pack(fill="x", pady=scaled(4))

        key_var = ctk.StringVar()
        key_entry = ctk.CTkEntry(parent, textvariable=key_var, font=F["card_sub"](),
                                 fg_color=C["bg4"], border_color=C["border"], text_color=C["t1"],
                                 placeholder_text="password")
        key_entry.pack(fill="x", pady=scaled(4))

        def _sync_placeholder(*_):
            key_entry.configure(placeholder_text=(
                "password" if mode_var.get() == "password"
                else "recipient PUBLIC key (paste their public bundle)"))
        mode_var.trace_add("write", _sync_placeholder)

        out_box = ctk.CTkTextbox(parent, height=scaled(120), fg_color=C["term_bg"],
                                 text_color=C["accent"], font=F["term"]())
        out_box.pack(fill="x", pady=scaled(4))
        status = ctk.CTkLabel(parent, text="", font=F["meta"](), text_color=C["t2"])
        status.pack(anchor="w")

        def _do(encrypt: bool):
            txt = in_box.get("1.0", "end").rstrip("\n")
            secret = key_var.get()
            try:
                if encrypt:
                    data = txt.encode("utf-8")
                    if mode_var.get() == "password":
                        blob = pqcrypto.encrypt_with_password(data, secret)
                    else:
                        blob = pqcrypto.encrypt_to_public(data, secret)
                    result = pqcrypto.armor(blob)
                    status.configure(text=f"  ✓  Encrypted · SHA-256 of original: {pqcrypto.sha256_hex(data)[:24]}…",
                                     text_color=C["green"])
                else:
                    blob = pqcrypto.dearmor(txt)
                    if mode_var.get() == "password":
                        data = pqcrypto.decrypt_with_password(blob, secret)
                    else:
                        pw = None
                        if pqcrypto.is_wrapped_private(secret):
                            from tkinter import simpledialog
                            pw = simpledialog.askstring(
                                "Passphrase", "This private key is passphrase-protected.\n"
                                "Enter its passphrase:", show="•", parent=self)
                        data = pqcrypto.decrypt_with_private(blob, secret, passphrase=pw)
                    result = data.decode("utf-8", errors="replace")
                    status.configure(text="  ✓  Decrypted successfully.", text_color=C["green"])
                out_box.delete("1.0", "end")
                out_box.insert("1.0", result)
            except Exception as e:
                status.configure(text=f"  ✗  {e}", text_color=C["red"])

        brow = ctk.CTkFrame(parent, fg_color="transparent")
        brow.pack(anchor="w", pady=scaled(6))
        ctk.CTkButton(brow, text="🔒  Encrypt", font=F["button_sm"](), fg_color=C["accent"],
                      hover_color=C["adim"], text_color=C["bg0"], height=scaled(36),
                      command=lambda: _do(True)).pack(side="left", padx=(0, scaled(6)))
        ctk.CTkButton(brow, text="🔓  Decrypt", font=F["button_sm"](), fg_color=C["accent2"],
                      hover_color=C["a2dim"], text_color=C["bg0"], height=scaled(36),
                      command=lambda: _do(False)).pack(side="left")

    def _build_encrypt_file_tab(self, parent, caps):
        ctk.CTkLabel(parent, text="Encrypt or decrypt a file on disk. The original is left untouched;\n"
                     "a new .fstk file is written next to it (or restored from one).",
                     font=F["card_sub"](), text_color=C["t2"], justify="left").pack(anchor="w", pady=(scaled(4), scaled(6)))
        mode_var = ctk.StringVar(value="password")
        ctk.CTkSegmentedButton(parent, values=["password", "recipient key"], variable=mode_var,
                               fg_color=C["bg4"], selected_color=C["accent"],
                               text_color=C["t1"]).pack(anchor="w", pady=(0, scaled(6)))
        key_var = ctk.StringVar()
        ctk.CTkEntry(parent, textvariable=key_var, font=F["card_sub"](), fg_color=C["bg4"],
                     border_color=C["border"], text_color=C["t1"],
                     placeholder_text="password or recipient public/private key").pack(fill="x", pady=scaled(4))
        status = ctk.CTkLabel(parent, text="", font=F["meta"](), text_color=C["t2"], justify="left")
        status.pack(anchor="w", pady=scaled(6))

        def _pick_and(encrypt: bool):
            path = filedialog.askopenfilename(parent=self)
            if not path:
                return
            secret = key_var.get()

            def _progress(pct):
                # marshalled back to the UI thread; cheap and throttled by chunk size
                self.after(0, lambda: status.configure(
                    text=f"  …  {'Encrypting' if encrypt else 'Decrypting'} {pct}%",
                    text_color=C["t2"]))

            def _work():
                try:
                    if encrypt:
                        out = path + ".fstk"
                        # SHA-256 of the original, streamed (constant memory) for display only
                        digest = pqcrypto.sha256_file(path)
                        if mode_var.get() == "password":
                            pqcrypto.encrypt_file_with_password(path, out, secret, _progress)
                        else:
                            pqcrypto.encrypt_file_to_public(path, out, secret, _progress)
                        msg = f"  ✓  Encrypted → {out}\n  SHA-256 of original: {digest}"
                    else:
                        out = path[:-5] if path.endswith(".fstk") else path + ".decrypted"
                        if mode_var.get() == "password":
                            pqcrypto.decrypt_file_with_password(path, out, secret, _progress)
                        else:
                            pw = None
                            if pqcrypto.is_wrapped_private(secret):
                                from tkinter import simpledialog
                                pw = simpledialog.askstring(
                                    "Passphrase", "This private key is passphrase-protected.\n"
                                    "Enter its passphrase:", show="•", parent=self)
                            pqcrypto.decrypt_file_with_private(path, out, secret, _progress,
                                                               passphrase=pw)
                        msg = f"  ✓  Decrypted → {out}"
                    self.after(0, lambda: status.configure(text=msg, text_color=C["green"]))
                except Exception as e:
                    self.after(0, lambda e=e: status.configure(text=f"  ✗  {e}", text_color=C["red"]))

            # Run off the UI thread so large files don't freeze the app.
            threading.Thread(target=_work, daemon=True).start()

        brow = ctk.CTkFrame(parent, fg_color="transparent")
        brow.pack(anchor="w", pady=scaled(6))
        ctk.CTkButton(brow, text="🔒  Choose file & Encrypt", font=F["button_sm"](),
                      fg_color=C["accent"], hover_color=C["adim"], text_color=C["bg0"],
                      height=scaled(36), command=lambda: _pick_and(True)).pack(side="left", padx=(0, scaled(6)))
        ctk.CTkButton(brow, text="🔓  Choose .fstk & Decrypt", font=F["button_sm"](),
                      fg_color=C["accent2"], hover_color=C["a2dim"], text_color=C["bg0"],
                      height=scaled(36), command=lambda: _pick_and(False)).pack(side="left")

    def _build_keys_tab(self, parent, caps):
        ctk.CTkLabel(parent,
                     text="Generate your personal post-quantum keypair. Share the PUBLIC key so\n"
                          "others can encrypt to you. Keep the PRIVATE key secret — it's the only\n"
                          "thing that can decrypt messages sent to you.",
                     font=F["card_sub"](), text_color=C["t2"], justify="left").pack(anchor="w", pady=(scaled(4), scaled(6)))
        pub_box = ctk.CTkTextbox(parent, height=scaled(90), fg_color=C["term_bg"],
                                 text_color=C["green"], font=F["term"]())
        priv_box = ctk.CTkTextbox(parent, height=scaled(90), fg_color=C["term_bg"],
                                  text_color=C["orange"], font=F["term"]())
        fp = ctk.CTkLabel(parent, text="", font=F["meta"](), text_color=C["accent2"])

        pp_var = ctk.StringVar()

        def _gen():
            if not caps["quantum_safe"]:
                fp.configure(text=f"  ✗  Needs: {caps['install_hint']}", text_color=C["red"])
                fp.pack(anchor="w"); return
            kp = pqcrypto.generate_keypair()
            pp = pp_var.get().strip()
            priv_out = kp.private_bundle()
            note = ""
            if pp:
                try:
                    priv_out = pqcrypto.wrap_private_bundle(priv_out, pp)
                    note = "  (private key is passphrase-protected — you'll need this passphrase to decrypt)"
                except Exception as e:
                    fp.configure(text=f"  ✗  Could not protect key: {e}", text_color=C["red"])
                    fp.pack(anchor="w"); return
            pub_box.delete("1.0", "end"); pub_box.insert("1.0", kp.public_bundle())
            priv_box.delete("1.0", "end"); priv_box.insert("1.0", priv_out)
            fp.configure(text=f"  Key fingerprint (verify out-of-band): {kp.public_fingerprint()}{note}",
                         text_color=C["accent2"])
            fp.pack(anchor="w", pady=scaled(4))

        pp_row = ctk.CTkFrame(parent, fg_color="transparent")
        pp_row.pack(anchor="w", fill="x", pady=(scaled(2), 0))
        ctk.CTkLabel(pp_row, text="Protect private key with a passphrase (optional):",
                     font=F["meta"](), text_color=C["t2"]).pack(side="left")
        ctk.CTkEntry(pp_row, textvariable=pp_var, show="•", width=scaled(200),
                     font=F["card_sub"](), fg_color=C["bg4"], border_color=C["border"],
                     text_color=C["t1"], placeholder_text="leave blank for an unprotected key").pack(
            side="left", padx=PAD_SM)

        ctk.CTkButton(parent, text="🔑  Generate new keypair", font=F["button_sm"](),
                      fg_color=C["accent"], hover_color=C["adim"], text_color=C["bg0"],
                      height=scaled(36), command=_gen).pack(anchor="w", pady=scaled(4))
        ctk.CTkLabel(parent, text="PUBLIC key — safe to share:", font=F["meta"](),
                     text_color=C["green"]).pack(anchor="w", pady=(scaled(6), 0))
        pub_box.pack(fill="x", pady=scaled(2))
        ctk.CTkLabel(parent, text="PRIVATE key — keep secret, store safely:", font=F["meta"](),
                     text_color=C["orange"]).pack(anchor="w", pady=(scaled(6), 0))
        priv_box.pack(fill="x", pady=scaled(2))

    def _build_hash_tab(self, parent):
        ctk.CTkLabel(parent,
                     text="A SHA-256 hash is a unique fingerprint of a file. If even one byte\n"
                          "changes, the fingerprint changes completely — so you can check a\n"
                          "download hasn't been tampered with by comparing hashes.",
                     font=F["card_sub"](), text_color=C["t2"], justify="left").pack(anchor="w", pady=(scaled(4), scaled(6)))
        result = ctk.CTkTextbox(parent, height=scaled(80), fg_color=C["term_bg"],
                                text_color=C["accent"], font=F["term"]())
        compare_var = ctk.StringVar()
        status = ctk.CTkLabel(parent, text="", font=F["card_sub"]())

        def _hash_file():
            path = filedialog.askopenfilename(parent=self)
            if not path:
                return
            try:
                digest = pqcrypto.sha256_file(path)
                result.delete("1.0", "end")
                result.insert("1.0", f"{digest}\n\nfile: {path}")
                expected = compare_var.get().strip().lower()
                if expected:
                    if expected == digest:
                        status.configure(text="  ✓  MATCH — the file is intact and unmodified.",
                                         text_color=C["green"])
                    else:
                        status.configure(text="  ✗  MISMATCH — the file differs from the expected hash!",
                                         text_color=C["red"])
                    status.pack(anchor="w", pady=scaled(4))
            except Exception as e:
                result.delete("1.0", "end"); result.insert("1.0", f"Error: {e}")

        ctk.CTkEntry(parent, textvariable=compare_var, font=F["card_sub"](), fg_color=C["bg4"],
                     border_color=C["border"], text_color=C["t1"],
                     placeholder_text="(optional) paste an expected SHA-256 to compare").pack(fill="x", pady=scaled(4))
        ctk.CTkButton(parent, text="🔍  Choose file & hash", font=F["button_sm"](),
                      fg_color=C["accent"], hover_color=C["adim"], text_color=C["bg0"],
                      height=scaled(36), command=_hash_file).pack(anchor="w", pady=scaled(4))
        result.pack(fill="x", pady=scaled(4))

    # ══════════════════════════════════════════════════════════════════
    # First-run onboarding wizard
    # ══════════════════════════════════════════════════════════════════

    # Recommended scan paths keyed by persona.
    # Each entry: (tool_id, why-this-first rationale)
    _ONBOARD_PATHS = {
        "home": [
            ("screen_lock",      "Locks your screen automatically — takes 10 seconds, stops walk-up access"),
            ("auto_updates",     "Makes sure your OS patches itself — closes the #1 breach vector"),
            ("av_status",        "Confirms your antivirus is actually running and current"),
            ("nist_password",    "Sets a strong password policy in the background"),
            ("guest_disable",    "Removes the built-in guest account — unauthenticated access with no password"),
            ("account_lockout",  "Locks any account after 5 failed logins — stops password-guessing attacks cold"),
            ("firewall_config",  "Turns on the built-in firewall — default-deny inbound"),
            ("disable_services", "Turns off legacy services like Telnet and SMBv1 — open doors you don't need"),
            ("wifi_security",    "Checks your Wi-Fi for WEP/open networks that can be cracked in minutes"),
            ("dns_over_https",   "Encrypts your DNS lookups — stops your ISP and local attackers seeing every site you visit"),
            ("hosts_blocklist",  "Blocks 50,000+ known malware and tracking domains at the OS level"),
        ],
        "admin": [
            ("audit_logging",    "Log everything first — you can't investigate what you didn't record"),
            ("encryption_check", "Verify all drives are encrypted before anything else"),
            ("admin_audit",      "Enumerate every privileged account — shadow admins are a top ATT&CK technique"),
            ("startup_audit",    "Check persistence mechanisms — malware universally hides here"),
            ("open_ports",       "Map the attack surface — every listening port is a potential entry point"),
            ("av_status",        "Confirm AV/EDR is running, current, and tamper-protected"),
            ("cve_scan",         "Find unpatched CVEs — published vulnerabilities are exploited within hours"),
            ("disable_services", "Disable legacy services — Telnet, SMBv1, SSDP shrink the attack surface immediately"),
            ("usb_lockdown",     "Block USB auto-execution — BadUSB and rubber ducky attacks rely entirely on it"),
            ("rdp_hardening",    "RDP is the most scanned service on the internet — harden or disable it"),
            ("tls_config",       "Disable SSLv3/TLS 1.0/1.1 — vulnerable to POODLE, BEAST, SWEET32"),
        ],
    }

    _PERSONA_META = {
        "home": {
            "icon":  "🏠",
            "title": "Home / Personal",
            "sub":   "I want my personal computer to be more secure",
            "time":  "~25 min",
            "col":   "accent",
        },
        "admin": {
            "icon":  "🏢",
            "title": "IT Admin / Compliance",
            "sub":   "Running this for an organization or audit",
            "time":  "~60 min",
            "col":   "purple",
        },
    }

    def _show_onboarding(self) -> None:
        """First-run modal: persona selection → recommended scan path → Start / Skip."""
        ov = ctk.CTkToplevel(self)
        ov.title("Welcome to ForceStack")
        ov.geometry(f"{scaled(780)}x{scaled(640)}")
        ov.configure(fg_color=C["bg1"])
        ov.transient(self)
        ov.grab_set()
        ov.resizable(False, False)

        # Track current view: "persona" | "path"
        _persona: list[str] = []

        # ── Scrollable inner area ──────────────────────────────────
        scroll = ctk.CTkScrollableFrame(
            ov, fg_color="transparent",
            scrollbar_button_color=C["bg4"],
            scrollbar_button_hover_color=C["accent"],
        )
        scroll.pack(fill="both", expand=True, padx=0, pady=0)
        body = ctk.CTkFrame(scroll, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=scaled(32), pady=scaled(24))

        def _clear():
            for w in body.winfo_children():
                w.destroy()

        def _dismiss(start_tool_id: str | None = None) -> None:
            try:
                ONBOARD_STATE.write_text("done")
            except Exception:
                pass
            try:
                ov.destroy()
            except Exception:
                pass
            if start_tool_id and start_tool_id in TOOL_MAP:
                self.after(50, lambda: self._page_tool_detail(TOOL_MAP[start_tool_id]))

        # ── View 1: Persona selection ──────────────────────────────
        def _show_persona_view() -> None:
            _clear()

            ctk.CTkLabel(body, text="Welcome to ForceStack",
                         font=F["page_title"](), text_color=C["t1"]).pack(pady=(0, scaled(4)))
            ctk.CTkLabel(
                body,
                text=(
                    "20 NIST SP 800-53 hardening scripts — cross-platform, free, open.\n"
                    "Which describes you best? We'll build a recommended scan order."
                ),
                font=F["card_sub"](), text_color=C["t2"],
                justify="center",
            ).pack(pady=(0, scaled(24)))

            card_row = ctk.CTkFrame(body, fg_color="transparent")
            card_row.pack(fill="x")
            card_row.columnconfigure(0, weight=1)
            card_row.columnconfigure(1, weight=1)

            for col_idx, (key, meta) in enumerate(self._PERSONA_META.items()):
                col = C[meta["col"]]
                card = GlassCard(card_row, hoverable=True,
                                  fg_color=C["bg3"],
                                  border_color=col + "33")
                card.grid(row=0, column=col_idx,
                          padx=(0 if col_idx == 0 else PAD_SM, PAD_SM if col_idx == 0 else 0),
                          sticky="nsew", ipady=PAD_MD)

                ctk.CTkLabel(card, text=meta["icon"],
                             font=ctk.CTkFont(size=scaled(36))).pack(pady=(PAD_LG, 0))
                ctk.CTkLabel(card, text=meta["title"],
                             font=F["section_label"](), text_color=col).pack(pady=(scaled(4), 0))
                ctk.CTkLabel(card, text=meta["sub"], font=F["card_sub"](),
                             text_color=C["t2"], wraplength=scaled(280),
                             justify="center").pack(pady=(scaled(4), 0))
                ctk.CTkLabel(card, text=f"Suggested path: {meta['time']}",
                             font=F["meta"](), text_color=C["t3"]).pack(pady=(scaled(6), PAD_LG))

                ctk.CTkButton(
                    card, text="Choose →",
                    font=F["button_sm"](),
                    fg_color=col + "22", hover_color=col + "40",
                    text_color=col, height=scaled(36),
                    corner_radius=scaled(8),
                    command=lambda k=key: _show_path_view(k),
                ).pack(pady=(0, PAD_LG))

            # Skip
            ctk.CTkButton(
                body, text="Skip — take me straight to the dashboard",
                font=F["meta"](),
                fg_color="transparent", hover_color=C["bg4"],
                text_color=C["t3"], height=scaled(28),
                command=lambda: _dismiss(None),
            ).pack(pady=(PAD_LG, 0))

        # ── View 2: Recommended path ───────────────────────────────
        def _show_path_view(persona: str) -> None:
            _clear()
            _persona.clear()
            _persona.append(persona)

            meta  = self._PERSONA_META[persona]
            steps = self._ONBOARD_PATHS[persona]
            col   = C[meta["col"]]
            first_id = steps[0][0]

            ctk.CTkButton(
                body, text="← Back",
                font=F["button_sm"](), fg_color=C["bg4"], hover_color=C["bg5"],
                text_color=C["t2"], height=scaled(28), width=scaled(64),
                corner_radius=scaled(6), anchor="w",
                command=_show_persona_view,
            ).pack(anchor="w", pady=(0, PAD_MD))

            ctk.CTkLabel(
                body,
                text=f"{meta['icon']}  Recommended path — {meta['title']}",
                font=F["page_title"](), text_color=col,
            ).pack(anchor="w", pady=(0, scaled(4)))
            ctk.CTkLabel(
                body,
                text=(
                    f"Run these {len(steps)} tools in order for the highest impact. "
                    "You can always run more from the sidebar sections."
                ),
                font=F["card_sub"](), text_color=C["t2"], justify="left",
            ).pack(anchor="w", pady=(0, scaled(20)))

            for i, (tid, rationale) in enumerate(steps):
                tool = TOOL_MAP.get(tid)
                if not tool:
                    continue
                is_first = (i == 0)

                step_card = GlassCard(
                    body, hoverable=False,
                    fg_color=col + "0C" if is_first else C["bg3"],
                    border_color=col + "50" if is_first else C["border"],
                )
                step_card.pack(fill="x", pady=scaled(3))

                row = ctk.CTkFrame(step_card, fg_color="transparent")
                row.pack(fill="x", padx=PAD_MD, pady=scaled(10))

                # Step number badge
                num_frame = ctk.CTkFrame(row, fg_color=col + "22",
                                          corner_radius=scaled(6),
                                          width=scaled(32), height=scaled(32))
                num_frame.pack(side="left", padx=(0, PAD_MD))
                num_frame.pack_propagate(False)
                ctk.CTkLabel(num_frame, text=str(i + 1),
                             font=F["badge"](), text_color=col).pack(expand=True)

                info = ctk.CTkFrame(row, fg_color="transparent")
                info.pack(side="left", fill="x", expand=True)
                ctk.CTkLabel(info,
                             text=f"{tool.icon}  {tool.name}",
                             font=F["card_title"](), text_color=C["t1"],
                             anchor="w").pack(anchor="w")
                ctk.CTkLabel(info, text=rationale, font=F["meta"](),
                             text_color=C["t2"], anchor="w",
                             wraplength=scaled(500)).pack(anchor="w")

                RiskBadge(row, tool.risk).pack(side="right", padx=PAD_SM)

                if is_first:
                    ctk.CTkLabel(step_card, text="  ← Start here",
                                 font=F["meta"](), text_color=col).pack(
                        anchor="w", padx=PAD_MD, pady=(0, PAD_SM))

            # CTA
            cta_row = ctk.CTkFrame(body, fg_color="transparent")
            cta_row.pack(fill="x", pady=(PAD_LG, 0))
            ctk.CTkButton(
                cta_row,
                text=f"▶  Start with step 1: {TOOL_MAP[first_id].name}",
                font=F["button"](),
                fg_color=col, hover_color=col + "CC",
                text_color=C["bg0"], height=scaled(46),
                corner_radius=scaled(10),
                command=lambda: _dismiss(first_id),
            ).pack(side="left")
            ctk.CTkButton(
                cta_row,
                text="Go to dashboard instead",
                font=F["button_sm"](),
                fg_color="transparent", hover_color=C["bg4"],
                text_color=C["t3"], height=scaled(46),
                command=lambda: _dismiss(None),
            ).pack(side="left", padx=PAD_MD)

        _show_persona_view()

    # ══════════════════════════════════════════════════════════════════
    # Window persistence
    # ══════════════════════════════════════════════════════════════════
    def _load_window_state(self):
        try:
            if WINDOW_STATE.exists():
                state = json.loads(WINDOW_STATE.read_text())
                w = state.get("width", 1380)
                h = state.get("height", 860)
                x = state.get("x", 100)
                y = state.get("y", 80)
                self.geometry(f"{w}x{h}+{x}+{y}")
                return
        except Exception:
            pass
        self.geometry(f"{scaled(1380)}x{scaled(860)}")

    def _save_window_state(self):
        try:
            state = {
                "width":  self.winfo_width(),
                "height": self.winfo_height(),
                "x":      self.winfo_x(),
                "y":      self.winfo_y(),
            }
            WINDOW_STATE.write_text(json.dumps(state))
        except Exception:
            pass

    def _on_close(self):
        self._bg.stop()
        self._save_window_state()
        self.destroy()
