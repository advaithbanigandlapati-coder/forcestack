"""
ui/background.py — Animated mesh gradient background canvas.
Fixes: #80 (animated mesh gradient like Warp/Linear), #86 (sidebar blur illusion)
"""

from __future__ import annotations
import tkinter as tk
from core.constants import C


class MeshBackground(tk.Canvas):
    """
    Draws 6 large overlapping radial ellipses in deep indigo and midnight blue
    that slowly drift — faking the animated mesh gradient used by Warp Terminal
    and Linear.
    """

    BLOBS = [
        # (rel_x, rel_y, rx, ry, color, speed_x, speed_y)
        (0.15, 0.25, 0.40, 0.35, "#0D1F3C", +0.12, +0.07),
        (0.70, 0.15, 0.35, 0.30, "#091A30", -0.08, +0.10),
        (0.50, 0.65, 0.45, 0.40, "#0A1628", +0.06, -0.09),
        (0.85, 0.75, 0.30, 0.25, "#0F2040", -0.11, -0.06),
        (0.10, 0.80, 0.35, 0.28, "#0C1A34", +0.09, +0.05),
        (0.55, 0.40, 0.50, 0.42, "#071020", -0.05, +0.08),
    ]

    def __init__(self, parent, **kwargs):
        kwargs["bg"] = C["bg0"]
        kwargs["highlightthickness"] = 0
        super().__init__(parent, **kwargs)
        self._blobs = [list(b) for b in self.BLOBS]   # mutable copies
        self._ovals: list[int] = []
        self._running = True
        self.bind("<Configure>", self._on_resize)
        self._animate()

    def _on_resize(self, event=None):
        self._draw()

    def _draw(self):
        self.delete("blob")
        w = self.winfo_width()
        h = self.winfo_height()
        if w < 2 or h < 2:
            return
        for b in self._blobs:
            rx, ry = int(b[2] * w), int(b[3] * h)
            cx, cy = int(b[0] * w), int(b[1] * h)
            self.create_oval(
                cx - rx, cy - ry, cx + rx, cy + ry,
                fill=b[4], outline="", tags="blob",
                stipple="gray50",   # approximate alpha via stipple
            )

    def _animate(self):
        if not self._running:
            return
        for b in self._blobs:
            b[0] += b[5] * 0.001
            b[1] += b[6] * 0.001
            # Bounce
            for idx in [0, 1]:
                if b[idx] < 0.05:
                    b[idx + 5] = abs(b[idx + 5])
                elif b[idx] > 0.95:
                    b[idx + 5] = -abs(b[idx + 5])
        self._draw()
        self.after(40, self._animate)   # 25 fps — low CPU

    def stop(self):
        self._running = False
