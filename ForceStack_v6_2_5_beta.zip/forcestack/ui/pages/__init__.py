"""ui/pages — Per-page view classes (fix #70)."""
