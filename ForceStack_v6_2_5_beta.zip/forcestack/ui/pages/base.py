"""ui/pages/base.py — BasePage shared by all pages. Fix #71: error boundary."""
from __future__ import annotations
import tkinter as tk
import customtkinter as ctk
from core.constants import C
from ui.utils import F, scaled


class BasePage:
    def __init__(self, container: ctk.CTkFrame, app):
        self.container = container
        self.app = app

    def build(self): raise NotImplementedError

    def _page_header(self, title: str, subtitle: str = ""):
        h = ctk.CTkFrame(self.container, fg_color="transparent")
        h.pack(fill="x", pady=(scaled(32), 0))
        ctk.CTkLabel(h, text=title, font=F["page_title"](), text_color=C["t1"]).pack(anchor="w")
        if subtitle:
            ctk.CTkLabel(h, text=subtitle, font=F["card_sub"](), text_color=C["t3"]).pack(
                anchor="w", pady=(scaled(4), 0))
        self._divider()

    def _divider(self):
        c = tk.Canvas(self.container, height=1, highlightthickness=0, bg=C["bg2"])
        c.pack(fill="x", pady=scaled(6))
        c.create_line(0, 0, 9999, 0, fill=C["border"])

    def _empty_state(self, icon: str, title: str, body: str, cta_text: str = "", cta_cmd=None):
        frame = ctk.CTkFrame(self.container, fg_color="transparent")
        frame.pack(pady=scaled(40))
        ctk.CTkLabel(frame, text=icon, font=ctk.CTkFont(size=scaled(48))).pack(pady=(0, scaled(8)))
        ctk.CTkLabel(frame, text=title, font=F["section_label"](), text_color=C["t1"]).pack()
        ctk.CTkLabel(frame, text=body, font=F["card_sub"](), text_color=C["t3"]).pack(pady=scaled(4))
        if cta_text and cta_cmd:
            ctk.CTkButton(frame, text=f"{cta_text} →", font=F["button_sm"](),
                          fg_color=C["accent"], hover_color=C["adim"], text_color=C["bg0"],
                          height=scaled(38), corner_radius=scaled(8), command=cta_cmd).pack(pady=scaled(16))

    def _footer(self):
        ctk.CTkFrame(self.container, fg_color="transparent", height=scaled(48)).pack()
