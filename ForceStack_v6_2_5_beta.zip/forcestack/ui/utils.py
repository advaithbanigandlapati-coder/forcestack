"""
ui/utils.py — UI-only helpers.
Issues fixed: #66 (Tooltip TclError guard), #67 (DPI sentinel for mis-ordering)
"""

from __future__ import annotations
import platform
import tkinter as tk
import customtkinter as ctk
from core.constants import C

# ── Platform font ──────────────────────────────────────────────────────────────
def _system_font() -> str:
    sys = platform.system()
    if sys == "Darwin":  return "SF Pro Display"
    if sys == "Windows": return "Segoe UI Variable"
    return "Inter"

_SYS_FONT = _system_font()

# ── DPI scaling ────────────────────────────────────────────────────────────────
# Fix #67: sentinel value so scaled() raises if init_dpi() was never called
_DPI_SCALE: float | None = None

# Accessibility: an optional user-chosen scale multiplier (Settings → Accessibility),
# applied on top of DPI so text and controls can be enlarged for readability.
try:
    from core.constants import load_config_dict as _load_cfg
    _USER_SCALE: float = max(1.0, min(1.75, float(_load_cfg().get("ui_scale", 1.0))))
except Exception:
    _USER_SCALE = 1.0

def init_dpi(root: tk.Tk) -> None:
    global _DPI_SCALE
    try:
        dpi = root.winfo_fpixels("1i")
        _DPI_SCALE = max(1.0, dpi / 96.0)
    except Exception:
        _DPI_SCALE = 1.0


def scaled(px: int) -> int:
    # Fix #67: fail loudly if DPI not initialised
    if _DPI_SCALE is None:
        import logging
        logging.getLogger("forcestack").warning(
            "scaled() called before init_dpi() — defaulting to 1.0x. "
            "Call ui.utils.init_dpi(root) after creating the Tk window."
        )
        return max(1, round(px * _USER_SCALE))
    return max(1, round(px * _DPI_SCALE * _USER_SCALE))


# ── Type scale ─────────────────────────────────────────────────────────────────
def font(size: int = 13, weight: str = "normal", mono: bool = False) -> ctk.CTkFont:
    family = "Courier" if mono else _SYS_FONT
    return ctk.CTkFont(family=family, size=scaled(size), weight=weight)

F = {
    "page_title":    lambda: font(26, "bold"),
    "section_label": lambda: font(15, "bold"),
    "card_title":    lambda: font(14, "bold"),
    "card_sub":      lambda: font(12),
    "meta":          lambda: font(10),
    "term":          lambda: font(11, mono=True),
    "badge":         lambda: font(9,  "bold"),
    "button":        lambda: font(13, "bold"),
    "button_sm":     lambda: font(12),
    "sidebar_item":  lambda: font(13),
    "sidebar_label": lambda: font(10),
    "h2":            lambda: font(13, "bold"),
    "small":         lambda: font(10),
}

# ── Risk helpers ───────────────────────────────────────────────────────────────
_RISK_COLORS = {
    "low":      C["green"],
    "medium":   C["yellow"],
    "high":     C["orange"],
    "critical": C["red"],
}
_RISK_LABELS = {"low": "LOW", "medium": "MEDIUM", "high": "HIGH", "critical": "CRITICAL"}

def risk_color(risk: str) -> str: return _RISK_COLORS.get(risk, C["t2"])
def risk_label(risk: str) -> str: return _RISK_LABELS.get(risk, risk.upper())


# ── Tooltip ────────────────────────────────────────────────────────────────────
class Tooltip:
    """Hover tooltip following the cursor. Fix #66: TclError guard throughout."""
    _active: "Tooltip | None" = None

    def __init__(self, widget: tk.Widget, text: str):
        self._widget = widget
        self._text   = text
        self._win: tk.Toplevel | None = None
        widget.bind("<Enter>",      self._show, add="+")
        widget.bind("<Leave>",      self._hide, add="+")
        widget.bind("<ButtonPress>",self._hide, add="+")

    def _show(self, event=None):
        if Tooltip._active and Tooltip._active is not self:
            Tooltip._active._hide()
        Tooltip._active = self
        # Fix #66: guard winfo calls — widget may be destroyed
        try:
            x = self._widget.winfo_rootx() + 12
            y = self._widget.winfo_rooty() + self._widget.winfo_height() + 4
        except tk.TclError:
            return
        try:
            self._win = tk.Toplevel(self._widget)
            self._win.wm_overrideredirect(True)
            self._win.wm_geometry(f"+{x}+{y}")
            self._win.configure(bg=C["bg4"])
            tk.Label(
                self._win, text=self._text,
                font=("Courier", scaled(9) if _DPI_SCALE else 9),
                bg=C["bg4"], fg=C["t1"],
                padx=8, pady=5,
                wraplength=280, justify="left",
            ).pack()
        except tk.TclError:
            self._win = None

    def _hide(self, event=None):
        if self._win:
            try:
                self._win.destroy()
            except tk.TclError:
                pass
            self._win = None
        if Tooltip._active is self:
            Tooltip._active = None
