"""
ui/widgets.py — Reusable glass-surface widgets.
Issues fixed: #63 (ColorTerminal.append() is NOT thread-safe — doc corrected + after() added),
              #64 (AnimatedProgress._step TclError guard), #65 (GlassCard._flash cancel previous)
"""

from __future__ import annotations
from typing import Callable
import tkinter as tk
import customtkinter as ctk
from core.constants import C
from ui.utils import F, scaled, risk_color, risk_label


# ── Glass Card ────────────────────────────────────────────────────────────────
class GlassCard(ctk.CTkFrame):
    """Glassmorphism card with hover transitions and border pulse on completion."""

    def __init__(self, parent, hoverable: bool = True, **kwargs):
        kwargs.setdefault("fg_color",      C["bg3"])
        kwargs.setdefault("corner_radius", scaled(18))
        kwargs.setdefault("border_width",  1)
        kwargs.setdefault("border_color",  C["glass_b"])
        super().__init__(parent, **kwargs)
        self._hoverable  = hoverable
        self._flash_job: str | None = None   # fix #65: track scheduled callback

        if hoverable:
            self.bind("<Enter>", self._on_enter, add="+")
            self.bind("<Leave>", self._on_leave, add="+")

    def _on_enter(self, _=None):
        self.configure(fg_color=C["bg4"], border_color=C["glass_bh"])

    def _on_leave(self, _=None):
        self.configure(fg_color=C["bg3"], border_color=C["glass_b"])

    def flash_success(self):
        self._flash_color(C["green"] + "55")

    def flash_error(self):
        self._flash_color(C["red"] + "55")

    def _flash_color(self, color: str):
        # Fix #65: cancel any in-progress flash before starting a new one
        if self._flash_job:
            try:
                self.after_cancel(self._flash_job)
            except Exception:
                pass
            self._flash_job = None
        self._flash(color, 0)

    def _flash(self, color: str, step: int):
        steps = [(color, 0), (C["glass_bh"], 130), (C["glass_b"], 400)]
        if step >= len(steps):
            self._flash_job = None
            return
        target, delay = steps[step]
        try:
            self.configure(border_color=target)
        except Exception:
            return
        self._flash_job = self.after(delay, lambda: self._flash(color, step + 1))


# ── Icon Circle ───────────────────────────────────────────────────────────────
class IconCircle(ctk.CTkLabel):
    """Glass-frosted circle container for an emoji icon."""

    def __init__(self, parent, icon: str, size: int = 48, **kwargs):
        sz = scaled(size)
        super().__init__(
            parent, text=icon,
            font=ctk.CTkFont(size=scaled(size - 6)),
            fg_color=C["glass"],
            corner_radius=sz // 2,
            width=sz, height=sz,
            **kwargs,
        )


# ── Status Dot ────────────────────────────────────────────────────────────────
class StatusDot(tk.Canvas):
    """8px filled circle for last-run status (green/red/grey)."""
    COLOURS = {
        "success": C["green"], "error": C["red"],
        "warning": C["yellow"], "never": C["t3"],
    }

    def __init__(self, parent, status: str = "never", **kwargs):
        sz = scaled(10)
        super().__init__(parent, width=sz, height=sz,
                         bg=C["bg3"], highlightthickness=0, **kwargs)
        self._sz = sz
        self.set_status(status)

    def set_status(self, status: str):
        self.delete("all")
        col = self.COLOURS.get(status, self.COLOURS["never"])
        pad = scaled(1)
        self.create_oval(pad, pad, self._sz - pad, self._sz - pad,
                         fill=col, outline="")


# ── Risk Badge ────────────────────────────────────────────────────────────────
class RiskBadge(ctk.CTkLabel):
    """Glass risk badge with tinted border."""

    def __init__(self, parent, risk: str, **kwargs):
        col = risk_color(risk)
        super().__init__(
            parent,
            text=f"  {risk_label(risk)}  ",
            font=F["badge"](),
            fg_color=col + "18",
            text_color=col,
            corner_radius=scaled(4),
            border_width=1,
            border_color=col + "40",
            **kwargs,
        )


# ── Colored Terminal ──────────────────────────────────────────────────────────
class ColorTerminal(ctk.CTkFrame):
    """
    Terminal output widget using tk.Text with tag-based colour support.

    THREAD SAFETY NOTE (Fix #63):
      append() is NOT thread-safe — tk.Text operations must run on the main
      thread. The method now schedules itself via self.after(0, ...) when called
      from a background thread. Callers should NOT wrap it in their own .after()
      — do it once here, not twice.
    """

    LEVEL_COLORS = {
        "ok":   C["term_ok"],
        "err":  C["term_err"],
        "warn": C["term_warn"],
        "info": C["term_inf"],
    }

    def __init__(self, parent, height: int = 200, **kwargs):
        super().__init__(parent, fg_color=C["term_bg"],
                         corner_radius=scaled(8),
                         border_width=1, border_color=C["border"], **kwargs)

        # Inner glow line at top
        glow = tk.Frame(self, bg=C["accent"] + "15", height=1)
        glow.pack(fill="x", side="top")

        self._text = tk.Text(
            self,
            height=max(4, height // scaled(14)),
            bg=C["term_bg"],
            fg=C["term_fg"],
            insertbackground=C["accent"],
            font=("Courier", scaled(11)),
            wrap="word",
            relief="flat",
            bd=0,
            padx=scaled(12),
            pady=scaled(8),
            state="disabled",
            cursor="arrow",
        )
        self._text.pack(fill="both", expand=True)

        sb = tk.Scrollbar(self._text, command=self._text.yview,
                          bg=C["bg4"], troughcolor=C["bg3"],
                          relief="flat", bd=0, width=scaled(6))
        self._text.configure(yscrollcommand=sb.set)

        for level, col in self.LEVEL_COLORS.items():
            self._text.tag_configure(level, foreground=col)
        self._text.tag_configure("default", foreground=C["term_fg"])

    def _do_append(self, text: str, level: str):
        """Internal: must only be called on the main thread."""
        tag = level if level in self.LEVEL_COLORS else "default"
        try:
            self._text.configure(state="normal")
            self._text.insert("end", text + "\n", tag)
            self._text.see("end")
            self._text.configure(state="disabled")
        except tk.TclError:
            pass  # widget destroyed

    def append(self, text: str, level: str = "info"):
        """
        Fix #63: always schedule on the main thread via after(0).
        Safe to call from ANY thread.
        """
        try:
            self.after(0, self._do_append, text, level)
        except RuntimeError:
            pass  # app shutting down

    def clear(self):
        """Must be called on main thread."""
        try:
            self._text.configure(state="normal")
            self._text.delete("1.0", "end")
            self._text.configure(state="disabled")
        except tk.TclError:
            pass


# ── Error Toast ───────────────────────────────────────────────────────────────
class ErrorToast(ctk.CTkFrame):
    """
    Slide-in error notification — bottom-right corner of the app window.
    Shows plain English title + one-liner from a structured error payload.
    Clicking 'View fix steps' calls on_detail(); X or 8s auto-dismiss slides it out.

    Place on the root CTk window, not inside _content, so it overlays everything.
    """
    _W      = 360   # pre-scale width
    _H      = 130   # pre-scale height (approximate — used for animation offset)
    _PAD_X  = 20    # px from right edge
    _PAD_Y  = 20    # px from bottom edge when fully visible

    def __init__(
        self,
        parent,
        payload: dict,
        on_detail: "Callable[[], None]",
        **kwargs,
    ):
        kwargs.setdefault("fg_color",      C["bg3"])
        kwargs.setdefault("corner_radius", scaled(12))
        kwargs.setdefault("border_width",  1)
        kwargs.setdefault("border_color",  C["red"] + "88")
        super().__init__(parent, width=scaled(self._W), **kwargs)
        self.pack_propagate(False)

        self._on_detail  = on_detail
        self._dismissed  = False
        # Start off-screen below the window bottom edge
        self._y_off      = scaled(self._H + 40)

        # ── Red left stripe ───────────────────────────────────────
        tk.Frame(self, bg=C["red"], width=scaled(4)).pack(side="left", fill="y")

        # ── Body ──────────────────────────────────────────────────
        body = ctk.CTkFrame(self, fg_color="transparent")
        body.pack(side="left", fill="both", expand=True,
                  padx=scaled(10), pady=scaled(8))

        # Title + dismiss button
        title_row = ctk.CTkFrame(body, fg_color="transparent")
        title_row.pack(fill="x")
        ctk.CTkLabel(
            title_row,
            text="⚠  " + payload.get("title", "Error"),
            font=F["card_title"](), text_color=C["red"],
            anchor="w",
        ).pack(side="left", fill="x", expand=True)
        ctk.CTkButton(
            title_row, text="✕",
            width=scaled(22), height=scaled(22),
            fg_color="transparent", hover_color=C["bg5"],
            text_color=C["t3"], font=F["badge"](),
            command=self._dismiss,
        ).pack(side="right")

        # One-liner (why truncated to fit)
        why = payload.get("why", "")
        if why:
            short = (why[:88] + "…") if len(why) > 88 else why
            ctk.CTkLabel(
                body, text=short,
                font=F["card_sub"](), text_color=C["t2"],
                anchor="w", justify="left",
                wraplength=scaled(self._W - 60),
            ).pack(anchor="w", pady=(scaled(2), 0))

        # Details link
        ctk.CTkButton(
            body, text="View fix steps →",
            font=F["meta"](), fg_color="transparent",
            hover_color=C["bg4"], text_color=C["accent2"],
            height=scaled(18), anchor="w",
            command=self._click,
        ).pack(anchor="w", pady=(scaled(4), 0))

        # ── Animate in, auto-dismiss ──────────────────────────────
        self.place(
            relx=1.0, rely=1.0, anchor="se",
            x=-scaled(self._PAD_X), y=self._y_off,
        )
        self.after(40, self._slide_in)
        self.after(8000, self._dismiss)

    # ── Animation helpers ──────────────────────────────────────────
    def _slide_in(self) -> None:
        target = -scaled(self._PAD_Y)
        step   = max(scaled(6), abs(self._y_off - target) // 4)
        self._y_off = max(target, self._y_off - step)
        try:
            self.place(relx=1.0, rely=1.0, anchor="se",
                       x=-scaled(self._PAD_X), y=self._y_off)
        except tk.TclError:
            return
        if self._y_off > target:
            self.after(16, self._slide_in)

    def _slide_out(self) -> None:
        target = scaled(self._H + 40)
        step   = max(scaled(8), abs(target - self._y_off) // 3 + scaled(4))
        self._y_off = min(target, self._y_off + step)
        try:
            self.place(relx=1.0, rely=1.0, anchor="se",
                       x=-scaled(self._PAD_X), y=self._y_off)
        except tk.TclError:
            return
        if self._y_off < target:
            self.after(16, self._slide_out)
        else:
            try:
                self.destroy()
            except tk.TclError:
                pass

    def _dismiss(self) -> None:
        if self._dismissed:
            return
        self._dismissed = True
        self._slide_out()

    def _click(self) -> None:
        self._dismissed = True
        try:
            self.destroy()
        except tk.TclError:
            pass
        self._on_detail()


# ── Animated Progress Bar ─────────────────────────────────────────────────────
class AnimatedProgress(ctk.CTkProgressBar):
    """
    Progress bar with eased interpolation.
    Fix #64: TclError guard when widget destroyed during animation.
    """

    def __init__(self, parent, **kwargs):
        kwargs.setdefault("fg_color",       C["bg4"])
        kwargs.setdefault("progress_color", C["accent"])
        kwargs.setdefault("height",         scaled(6))
        kwargs.setdefault("corner_radius",  scaled(3))
        super().__init__(parent, **kwargs)
        self._target:    float = 0.0
        self._current:   float = 0.0
        self._animating: bool  = False

    def set_target(self, value: float):
        self._target = max(0.0, min(1.0, value))
        if not self._animating:
            self._animating = True
            self._step()

    def _step(self):
        # Fix #64: guard against TclError when widget is destroyed mid-animation
        try:
            diff = self._target - self._current
            if abs(diff) < 0.005:
                self._current = self._target
                self.set(self._current)
                self._animating = False
                return
            self._current += diff * 0.25
            self.set(self._current)
            self.after(16, self._step)
        except tk.TclError:
            self._animating = False


# ── Explain Card (accessibility: plain-English, collapsible learning aid) ──────
class ExplainCard(ctk.CTkFrame):
    """
    A friendly "What is this and why does it matter?" panel.

    Core to the toolkit's mission: anyone — IT pro, teenager, first-timer —
    should understand what a page does and learn from it. Shows a plain-English
    summary always; an optional "For the curious →" toggle reveals a deeper,
    more technical explanation for those who want it. Nobody is talked down to,
    nobody is drowned in jargon.
    """

    def __init__(self, parent, title: str, plain: str, deeper: str = "", icon: str = "💡", **kwargs):
        kwargs.setdefault("fg_color", C["accent"] + "0E")
        kwargs.setdefault("corner_radius", scaled(14))
        kwargs.setdefault("border_width", 1)
        kwargs.setdefault("border_color", C["accent"] + "33")
        super().__init__(parent, **kwargs)

        head = ctk.CTkFrame(self, fg_color="transparent")
        head.pack(fill="x", padx=scaled(16), pady=(scaled(12), scaled(2)))
        ctk.CTkLabel(head, text=f"{icon}  {title}", font=F["card_title"](),
                     text_color=C["accent"], anchor="w").pack(side="left")

        ctk.CTkLabel(self, text=plain, font=F["card_sub"](), text_color=C["t1"],
                     justify="left", anchor="w", wraplength=scaled(720)).pack(
            fill="x", padx=scaled(16), pady=(0, scaled(12)))

        if deeper:
            self._open = False
            self._deeper_text = deeper
            self._toggle = ctk.CTkButton(
                self, text="For the curious  ▸", font=F["meta"](),
                fg_color="transparent", hover_color=C["bg4"],
                text_color=C["accent2"], anchor="w", height=scaled(22),
                command=self._flip,
            )
            self._toggle.pack(anchor="w", padx=scaled(12), pady=(0, scaled(6)))
            self._body = ctk.CTkLabel(
                self, text=deeper, font=F["card_sub"](), text_color=C["t2"],
                justify="left", anchor="w", wraplength=scaled(720))

    def _flip(self):
        self._open = not self._open
        if self._open:
            self._body.pack(fill="x", padx=scaled(16), pady=(0, scaled(12)))
            self._toggle.configure(text="For the curious  ▾")
        else:
            self._body.pack_forget()
            self._toggle.configure(text="For the curious  ▸")


# ── Severity Pill ──────────────────────────────────────────────────────────────
class SeverityPill(ctk.CTkLabel):
    """Coloured band label for probe detections (info/low/medium/high/critical)."""
    _MAP = {
        "info":     ("t2",    "INFO"),
        "low":      ("green",  "LOW"),
        "medium":   ("yellow", "MEDIUM"),
        "high":     ("orange", "HIGH"),
        "critical": ("red",    "CRITICAL"),
    }

    def __init__(self, parent, band: str, **kwargs):
        col_key, text = self._MAP.get(band, ("t2", band.upper()))
        col = C[col_key]
        super().__init__(parent, text=f"  {text}  ", font=F["badge"](),
                         fg_color=col + "20", text_color=col,
                         corner_radius=scaled(4), border_width=1,
                         border_color=col + "55", **kwargs)
